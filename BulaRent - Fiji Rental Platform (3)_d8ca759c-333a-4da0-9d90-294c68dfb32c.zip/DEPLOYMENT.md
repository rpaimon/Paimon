# BulaRent Deployment Guide for Hostinger

## Overview
This guide will help you deploy BulaRent to Hostinger. The application is built with React + TypeScript and uses Supabase for backend services.

## Prerequisites
1. Node.js (version 18 or higher)
2. Hostinger hosting account with Node.js support
3. Supabase account and project

## Step 1: Setup Environment Variables

Create a `.env` file in your root directory with the following variables:

```env
VITE_SUPABASE_URL=your-supabase-project-url
VITE_SUPABASE_ANON_KEY=your-supabase-anon-key
SUPABASE_SERVICE_ROLE_KEY=your-supabase-service-role-key
```

## Step 2: Build the Application

1. Install dependencies:
```bash
npm install
```

2. Build the application:
```bash
npm run build
```

This creates a `dist` folder with static files.

## Step 3: Deploy to Hostinger

### Option A: Static Site Deployment (Recommended for Frontend Only)
1. Upload the contents of the `dist` folder to your Hostinger public_html directory
2. Configure your domain to point to the uploaded files

### Option B: Full Stack Deployment (with Supabase Edge Functions)
1. Deploy the Supabase functions:
```bash
npx supabase functions deploy server
```

2. Upload the frontend files to Hostinger
3. Update the API endpoints in your code to point to your Supabase functions

## Step 4: Admin Setup

To access the admin panel:
1. Create an account with email: `admin@bularent.com` or `owner@bularent.com`
2. Navigate to `/admin` or use the admin link in the user menu
3. You can now approve/reject properties and send WhatsApp notifications

## Step 5: Email Verification Fix

The current setup auto-confirms user emails. To enable proper email verification:
1. Configure email templates in Supabase Dashboard
2. Set up SMTP settings in Supabase
3. Update the signup flow to require email confirmation

## Property Approval Workflow

1. Users submit properties → Status: "pending"
2. Admin receives notification (can be sent via WhatsApp)
3. Admin reviews property in admin panel
4. Admin approves → Property appears in public listings
5. Admin rejects → Property owner is notified

## WhatsApp Integration

The admin panel includes WhatsApp integration:
- Click "WhatsApp" button on any property
- Pre-formatted message with property details opens
- Send to yourself or property management team

## Troubleshooting

### Common Issues:
1. **Build errors**: Check all imports and dependencies
2. **API errors**: Verify Supabase environment variables
3. **Email verification**: Check Supabase auth settings
4. **Admin access**: Ensure email matches admin emails in code

### File Structure After Build:
```
dist/
├── index.html
├── assets/
│   ├── css files
│   └── js files
└── favicon.svg
```

## Security Notes

1. Never expose service role keys in frontend code
2. Use environment variables for all sensitive data
3. Enable RLS (Row Level Security) in Supabase
4. Regularly update dependencies

## Performance Optimization

1. Images are optimized automatically
2. Code splitting is enabled
3. Assets are cached by browser
4. Consider using Hostinger's CDN

## Support

For deployment issues:
- Check Hostinger documentation for Node.js apps
- Verify Supabase connection
- Test API endpoints after deployment

## Production Checklist

- [ ] Environment variables set
- [ ] Build completes without errors
- [ ] Admin account created
- [ ] Email settings configured
- [ ] WhatsApp integration tested
- [ ] Property submission workflow tested
- [ ] All pages load correctly
- [ ] Mobile responsiveness verified