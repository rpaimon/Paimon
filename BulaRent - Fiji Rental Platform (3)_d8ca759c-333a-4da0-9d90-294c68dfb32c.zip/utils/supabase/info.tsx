// Replace the demo configuration with your real Supabase credentials
// IMPORTANT: Replace these with your actual Supabase project values

// Get these from your Supabase project settings → API
export const projectId = 'your-actual-project-id'; // Extract from your project URL
export const publicAnonKey = 'your-actual-anon-key'; // From Project Settings → API
export const supabaseUrl = 'https://your-actual-project-id.supabase.co'; // Your project URL

// Environment check
const isDemoMode = !projectId || projectId === 'demo-project-id';

if (isDemoMode) {
  console.log('🏝️ BulaRent Demo Mode: Using demo Supabase configuration');
  console.log('📝 To connect to real Supabase, update /utils/supabase/info.tsx with your project credentials');
} else {
  console.log('✅ BulaRent: Connected to production Supabase');
}

export const demoMode = isDemoMode;