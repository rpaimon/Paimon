import { useState } from 'react';
import { AuthProvider } from './components/auth/AuthContext';
import EnhancedNavigation from './components/EnhancedNavigation';
import HomePage from './components/HomePage';
import EnhancedListingsPage from './components/EnhancedListingsPage';
import PropertyDetailsPage from './components/PropertyDetailsPage';
import SubmitPropertyPage from './components/SubmitPropertyPage';
import AboutPage from './components/AboutPage';
import ContactPage from './components/ContactPage';
import UserDashboard from './components/UserDashboard';
import AdminPanel from './components/AdminPanel';
import MobileDemo from './components/MobileDemo';
import FijiTenancyAgreement from './components/FijiTenancyAgreement';
import ITaukeiLandInfo from './components/ITaukeiLandInfo';
import MPaisaHelp from './components/MPaisaHelp';
import VerificationPage from './components/VerificationPage';
import AuthModal from './components/auth/AuthModal';

export default function App() {
  const [currentPage, setCurrentPage] = useState('home');
  const [currentPropertyId, setCurrentPropertyId] = useState<string | null>(null);
  const [showMobileDemo, setShowMobileDemo] = useState(false);

  const handleNavigate = (page: string, propertyId?: string) => {
    setCurrentPage(page);
    if (propertyId) {
      setCurrentPropertyId(propertyId);
    }
    // Scroll to top when navigating
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const renderCurrentPage = () => {
    switch (currentPage) {
      case 'home':
        return <HomePage onNavigate={handleNavigate} />;
      case 'listings':
        return <EnhancedListingsPage onNavigate={handleNavigate} />;
      case 'property-details':
        return currentPropertyId ? (
          <PropertyDetailsPage 
            propertyId={currentPropertyId} 
            onNavigate={handleNavigate} 
          />
        ) : (
          <HomePage onNavigate={handleNavigate} />
        );
      case 'submit':
        return <SubmitPropertyPage onNavigate={handleNavigate} />;
      case 'about':
        return <AboutPage onNavigate={handleNavigate} />;
      case 'contact':
        return <ContactPage onNavigate={handleNavigate} />;
      case 'dashboard':
        return <UserDashboard onNavigate={handleNavigate} />;
      case 'admin':
        return <AdminPanel onNavigate={handleNavigate} />;
      case 'verification':
        return <VerificationPage onNavigate={handleNavigate} />;
      case 'fiji-tenancy-agreement':
        return <FijiTenancyAgreement onNavigate={handleNavigate} />;
      case 'itaukei-land-info':
        return <ITaukeiLandInfo onNavigate={handleNavigate} />;
      case 'mpaisa-help':
        return <MPaisaHelp onNavigate={handleNavigate} />;
      default:
        return <HomePage onNavigate={handleNavigate} />;
    }
  };

  // Mobile Demo Mode
  if (showMobileDemo) {
    return (
      <AuthProvider>
        <div className="min-h-screen bg-gray-100">
          {/* Exit Mobile Demo Button */}
          <div className="fixed top-4 left-4 z-50">
            <button
              onClick={() => setShowMobileDemo(false)}
              className="bg-white text-gray-700 px-3 py-2 rounded-lg shadow-lg text-sm border"
            >
              ← Exit Mobile Demo
            </button>
          </div>
          
          {/* Mobile Demo Instructions */}
          <div className="text-center py-4 bg-tropical-green text-white">
            <div className="max-w-4xl mx-auto px-4">
              <h2 className="font-bold text-lg mb-2">📱 BulaRent Suva MVP Experience</h2>
              <p className="text-sm opacity-90">
                Ultra-local Suva rental search with landlord verification and M-PAiSA integration
              </p>
            </div>
          </div>

          {/* Mobile Demo Container */}
          <div className="flex justify-center py-8">
            <div className="bg-black p-6 rounded-3xl shadow-2xl">
              <div className="bg-white rounded-2xl overflow-hidden" style={{ width: '375px', height: '812px' }}>
                <MobileDemo />
              </div>
            </div>
          </div>

          {/* Suva MVP Features List */}
          <div className="max-w-4xl mx-auto px-4 pb-8">
            <div className="grid md:grid-cols-2 gap-6">
              <div className="bg-white p-6 rounded-lg shadow">
                <h3 className="font-bold text-lg mb-4 text-tropical-green">🏠 Suva-Focused Features</h3>
                <ul className="space-y-2 text-sm">
                  <li className="flex items-start">
                    <span className="bg-green-100 text-green-600 rounded-full p-1 mr-2 mt-1">✓</span>
                    Ultra-local search (Samabula, Nabua, Raiwaqa, Tamavua)
                  </li>
                  <li className="flex items-start">
                    <span className="bg-green-100 text-green-600 rounded-full p-1 mr-2 mt-1">✓</span>
                    Landmark proximity (USP, MHCC, Suva Market)
                  </li>
                  <li className="flex items-start">
                    <span className="bg-green-100 text-green-600 rounded-full p-1 mr-2 mt-1">✓</span>
                    Landlord verification with Fiji ID + video
                  </li>
                  <li className="flex items-start">
                    <span className="bg-green-100 text-green-600 rounded-full p-1 mr-2 mt-1">✓</span>
                    M-PAiSA payment integration
                  </li>
                  <li className="flex items-start">
                    <span className="bg-green-100 text-green-600 rounded-full p-1 mr-2 mt-1">✓</span>
                    Scam prevention & reporting
                  </li>
                  <li className="flex items-start">
                    <span className="bg-green-100 text-green-600 rounded-full p-1 mr-2 mt-1">✓</span>
                    Local terminology (Bure, Flat, etc.)
                  </li>
                </ul>
              </div>

              <div className="bg-white p-6 rounded-lg shadow">
                <h3 className="font-bold text-lg mb-4 text-fiji-orange">💰 Revenue Features</h3>
                <ul className="space-y-2 text-sm">
                  <li className="flex items-start">
                    <span className="bg-blue-100 text-blue-600 rounded-full p-1 mr-2 mt-1">$</span>
                    Verification Badge (FJD $10/month)
                  </li>
                  <li className="flex items-start">
                    <span className="bg-blue-100 text-blue-600 rounded-full p-1 mr-2 mt-1">$</span>
                    Listing Boost (FJD $5/week)
                  </li>
                  <li className="flex items-start">
                    <span className="bg-blue-100 text-blue-600 rounded-full p-1 mr-2 mt-1">$</span>
                    Tenant Screening (FJD $15/report)
                  </li>
                  <li className="flex items-start">
                    <span className="bg-blue-100 text-blue-600 rounded-full p-1 mr-2 mt-1">$</span>
                    Premium Dashboard Features
                  </li>
                  <li className="flex items-start">
                    <span className="bg-blue-100 text-blue-600 rounded-full p-1 mr-2 mt-1">$</span>
                    M-PAiSA transaction fees
                  </li>
                  <li className="flex items-start">
                    <span className="bg-blue-100 text-blue-600 rounded-full p-1 mr-2 mt-1">$</span>
                    Document e-signing services
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </AuthProvider>
    );
  }

  return (
    <AuthProvider>
      <div className="min-h-screen bg-white flex flex-col">
        <EnhancedNavigation currentPage={currentPage} onNavigate={handleNavigate} />
        
        {/* Mobile Demo Button */}
        <div className="fixed bottom-4 right-4 z-40">
          <button
            onClick={() => setShowMobileDemo(true)}
            className="bg-tropical-green text-white px-4 py-2 rounded-full shadow-lg hover:bg-green-600 transition-colors text-sm font-medium"
          >
            📱 Suva MVP Demo
          </button>
        </div>

        <main className="flex-grow">
          {renderCurrentPage()}
        </main>
        
        {/* Footer - Moved to bottom with disclaimer at top */}
        <footer className="bg-fiji-dark-blue text-white py-12 mt-auto">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            {/* Disclaimer at top of footer */}
            <div className="bg-red-600 text-white p-4 rounded-lg mb-8 border border-red-500">
              <div className="flex items-center justify-center gap-2 text-center">
                <span className="text-xl">🚨</span>
                <p className="font-semibold">
                  SECURITY ALERT: Never send deposits before viewing property in person. 
                  Report scams to Fiji Police Cyber Unit: 
                  <a href="tel:919" className="underline font-bold ml-1">📞 919</a>
                </p>
              </div>
            </div>

            {/* Critical Disclaimer */}
            <div className="bg-fiji-dark-blue border border-gray-600 p-4 rounded-lg mb-8">
              <p className="text-xs text-yellow-200 font-medium text-center">
                ⚠️ IMPORTANT DISCLAIMER: BulaRent is a platform connecting landlords and tenants. 
                We do not guarantee property availability or landlord legitimacy. 
                Always verify identity, inspect properties in person, and use official payment methods. 
                For iTaukei Land leases, consult the Ministry of Lands first.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
              {/* Company Info */}
              <div className="col-span-1 md:col-span-2">
                <div className="flex items-center mb-4">
                  <div className="bg-tropical-green text-white px-3 py-2 rounded-lg mr-3">
                    <span className="font-bold text-lg">BR</span>
                  </div>
                  <span className="text-xl font-bold">BulaRent</span>
                </div>
                <p className="text-gray-300 mb-4 max-w-md">
                  Suva's trusted rental platform connecting verified landlords with tenants. 
                  Find your perfect home in Samabula, Nabua, Raiwaqa, and surrounding areas.
                </p>
                <div className="flex space-x-4">
                  <a href="#" className="text-gray-300 hover:text-white transition-colors">
                    Facebook
                  </a>
                  <a href="#" className="text-gray-300 hover:text-white transition-colors">
                    Instagram
                  </a>
                  <a href="tel:+6797233406" className="text-gray-300 hover:text-white transition-colors">
                    📞 +679 7233406
                  </a>
                  <a href="mailto:Rehansikdar@gmail.com" className="text-gray-300 hover:text-white transition-colors">
                    ✉️ Rehansikdar@gmail.com
                  </a>
                </div>
              </div>
              
              {/* Quick Links */}
              <div>
                <h3 className="font-bold text-lg mb-4">Quick Access</h3>
                <ul className="space-y-2">
                  <li>
                    <button 
                      onClick={() => handleNavigate('home')}
                      className="text-gray-300 hover:text-white transition-colors"
                    >
                      Suva Rentals
                    </button>
                  </li>
                  <li>
                    <button 
                      onClick={() => handleNavigate('listings')}
                      className="text-gray-300 hover:text-white transition-colors"
                    >
                      Browse Properties
                    </button>
                  </li>
                  <li>
                    <button 
                      onClick={() => handleNavigate('submit')}
                      className="text-gray-300 hover:text-white transition-colors"
                    >
                      List Your Property
                    </button>
                  </li>
                  <li>
                    <button 
                      onClick={() => handleNavigate('verification')}
                      className="text-tropical-green hover:text-white transition-colors"
                    >
                      Get Verified Badge
                    </button>
                  </li>
                  <li>
                    <button 
                      onClick={() => setShowMobileDemo(true)}
                      className="text-tropical-green hover:text-white transition-colors"
                    >
                      📱 Suva MVP Demo
                    </button>
                  </li>
                </ul>
              </div>
              
              {/* Local Resources */}
              <div>
                <h3 className="font-bold text-lg mb-4">Local Resources</h3>
                <ul className="space-y-2 text-gray-300">
                  <li>
                    <button 
                      onClick={() => handleNavigate('fiji-tenancy-agreement')}
                      className="hover:text-white transition-colors text-left"
                    >
                      📋 Fiji Tenancy Agreement
                    </button>
                  </li>
                  <li>
                    <button 
                      onClick={() => handleNavigate('itaukei-land-info')}
                      className="hover:text-white transition-colors text-left"
                    >
                      🏝️ iTaukei Land Info
                    </button>
                  </li>
                  <li>
                    <button 
                      onClick={() => handleNavigate('mpaisa-help')}
                      className="hover:text-white transition-colors text-left"
                    >
                      📱 M-PAiSA Help
                    </button>
                  </li>
                  <li>
                    <a href="tel:919" className="hover:text-white transition-colors">
                      🚨 Report Scam (919)
                    </a>
                  </li>
                  <li className="text-sm text-gray-400 mt-3">
                    📍 Suva CBD, Viti Levu<br />
                    🏢 Near FNPF Tower
                  </li>
                </ul>
              </div>
            </div>
            
            {/* Legal Footer */}
            <div className="border-t border-gray-600 mt-8 pt-8">
              <div className="text-center text-gray-300 space-y-2">
                <p>&copy; 2025 BulaRent Suva MVP. All rights reserved. Made with ❤️ in Fiji.</p>
                <p className="text-sm">
                  Powered by Supabase • Built with React & Tailwind CSS • M-PAiSA Integration
                </p>
              </div>
            </div>
          </div>
        </footer>
      </div>
    </AuthProvider>
  );
}