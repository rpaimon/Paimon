import { Hono } from 'npm:hono';
import { cors } from 'npm:hono/cors';
import { logger } from 'npm:hono/logger';
import { createClient } from 'npm:@supabase/supabase-js@2';
import * as kv from './kv_store.tsx';

// Initialize Supabase client with service role key for server operations
const supabase = createClient(
  Deno.env.get('SUPABASE_URL') || 'https://demo.supabase.co',
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') || 'demo-key',
  {
    auth: {
      autoRefreshToken: false,
      persistSession: false
    }
  }
);

const app = new Hono();

// Middleware
app.use('*', cors({
  origin: ['http://localhost:5173', 'https://your-domain.com'], // Add your actual domain
  credentials: true,
}));
app.use('*', logger(console.log));

// Health check
app.get('/make-server-304c8b39/health', (c) => {
  return c.json({ 
    status: 'healthy', 
    timestamp: new Date().toISOString(),
    supabase_connected: !!Deno.env.get('SUPABASE_URL')
  });
});

// Auth endpoints
app.post('/make-server-304c8b39/auth/signup', async (c) => {
  try {
    const { email, password, userData } = await c.req.json();
    
    // Create user with admin API (auto-confirm email)
    const { data, error } = await supabase.auth.admin.createUser({
      email,
      password,
      user_metadata: userData,
      // Automatically confirm the user's email since an email server hasn't been configured.
      email_confirm: true
    });

    if (error) {
      console.log(`Signup error: ${error.message}`);
      return c.json({ error: error.message }, 400);
    }

    return c.json({ user: data.user });
  } catch (error) {
    console.log(`Signup error: ${error}`);
    return c.json({ error: 'Internal server error during signup' }, 500);
  }
});

app.post('/make-server-304c8b39/auth/verify-user', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    if (!accessToken) {
      return c.json({ error: 'No token provided' }, 401);
    }

    const { data: { user }, error } = await supabase.auth.getUser(accessToken);
    if (error || !user) {
      return c.json({ error: 'Invalid token' }, 401);
    }

    return c.json({ user });
  } catch (error) {
    console.log(`Token verification error: ${error}`);
    return c.json({ error: 'Token verification failed' }, 500);
  }
});

// Property management endpoints
app.post('/make-server-304c8b39/properties/submit', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    if (!accessToken) {
      return c.json({ error: 'Authentication required' }, 401);
    }

    const { data: { user }, error: authError } = await supabase.auth.getUser(accessToken);
    if (authError || !user) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const propertyData = await c.req.json();
    
    // Store property in KV store with pending approval status
    const propertyId = `property_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    await kv.set(propertyId, {
      ...propertyData,
      id: propertyId,
      ownerId: user.id,
      ownerEmail: user.email,
      status: 'pending_approval',
      submittedAt: new Date().toISOString(),
      approvedAt: null,
      adminNotes: ''
    });

    // Also store in user's property list
    const userPropertiesKey = `user_properties_${user.id}`;
    const existingProperties = await kv.get(userPropertiesKey) || [];
    await kv.set(userPropertiesKey, [...existingProperties, propertyId]);

    return c.json({ 
      success: true, 
      propertyId,
      message: 'Property submitted for admin approval' 
    });
  } catch (error) {
    console.log(`Property submission error: ${error}`);
    return c.json({ error: 'Failed to submit property' }, 500);
  }
});

app.get('/make-server-304c8b39/properties/list', async (c) => {
  try {
    // Get approved properties
    const allProperties = await kv.getByPrefix('property_');
    const approvedProperties = allProperties
      .filter(item => item.value.status === 'approved')
      .map(item => item.value);

    return c.json({ properties: approvedProperties });
  } catch (error) {
    console.log(`Property listing error: ${error}`);
    return c.json({ error: 'Failed to fetch properties' }, 500);
  }
});

app.get('/make-server-304c8b39/properties/:id', async (c) => {
  try {
    const propertyId = c.req.param('id');
    const property = await kv.get(propertyId);
    
    if (!property) {
      return c.json({ error: 'Property not found' }, 404);
    }

    return c.json({ property });
  } catch (error) {
    console.log(`Property fetch error: ${error}`);
    return c.json({ error: 'Failed to fetch property' }, 500);
  }
});

// User dashboard endpoints
app.get('/make-server-304c8b39/user/properties', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    if (!accessToken) {
      return c.json({ error: 'Authentication required' }, 401);
    }

    const { data: { user }, error: authError } = await supabase.auth.getUser(accessToken);
    if (authError || !user) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const userPropertiesKey = `user_properties_${user.id}`;
    const propertyIds = await kv.get(userPropertiesKey) || [];
    
    const properties = [];
    for (const propertyId of propertyIds) {
      const property = await kv.get(propertyId);
      if (property) {
        properties.push(property);
      }
    }

    return c.json({ properties });
  } catch (error) {
    console.log(`User properties fetch error: ${error}`);
    return c.json({ error: 'Failed to fetch user properties' }, 500);
  }
});

// Admin endpoints
app.get('/make-server-304c8b39/admin/properties/pending', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    if (!accessToken) {
      return c.json({ error: 'Authentication required' }, 401);
    }

    const { data: { user }, error: authError } = await supabase.auth.getUser(accessToken);
    if (authError || !user) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    // Check if user is admin (you can store admin status in user metadata)
    const isAdmin = user.user_metadata?.role === 'admin' || user.email === 'Rehansikdar@gmail.com';
    if (!isAdmin) {
      return c.json({ error: 'Admin access required' }, 403);
    }

    const allProperties = await kv.getByPrefix('property_');
    const pendingProperties = allProperties
      .filter(item => item.value.status === 'pending_approval')
      .map(item => item.value);

    return c.json({ properties: pendingProperties });
  } catch (error) {
    console.log(`Admin properties fetch error: ${error}`);
    return c.json({ error: 'Failed to fetch pending properties' }, 500);
  }
});

app.post('/make-server-304c8b39/admin/properties/:id/approve', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    if (!accessToken) {
      return c.json({ error: 'Authentication required' }, 401);
    }

    const { data: { user }, error: authError } = await supabase.auth.getUser(accessToken);
    if (authError || !user) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const isAdmin = user.user_metadata?.role === 'admin' || user.email === 'Rehansikdar@gmail.com';
    if (!isAdmin) {
      return c.json({ error: 'Admin access required' }, 403);
    }

    const propertyId = c.req.param('id');
    const { adminNotes } = await c.req.json();
    
    const property = await kv.get(propertyId);
    if (!property) {
      return c.json({ error: 'Property not found' }, 404);
    }

    // Update property status
    await kv.set(propertyId, {
      ...property,
      status: 'approved',
      approvedAt: new Date().toISOString(),
      approvedBy: user.id,
      adminNotes: adminNotes || ''
    });

    return c.json({ success: true, message: 'Property approved successfully' });
  } catch (error) {
    console.log(`Property approval error: ${error}`);
    return c.json({ error: 'Failed to approve property' }, 500);
  }
});

app.post('/make-server-304c8b39/admin/properties/:id/reject', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    if (!accessToken) {
      return c.json({ error: 'Authentication required' }, 401);
    }

    const { data: { user }, error: authError } = await supabase.auth.getUser(accessToken);
    if (authError || !user) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const isAdmin = user.user_metadata?.role === 'admin' || user.email === 'Rehansikdar@gmail.com';
    if (!isAdmin) {
      return c.json({ error: 'Admin access required' }, 403);
    }

    const propertyId = c.req.param('id');
    const { rejectionReason } = await c.req.json();
    
    const property = await kv.get(propertyId);
    if (!property) {
      return c.json({ error: 'Property not found' }, 404);
    }

    // Update property status
    await kv.set(propertyId, {
      ...property,
      status: 'rejected',
      rejectedAt: new Date().toISOString(),
      rejectedBy: user.id,
      rejectionReason: rejectionReason || 'No reason provided'
    });

    return c.json({ success: true, message: 'Property rejected' });
  } catch (error) {
    console.log(`Property rejection error: ${error}`);
    return c.json({ error: 'Failed to reject property' }, 500);
  }
});

// User profile endpoints
app.get('/make-server-304c8b39/user/profile', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    if (!accessToken) {
      return c.json({ error: 'Authentication required' }, 401);
    }

    const { data: { user }, error: authError } = await supabase.auth.getUser(accessToken);
    if (authError || !user) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    // Get additional profile data from KV store
    const profileKey = `profile_${user.id}`;
    const profileData = await kv.get(profileKey) || {};

    return c.json({ 
      user: {
        ...user,
        profile: profileData
      }
    });
  } catch (error) {
    console.log(`Profile fetch error: ${error}`);
    return c.json({ error: 'Failed to fetch profile' }, 500);
  }
});

app.post('/make-server-304c8b39/user/profile', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    if (!accessToken) {
      return c.json({ error: 'Authentication required' }, 401);
    }

    const { data: { user }, error: authError } = await supabase.auth.getUser(accessToken);
    if (authError || !user) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const profileData = await c.req.json();
    const profileKey = `profile_${user.id}`;
    
    await kv.set(profileKey, {
      ...profileData,
      updatedAt: new Date().toISOString()
    });

    return c.json({ success: true, message: 'Profile updated successfully' });
  } catch (error) {
    console.log(`Profile update error: ${error}`);
    return c.json({ error: 'Failed to update profile' }, 500);
  }
});

// Start server
Deno.serve(app.fetch);