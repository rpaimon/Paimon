import { useState } from 'react';
import { Search, Heart, MapPin, Star, Phone, MessageSquare, Filter, ArrowLeft, Menu } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Badge } from './ui/badge';

export default function MobileDemo() {
  const [currentView, setCurrentView] = useState('home');
  const [searchTerm, setSearchTerm] = useState('');

  // Sample properties for demo
  const sampleProperties = [
    {
      id: '1',
      title: 'Modern Flat near USP',
      location: 'Laucala Bay',
      price: 'FJD $280/week',
      image: 'https://images.unsplash.com/photo-1522708323590-d24dbb6b0267?w=400&h=250&fit=crop',
      bedrooms: 2,
      bathrooms: 1,
      verified: true,
      rating: 4.8
    },
    {
      id: '2',
      title: 'Traditional Bure in Tamavua',
      location: 'Tamavua Heights',
      price: 'FJD $220/week',
      image: 'https://images.unsplash.com/photo-1571003123894-1f0594d2b5d9?w=400&h=250&fit=crop',
      bedrooms: 3,
      bathrooms: 2,
      verified: true,
      rating: 4.6
    },
    {
      id: '3',
      title: 'Student Room near FNU',
      location: 'Samabula',
      price: 'FJD $120/week',
      image: 'https://images.unsplash.com/photo-1584132915807-fd1f5fbc078f?w=400&h=250&fit=crop',
      bedrooms: 1,
      bathrooms: 1,
      verified: false,
      rating: 4.2
    }
  ];

  const renderHeader = () => (
    <div className="bg-tropical-green text-white p-4 safe-area-top">
      <div className="flex items-center justify-between">
        {currentView !== 'home' && (
          <button onClick={() => setCurrentView('home')} className="p-2">
            <ArrowLeft size={20} />
          </button>
        )}
        <div className="flex items-center gap-2">
          <div className="bg-white text-tropical-green p-1 rounded font-bold text-sm">BR</div>
          <span className="font-bold">BulaRent</span>
        </div>
        <button className="p-2">
          <Menu size={20} />
        </button>
      </div>
    </div>
  );

  const renderSearch = () => (
    <div className="p-4 bg-white border-b">
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
        <Input
          placeholder="Search Suva properties..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="pl-10 pr-12 py-3 rounded-full border-2 border-gray-200 focus:border-tropical-green"
        />
        <button className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400">
          <Filter size={18} />
        </button>
      </div>
    </div>
  );

  const renderPropertyCard = (property: any) => (
    <div
      key={property.id}
      className="bg-white border-b border-gray-100 mobile-list-item"
      onClick={() => setCurrentView('property')}
    >
      <div className="p-4">
        <div className="flex gap-3">
          <div className="relative flex-shrink-0">
            <img
              src={property.image}
              alt={property.title}
              className="w-20 h-20 rounded-lg object-cover"
            />
            {property.verified && (
              <Badge className="absolute -top-1 -right-1 verified-badge text-xs px-1 py-0">
                ✓
              </Badge>
            )}
          </div>
          
          <div className="flex-1 min-w-0">
            <h3 className="font-medium text-gray-900 line-clamp-1 mb-1">
              {property.title}
            </h3>
            
            <div className="flex items-center gap-1 text-gray-600 text-sm mb-2">
              <MapPin size={12} />
              <span className="line-clamp-1">{property.location}</span>
            </div>
            
            <div className="flex items-center justify-between">
              <div className="font-bold text-tropical-green">{property.price}</div>
              <div className="flex items-center gap-1 text-yellow-500 text-sm">
                <Star size={12} className="fill-current" />
                <span>{property.rating}</span>
              </div>
            </div>
            
            <div className="flex items-center gap-4 mt-2 text-gray-500 text-xs">
              <span>{property.bedrooms} bed</span>
              <span>{property.bathrooms} bath</span>
              <div className="flex gap-1 ml-auto">
                <button className="p-1 hover:bg-gray-100 rounded">
                  <Heart size={14} />
                </button>
                <button className="p-1 hover:bg-gray-100 rounded">
                  <Phone size={14} />
                </button>
                <button className="p-1 hover:bg-gray-100 rounded">
                  <MessageSquare size={14} />
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );

  const renderQuickFilters = () => (
    <div className="p-4 bg-gray-50">
      <div className="flex gap-2 overflow-x-auto scrollbar-hide">
        {[
          { label: 'Near USP', emoji: '🎓' },
          { label: 'Under $200', emoji: '💰' },
          { label: 'Furnished', emoji: '🏠' },
          { label: 'M-PAiSA', emoji: '💳' },
          { label: 'Verified', emoji: '✅' }
        ].map((filter, index) => (
          <button
            key={index}
            className="flex items-center gap-1 bg-white px-3 py-2 rounded-full text-sm border flex-shrink-0 hover:border-tropical-green transition-colors"
          >
            <span>{filter.emoji}</span>
            <span>{filter.label}</span>
          </button>
        ))}
      </div>
    </div>
  );

  const renderPropertyDetails = () => (
    <div className="flex flex-col h-full bg-white">
      {renderHeader()}
      
      <div className="flex-1 overflow-y-auto">
        {/* Property Image */}
        <div className="relative">
          <img
            src="https://images.unsplash.com/photo-1522708323590-d24dbb6b0267?w=800&h=400&fit=crop"
            alt="Property"
            className="w-full h-48 object-cover"
          />
          <button className="absolute top-4 right-4 bg-black/50 text-white p-2 rounded-full">
            <Heart size={16} />
          </button>
        </div>

        <div className="p-4">
          <div className="flex items-start justify-between mb-3">
            <div>
              <h1 className="font-bold text-lg mb-1">Modern Flat near USP</h1>
              <div className="flex items-center gap-1 text-gray-600">
                <MapPin size={14} />
                <span>Laucala Bay • 500m from USP</span>
              </div>
            </div>
            <Badge className="verified-badge">Verified</Badge>
          </div>

          <div className="text-2xl font-bold text-tropical-green mb-4">FJD $280/week</div>

          <div className="grid grid-cols-3 gap-4 mb-4 text-center">
            <div className="bg-gray-50 p-3 rounded-lg">
              <div className="font-bold">2</div>
              <div className="text-xs text-gray-600">Bedrooms</div>
            </div>
            <div className="bg-gray-50 p-3 rounded-lg">
              <div className="font-bold">1</div>
              <div className="text-xs text-gray-600">Bathroom</div>
            </div>
            <div className="bg-gray-50 p-3 rounded-lg">
              <div className="font-bold">1</div>
              <div className="text-xs text-gray-600">Parking</div>
            </div>
          </div>

          <div className="mb-4">
            <h3 className="font-medium mb-2">Features</h3>
            <div className="flex flex-wrap gap-2">
              {['WiFi Included', 'Furnished', 'M-PAiSA Accepted', 'Student Friendly'].map((feature) => (
                <span key={feature} className="bg-green-100 text-green-700 px-2 py-1 rounded-full text-xs">
                  {feature}
                </span>
              ))}
            </div>
          </div>

          <div className="mb-4">
            <h3 className="font-medium mb-2">Description</h3>
            <p className="text-gray-600 text-sm leading-relaxed">
              Perfect for students! Walking distance to USP, this modern flat comes fully furnished 
              with WiFi included. Great for shared living with separate bedrooms and common areas.
            </p>
          </div>

          <div className="border-t pt-4">
            <h3 className="font-medium mb-3">Contact Landlord</h3>
            <div className="bg-yellow-50 border border-yellow-200 p-3 rounded-lg mb-3">
              <p className="text-yellow-800 text-xs">
                🔒 Sign in to view contact information and send messages
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Action Bar */}
      <div className="border-t bg-white p-4 safe-area-bottom">
        <div className="flex gap-3">
          <Button variant="outline" className="flex-1">
            <Heart size={16} className="mr-2" />
            Save
          </Button>
          <Button className="flex-1 bg-tropical-green text-white">
            <MessageSquare size={16} className="mr-2" />
            Contact
          </Button>
        </div>
      </div>
    </div>
  );

  const renderHome = () => (
    <div className="flex flex-col h-full bg-gray-50">
      {renderHeader()}
      {renderSearch()}
      {renderQuickFilters()}
      
      <div className="flex-1 overflow-y-auto">
        <div className="bg-white">
          <div className="p-4 border-b">
            <h2 className="font-bold text-lg">Properties in Suva</h2>
            <p className="text-gray-600 text-sm">{sampleProperties.length} properties found</p>
          </div>
          
          {sampleProperties.map(renderPropertyCard)}
        </div>
      </div>

      {/* Bottom Navigation */}
      <div className="border-t bg-white p-2 safe-area-bottom">
        <div className="flex justify-around">
          {[
            { icon: Search, label: 'Search', active: true },
            { icon: Heart, label: 'Saved' },
            { icon: MessageSquare, label: 'Messages' },
            { icon: Phone, label: 'Contact' }
          ].map((item, index) => (
            <button
              key={index}
              className={`flex flex-col items-center p-2 touch-target ${
                item.active ? 'text-tropical-green' : 'text-gray-400'
              }`}
            >
              <item.icon size={20} />
              <span className="text-xs mt-1">{item.label}</span>
            </button>
          ))}
        </div>
      </div>
    </div>
  );

  if (currentView === 'property') {
    return renderPropertyDetails();
  }

  return renderHome();
}