import { useState } from 'react';
import { Search, MapPin, Bath, Bed, Car, Filter, Heart } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface ListingsPageProps {
  onNavigate: (page: string) => void;
}

export default function ListingsPage({ onNavigate }: ListingsPageProps) {
  const [searchLocation, setSearchLocation] = useState('');
  const [priceRange, setPriceRange] = useState('');
  const [propertyType, setPropertyType] = useState('');
  const [bedrooms, setBedrooms] = useState('');
  const [showFilters, setShowFilters] = useState(false);
  const [favorites, setFavorites] = useState<number[]>([]);

  const allListings = [
    {
      id: 1,
      title: 'Oceanfront Villa in Pacific Harbour',
      location: 'Pacific Harbour, Viti Levu',
      price: 'FJ$2,800',
      period: 'per month',
      bedrooms: 3,
      bathrooms: 2,
      parking: 2,
      type: 'Villa',
      image: 'https://images.unsplash.com/photo-1613490493576-7fde63acd811?w=500&h=300&fit=crop',
      description: 'Stunning oceanfront villa with private beach access and panoramic views of the Pacific Ocean.',
      features: ['Ocean View', 'Private Beach', 'Swimming Pool', 'Garden']
    },
    {
      id: 2,
      title: 'Modern Apartment in Suva City',
      location: 'Suva Central, Viti Levu',
      price: 'FJ$1,200',
      period: 'per month',
      bedrooms: 2,
      bathrooms: 1,
      parking: 1,
      type: 'Apartment',
      image: 'https://images.unsplash.com/photo-1522708323590-d24dbb6b0267?w=500&h=300&fit=crop',
      description: 'Contemporary apartment in the heart of Suva with city views and modern amenities.',
      features: ['City View', 'Air Conditioning', 'Balcony', 'Gym Access']
    },
    {
      id: 3,
      title: 'Traditional Bure near Coral Coast',
      location: 'Coral Coast, Viti Levu',
      price: 'FJ$800',
      period: 'per month',
      bedrooms: 2,
      bathrooms: 1,
      parking: 1,
      type: 'Bure',
      image: 'https://images.unsplash.com/photo-1571003123894-1f0594d2b5d9?w=500&h=300&fit=crop',
      description: 'Authentic Fijian bure with thatched roof, close to beautiful beaches and resorts.',
      features: ['Traditional Design', 'Thatched Roof', 'Beach Access', 'Quiet Location']
    },
    {
      id: 4,
      title: 'Family Home in Lautoka',
      location: 'Lautoka, Viti Levu',
      price: 'FJ$1,500',
      period: 'per month',
      bedrooms: 4,
      bathrooms: 2,
      parking: 2,
      type: 'House',
      image: 'https://images.unsplash.com/photo-1580587771525-78b9dba3b914?w=500&h=300&fit=crop',
      description: 'Spacious family home with garden, perfect for families with children.',
      features: ['Large Garden', 'Children Playground', 'Security System', 'Storage']
    },
    {
      id: 5,
      title: 'Beachside Cottage in Nadi',
      location: 'Nadi, Viti Levu',
      price: 'FJ$1,800',
      period: 'per month',
      bedrooms: 2,
      bathrooms: 2,
      parking: 1,
      type: 'Cottage',
      image: 'https://images.unsplash.com/photo-1499793983690-e29da59ef1c2?w=500&h=300&fit=crop',
      description: 'Charming beachside cottage with tropical garden and easy airport access.',
      features: ['Beach Access', 'Tropical Garden', 'Airport Nearby', 'WiFi']
    },
    {
      id: 6,
      title: 'Hilltop House with Valley Views',
      location: 'Ba, Viti Levu',
      price: 'FJ$1,000',
      period: 'per month',
      bedrooms: 3,
      bathrooms: 1,
      parking: 2,
      type: 'House',
      image: 'https://images.unsplash.com/photo-1564013799919-ab600027ffc6?w=500&h=300&fit=crop',
      description: 'Peaceful hilltop location with stunning valley views and cool mountain air.',
      features: ['Mountain Views', 'Cool Climate', 'Large Deck', 'Fruit Trees']
    },
    {
      id: 7,
      title: 'Luxury Penthouse Suva Harbour',
      location: 'Suva Harbour, Viti Levu',
      price: 'FJ$3,500',
      period: 'per month',
      bedrooms: 3,
      bathrooms: 3,
      parking: 2,
      type: 'Penthouse',
      image: 'https://images.unsplash.com/photo-1545324418-cc1a3fa10c00?w=500&h=300&fit=crop',
      description: 'Luxury penthouse with panoramic harbour views and premium finishes.',
      features: ['Harbour View', 'Luxury Finishes', 'Rooftop Terrace', 'Concierge']
    },
    {
      id: 8,
      title: 'Cozy Studio in Nausori',
      location: 'Nausori, Viti Levu',
      price: 'FJ$600',
      period: 'per month',
      bedrooms: 1,
      bathrooms: 1,
      parking: 1,
      type: 'Studio',
      image: 'https://images.unsplash.com/photo-1484154218962-a197022b5858?w=500&h=300&fit=crop',
      description: 'Perfect studio apartment for young professionals or students.',
      features: ['Compact Design', 'Modern Kitchen', 'Study Area', 'Transport Links']
    },
    {
      id: 9,
      title: 'Riverfront Property in Rewa',
      location: 'Rewa, Viti Levu',
      price: 'FJ$1,100',
      period: 'per month',
      bedrooms: 2,
      bathrooms: 2,
      parking: 1,
      type: 'House',
      image: 'https://images.unsplash.com/photo-1449824913935-59a10b8d2000?w=500&h=300&fit=crop',
      description: 'Beautiful property alongside the Rewa River with fishing opportunities.',
      features: ['River Access', 'Fishing Spot', 'Peaceful', 'Boat Dock']
    }
  ];

  const toggleFavorite = (id: number) => {
    setFavorites(prev => 
      prev.includes(id) 
        ? prev.filter(fav => fav !== id)
        : [...prev, id]
    );
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Page Header */}
        <div className="text-center mb-8">
          <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Available Rental Properties
          </h1>
          <p className="text-lg text-gray-600">
            Browse through {allListings.length} beautiful properties across Fiji
          </p>
        </div>

        {/* Search and Filters */}
        <div className="bg-white rounded-lg shadow-lg p-6 mb-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div>
              <label className="block text-gray-700 mb-2">Location</label>
              <div className="relative">
                <MapPin className="absolute left-3 top-3 text-gray-400" size={20} />
                <input
                  type="text"
                  placeholder="Enter location..."
                  value={searchLocation}
                  onChange={(e) => setSearchLocation(e.target.value)}
                  className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-ocean-blue focus:border-transparent"
                />
              </div>
            </div>
            
            <div>
              <label className="block text-gray-700 mb-2">Price Range</label>
              <select
                value={priceRange}
                onChange={(e) => setPriceRange(e.target.value)}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-ocean-blue focus:border-transparent"
              >
                <option value="">Any Price</option>
                <option value="0-800">FJ$0 - FJ$800</option>
                <option value="800-1500">FJ$800 - FJ$1,500</option>
                <option value="1500-2500">FJ$1,500 - FJ$2,500</option>
                <option value="2500+">FJ$2,500+</option>
              </select>
            </div>
            
            <div>
              <label className="block text-gray-700 mb-2">Property Type</label>
              <select
                value={propertyType}
                onChange={(e) => setPropertyType(e.target.value)}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-ocean-blue focus:border-transparent"
              >
                <option value="">All Types</option>
                <option value="House">House</option>
                <option value="Apartment">Apartment</option>
                <option value="Villa">Villa</option>
                <option value="Bure">Bure</option>
                <option value="Cottage">Cottage</option>
                <option value="Studio">Studio</option>
                <option value="Penthouse">Penthouse</option>
              </select>
            </div>
            
            <div>
              <label className="block text-gray-700 mb-2">Bedrooms</label>
              <select
                value={bedrooms}
                onChange={(e) => setBedrooms(e.target.value)}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-ocean-blue focus:border-transparent"
              >
                <option value="">Any</option>
                <option value="1">1 Bedroom</option>
                <option value="2">2 Bedrooms</option>
                <option value="3">3 Bedrooms</option>
                <option value="4+">4+ Bedrooms</option>
              </select>
            </div>
          </div>
          
          <div className="flex justify-between items-center mt-6">
            <button
              onClick={() => setShowFilters(!showFilters)}
              className="flex items-center gap-2 text-ocean-blue hover:text-deep-blue"
            >
              <Filter size={20} />
              {showFilters ? 'Hide Filters' : 'More Filters'}
            </button>
            
            <button className="bg-ocean-blue hover:bg-deep-blue text-white px-6 py-2 rounded-lg transition-colors duration-300 flex items-center gap-2">
              <Search size={20} />
              Search Properties
            </button>
          </div>
        </div>

        {/* Properties Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {allListings.map((listing) => (
            <div
              key={listing.id}
              className="bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-2xl transition-shadow duration-300 group"
            >
              <div className="relative overflow-hidden">
                <ImageWithFallback
                  src={listing.image}
                  alt={listing.title}
                  className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300"
                />
                <div className="absolute top-4 left-4 bg-ocean-blue text-white px-2 py-1 rounded text-sm">
                  {listing.type}
                </div>
                <div className="absolute top-4 right-4 bg-coral text-white px-3 py-1 rounded-full">
                  {listing.price} <span className="text-xs">{listing.period}</span>
                </div>
                <button
                  onClick={() => toggleFavorite(listing.id)}
                  className="absolute bottom-4 right-4 bg-white bg-opacity-80 hover:bg-opacity-100 rounded-full p-2 transition-all duration-300"
                >
                  <Heart 
                    size={20} 
                    className={favorites.includes(listing.id) ? 'text-red-500 fill-current' : 'text-gray-600'}
                  />
                </button>
              </div>
              
              <div className="p-6">
                <h3 className="font-bold text-lg text-gray-900 mb-2 group-hover:text-ocean-blue transition-colors">
                  {listing.title}
                </h3>
                <div className="flex items-center text-gray-600 mb-3">
                  <MapPin size={16} className="mr-1" />
                  <span className="text-sm">{listing.location}</span>
                </div>
                
                <p className="text-gray-600 mb-4 text-sm">
                  {listing.description}
                </p>
                
                <div className="flex items-center justify-between text-sm text-gray-500 mb-4">
                  <div className="flex items-center gap-4">
                    <div className="flex items-center gap-1">
                      <Bed size={16} />
                      <span>{listing.bedrooms}</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <Bath size={16} />
                      <span>{listing.bathrooms}</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <Car size={16} />
                      <span>{listing.parking}</span>
                    </div>
                  </div>
                </div>
                
                <div className="flex flex-wrap gap-2 mb-4">
                  {listing.features.slice(0, 3).map((feature, index) => (
                    <span 
                      key={index}
                      className="bg-sand-beige text-ocean-blue px-2 py-1 rounded text-xs"
                    >
                      {feature}
                    </span>
                  ))}
                </div>
                
                <button className="w-full bg-tropical-green hover:bg-green-600 text-white py-2 rounded-lg transition-colors duration-300">
                  View Details
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* Pagination */}
        <div className="flex justify-center mt-12">
          <div className="flex gap-2">
            <button className="px-4 py-2 bg-ocean-blue text-white rounded-lg hover:bg-deep-blue transition-colors">
              1
            </button>
            <button className="px-4 py-2 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300 transition-colors">
              2
            </button>
            <button className="px-4 py-2 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300 transition-colors">
              3
            </button>
            <button className="px-4 py-2 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300 transition-colors">
              Next
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}