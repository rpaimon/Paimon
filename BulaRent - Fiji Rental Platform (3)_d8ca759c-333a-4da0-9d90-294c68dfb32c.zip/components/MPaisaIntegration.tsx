import { useState } from 'react';
import { CreditCard, Shield, CheckCircle, AlertCircle, Phone, Copy } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Card, CardContent } from './ui/card';
import { Badge } from './ui/badge';

interface MPaisaIntegrationProps {
  propertyTitle: string;
  landlordName: string;
  depositAmount: number;
  onPaymentComplete: (transactionData: TransactionData) => void;
  onClose?: () => void;
}

interface TransactionData {
  transactionId: string;
  amount: number;
  senderNumber: string;
  receiverNumber: string;
  status: 'pending' | 'completed' | 'failed';
  timestamp: string;
}

export default function MPaisaIntegration({
  propertyTitle,
  landlordName,
  depositAmount,
  onPaymentComplete,
  onClose
}: MPaisaIntegrationProps) {
  const [currentStep, setCurrentStep] = useState(1);
  const [paymentData, setPaymentData] = useState({
    senderNumber: '',
    confirmationCode: '',
    transactionId: ''
  });
  const [isProcessing, setIsProcessing] = useState(false);
  const [generatedTransactionId] = useState(() => 
    `BULARENT${Date.now()}${Math.floor(Math.random() * 1000)}`
  );

  // Mock landlord M-PAiSA number (in real app, this would come from verified profile)
  const landlordMPaisaNumber = '+679 123 4567';

  const handleInputChange = (field: string, value: string) => {
    setPaymentData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const processPayment = async () => {
    setIsProcessing(true);
    
    // Simulate payment processing
    setTimeout(() => {
      const transactionData: TransactionData = {
        transactionId: generatedTransactionId,
        amount: depositAmount,
        senderNumber: paymentData.senderNumber,
        receiverNumber: landlordMPaisaNumber,
        status: 'completed',
        timestamp: new Date().toISOString()
      };
      
      setIsProcessing(false);
      setCurrentStep(3);
      onPaymentComplete(transactionData);
      
      // Send SMS receipts (simulated)
      sendSMSReceipts(transactionData);
    }, 3000);
  };

  const sendSMSReceipts = (transaction: TransactionData) => {
    // In real implementation, this would trigger SMS via Fiji telecom APIs
    console.log('SMS sent to tenant:', transaction.senderNumber);
    console.log('SMS sent to landlord:', transaction.receiverNumber);
  };

  const copyTransactionId = () => {
    navigator.clipboard.writeText(generatedTransactionId);
    alert('Transaction ID copied to clipboard');
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-FJ', {
      style: 'currency',
      currency: 'FJD'
    }).format(amount);
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <Card className="w-full max-w-md max-h-[90vh] overflow-y-auto">
        <CardContent className="p-6">
          {/* Header */}
          <div className="flex justify-between items-center mb-6">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 bg-gradient-to-r from-purple-600 to-purple-700 rounded-lg flex items-center justify-center">
                <CreditCard className="text-white" size={16} />
              </div>
              <h2 className="text-xl font-bold text-gray-900">
                M-PAiSA Payment
              </h2>
            </div>
            {onClose && (
              <button 
                onClick={onClose} 
                className="text-gray-400 hover:text-gray-600"
                disabled={isProcessing}
              >
                ✕
              </button>
            )}
          </div>

          {/* Property Info */}
          <div className="bg-fiji-light-blue p-4 rounded-lg mb-6">
            <h3 className="font-semibold text-fiji-dark-blue mb-2">Payment Details</h3>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span>Property:</span>
                <span className="font-medium">{propertyTitle}</span>
              </div>
              <div className="flex justify-between">
                <span>Landlord:</span>
                <span className="font-medium">{landlordName}</span>
              </div>
              <div className="flex justify-between">
                <span>Deposit Amount:</span>
                <span className="font-bold text-lg text-fiji-orange">
                  {formatCurrency(depositAmount)}
                </span>
              </div>
              <div className="flex justify-between">
                <span>Transaction ID:</span>
                <div className="flex items-center gap-2">
                  <span className="font-mono text-xs">{generatedTransactionId}</span>
                  <button 
                    onClick={copyTransactionId}
                    className="text-fiji-blue hover:text-fiji-dark-blue"
                  >
                    <Copy size={12} />
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* Step 1: Payment Instructions */}
          {currentStep === 1 && (
            <div className="space-y-4">
              <h3 className="font-semibold text-gray-900 mb-4">
                M-PAiSA Payment Instructions
              </h3>

              <div className="bg-gradient-to-r from-purple-50 to-purple-100 p-4 rounded-lg border border-purple-200">
                <h4 className="font-semibold text-purple-800 mb-3">
                  📱 Follow these steps in your M-PAiSA app:
                </h4>
                <ol className="text-sm text-purple-700 space-y-2">
                  <li>1. Open M-PAiSA app on your phone</li>
                  <li>2. Select "Send Money"</li>
                  <li>3. Enter recipient: <strong>{landlordMPaisaNumber}</strong></li>
                  <li>4. Amount: <strong>{formatCurrency(depositAmount)}</strong></li>
                  <li>5. Reference: <strong>{generatedTransactionId}</strong></li>
                  <li>6. Complete the transaction</li>
                </ol>
              </div>

              <div className="bg-yellow-50 border-l-4 border-yellow-400 p-3">
                <div className="flex items-start">
                  <AlertCircle className="text-yellow-400 mr-2 mt-0.5" size={16} />
                  <div>
                    <p className="text-sm text-yellow-700 font-medium">
                      Important: Use the exact Transaction ID as reference
                    </p>
                    <p className="text-xs text-yellow-600 mt-1">
                      This helps us track your payment automatically
                    </p>
                  </div>
                </div>
              </div>

              <Button
                onClick={() => setCurrentStep(2)}
                className="w-full mpaisa-button"
              >
                I've Completed the M-PAiSA Transfer
              </Button>
            </div>
          )}

          {/* Step 2: Confirmation */}
          {currentStep === 2 && (
            <div className="space-y-4">
              <h3 className="font-semibold text-gray-900 mb-4">
                Confirm Your Payment
              </h3>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Your M-PAiSA Number *
                </label>
                <div className="flex">
                  <span className="inline-flex items-center px-3 rounded-l-lg border border-r-0 border-gray-300 bg-gray-50 text-gray-500 text-sm">
                    +679
                  </span>
                  <Input
                    type="tel"
                    placeholder="123 4567"
                    value={paymentData.senderNumber}
                    onChange={(e) => handleInputChange('senderNumber', e.target.value)}
                    className="flex-1 rounded-l-none"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  M-PAiSA Confirmation Code (Optional)
                </label>
                <Input
                  type="text"
                  placeholder="e.g., MP123456789"
                  value={paymentData.confirmationCode}
                  onChange={(e) => handleInputChange('confirmationCode', e.target.value)}
                  className="w-full"
                />
                <p className="text-xs text-gray-500 mt-1">
                  The confirmation code from your M-PAiSA receipt SMS
                </p>
              </div>

              <div className="bg-green-50 border-l-4 border-green-400 p-3">
                <div className="flex items-start">
                  <CheckCircle className="text-green-400 mr-2 mt-0.5" size={16} />
                  <div>
                    <p className="text-sm text-green-700 font-medium">
                      Secure Payment Processing
                    </p>
                    <p className="text-xs text-green-600 mt-1">
                      Your payment will be verified automatically within 5 minutes
                    </p>
                  </div>
                </div>
              </div>

              <div className="flex gap-3">
                <Button
                  variant="outline"
                  onClick={() => setCurrentStep(1)}
                  className="flex-1"
                  disabled={isProcessing}
                >
                  Back
                </Button>
                <Button
                  onClick={processPayment}
                  disabled={!paymentData.senderNumber || isProcessing}
                  className="flex-1 mpaisa-button"
                >
                  {isProcessing ? (
                    <span className="flex items-center gap-2">
                      <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                      Verifying...
                    </span>
                  ) : (
                    'Verify Payment'
                  )}
                </Button>
              </div>
            </div>
          )}

          {/* Step 3: Success */}
          {currentStep === 3 && (
            <div className="text-center space-y-4">
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto">
                <CheckCircle className="text-green-600" size={32} />
              </div>

              <h3 className="text-xl font-bold text-gray-900">
                Payment Successful! 🎉
              </h3>

              <div className="bg-green-50 p-4 rounded-lg text-left">
                <h4 className="font-semibold text-green-800 mb-2">Payment Receipt:</h4>
                <div className="space-y-1 text-sm text-green-700">
                  <div className="flex justify-between">
                    <span>Transaction ID:</span>
                    <span className="font-mono">{generatedTransactionId}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Amount:</span>
                    <span className="font-bold">{formatCurrency(depositAmount)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Status:</span>
                    <Badge className="verified-badge">Completed</Badge>
                  </div>
                </div>
              </div>

              <div className="bg-blue-50 p-4 rounded-lg">
                <h4 className="font-semibold text-blue-800 mb-2">📱 SMS Receipts Sent:</h4>
                <div className="text-sm text-blue-700 space-y-1">
                  <p>✓ Tenant receipt sent to {paymentData.senderNumber}</p>
                  <p>✓ Landlord notification sent to {landlordMPaisaNumber}</p>
                </div>
              </div>

              <div className="space-y-2">
                <Button
                  onClick={onClose}
                  className="w-full bg-fiji-blue text-white hover:bg-fiji-dark-blue"
                >
                  Continue to Property
                </Button>
                
                <p className="text-xs text-gray-600">
                  Keep your transaction ID for future reference
                </p>
              </div>
            </div>
          )}

          {/* Security Notice */}
          <div className="mt-6 pt-4 border-t border-gray-200">
            <div className="flex items-center gap-2 text-xs text-gray-600">
              <Shield size={14} />
              <span>Secured by M-PAiSA • Your payment is protected</span>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}