import { useState, useEffect } from 'react';
import { ArrowLeft, Users, Home, Shield, TrendingUp, Eye, CheckCircle, XCircle, Clock } from 'lucide-react';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Textarea } from './ui/textarea';
import { useAuth } from './auth/AuthContext';
import { projectId, publicAnonKey } from '../utils/supabase/info';

interface AdminPanelProps {
  onNavigate: (page: string) => void;
}

interface AdminStats {
  totalUsers: number;
  totalProperties: number;
  approvedProperties: number;
  pendingProperties: number;
  pendingVerifications: number;
  totalRevenue: number;
}

interface VerificationApplication {
  id: string;
  userId: string;
  userEmail: string;
  personalInfo: {
    fijiIdNumber: string;
    fullName: string;
    dateOfBirth: string;
    address: string;
    phone: string;
  };
  landlordInfo: {
    propertyCount: number;
    experienceYears: number;
    references: string;
  };
  status: 'pending' | 'approved' | 'rejected';
  submittedAt: string;
  reviewedAt?: string;
  adminNotes?: string;
}

interface PropertySubmission {
  id: string;
  title: string;
  location: string;
  price: string;
  type: string;
  bedrooms: number;
  bathrooms: number;
  status: 'pending' | 'approved' | 'rejected';
  submittedAt: string;
  submittedBy: string;
  adminNotes?: string;
}

export default function AdminPanel({ onNavigate }: AdminPanelProps) {
  const { user, getAccessToken } = useAuth();
  const [activeTab, setActiveTab] = useState('dashboard');
  const [loading, setLoading] = useState(true);
  const [stats, setStats] = useState<AdminStats | null>(null);
  const [verificationApplications, setVerificationApplications] = useState<VerificationApplication[]>([]);
  const [propertySubmissions, setPropertySubmissions] = useState<PropertySubmission[]>([]);
  const [notifications, setNotifications] = useState<any[]>([]);

  useEffect(() => {
    if (user) {
      loadAdminData();
    }
  }, [user]);

  const loadAdminData = async () => {
    if (!user) return;
    
    const token = getAccessToken();
    if (!token) return;

    try {
      setLoading(true);
      
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-304c8b39/admin/dashboard`,
        {
          headers: {
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json'
          }
        }
      );

      if (response.ok) {
        const data = await response.json();
        setStats(data.stats);
        setVerificationApplications(data.pendingVerifications || []);
        setPropertySubmissions(data.pendingProperties || []);
        setNotifications(data.notifications || []);
      } else {
        console.error('Failed to load admin data');
      }
    } catch (error) {
      console.error('Error loading admin data:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleVerificationAction = async (applicationId: string, action: 'approve' | 'reject', adminNotes: string) => {
    if (!user) return;
    
    const token = getAccessToken();
    if (!token) return;

    try {
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-304c8b39/admin/verification/${applicationId}/${action}`,
        {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({ adminNotes })
        }
      );

      if (response.ok) {
        // Refresh data
        loadAdminData();
        alert(`Verification ${action}d successfully!`);
      } else {
        alert(`Failed to ${action} verification`);
      }
    } catch (error) {
      console.error('Error processing verification:', error);
      alert('An error occurred');
    }
  };

  const handlePropertyAction = async (propertyId: string, action: 'approve' | 'reject', adminNotes: string) => {
    if (!user) return;
    
    const token = getAccessToken();
    if (!token) return;

    try {
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-304c8b39/admin/property/${propertyId}/${action}`,
        {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({ adminNotes })
        }
      );

      if (response.ok) {
        // Refresh data
        loadAdminData();
        alert(`Property ${action}d successfully!`);
      } else {
        alert(`Failed to ${action} property`);
      }
    } catch (error) {
      console.error('Error processing property:', error);
      alert('An error occurred');
    }
  };

  if (!user) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-red-50 to-orange-50 flex items-center justify-center p-4">
        <Card className="max-w-md w-full p-8 text-center">
          <div className="text-6xl mb-4">🔐</div>
          <h2 className="text-2xl font-bold mb-4">Admin Access Required</h2>
          <p className="text-gray-600 mb-6">Please sign in as an administrator to access this panel.</p>
          <Button onClick={() => onNavigate('home')} className="bg-red-600 text-white">
            Back to Home
          </Button>
        </Card>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-red-50 to-orange-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-red-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Loading admin dashboard...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-red-50 to-orange-50">
      {/* Header */}
      <div className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <button
                onClick={() => onNavigate('home')}
                className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
              >
                <ArrowLeft size={20} />
              </button>
              <div>
                <h1 className="text-2xl font-bold text-gray-900">Admin Dashboard</h1>
                <p className="text-gray-600">BulaRent Platform Management</p>
              </div>
            </div>
            
            <Badge className="bg-red-600 text-white px-4 py-2">
              <Shield size={16} className="mr-2" />
              Administrator
            </Badge>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Stats Overview */}
        {stats && (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4 mb-8">
            <Card className="p-4 text-center bg-blue-50 border-blue-200">
              <Users className="mx-auto mb-2 text-blue-600" size={24} />
              <div className="font-bold text-2xl text-blue-900">{stats.totalUsers}</div>
              <div className="text-sm text-blue-700">Total Users</div>
            </Card>
            
            <Card className="p-4 text-center bg-green-50 border-green-200">
              <Home className="mx-auto mb-2 text-green-600" size={24} />
              <div className="font-bold text-2xl text-green-900">{stats.totalProperties}</div>
              <div className="text-sm text-green-700">Properties</div>
            </Card>
            
            <Card className="p-4 text-center bg-purple-50 border-purple-200">
              <Shield className="mx-auto mb-2 text-purple-600" size={24} />
              <div className="font-bold text-2xl text-purple-900">{stats.pendingVerifications}</div>
              <div className="text-sm text-purple-700">Pending Verifications</div>
            </Card>
            
            <Card className="p-4 text-center bg-orange-50 border-orange-200">
              <Clock className="mx-auto mb-2 text-orange-600" size={24} />
              <div className="font-bold text-2xl text-orange-900">{stats.pendingProperties}</div>
              <div className="text-sm text-orange-700">Pending Properties</div>
            </Card>
            
            <Card className="p-4 text-center bg-yellow-50 border-yellow-200">
              <TrendingUp className="mx-auto mb-2 text-yellow-600" size={24} />
              <div className="font-bold text-2xl text-yellow-900">FJD ${stats.totalRevenue}</div>
              <div className="text-sm text-yellow-700">Revenue</div>
            </Card>
            
            <Card className="p-4 text-center bg-indigo-50 border-indigo-200">
              <Eye className="mx-auto mb-2 text-indigo-600" size={24} />
              <div className="font-bold text-2xl text-indigo-900">{stats.approvedProperties}</div>
              <div className="text-sm text-indigo-700">Approved</div>
            </Card>
          </div>
        )}

        {/* Admin Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid grid-cols-2 md:grid-cols-4 w-full mb-8">
            <TabsTrigger value="dashboard">Dashboard</TabsTrigger>
            <TabsTrigger value="verifications">
              Verifications ({verificationApplications.length})
            </TabsTrigger>
            <TabsTrigger value="properties">
              Properties ({propertySubmissions.length})
            </TabsTrigger>
            <TabsTrigger value="notifications">
              Notifications ({notifications.length})
            </TabsTrigger>
          </TabsList>

          {/* Dashboard Tab */}
          <TabsContent value="dashboard">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card className="p-6">
                <h3 className="text-lg font-bold mb-4">Recent Activity</h3>
                <div className="space-y-3">
                  {notifications.slice(0, 5).map((notif, index) => (
                    <div key={index} className="flex items-start gap-3 p-3 bg-gray-50 rounded-lg">
                      <div className="w-2 h-2 rounded-full bg-red-500 mt-2"></div>
                      <div>
                        <div className="font-medium text-sm">{notif.subject}</div>
                        <div className="text-xs text-gray-500">{notif.message}</div>
                        <div className="text-xs text-gray-400 mt-1">
                          {new Date(notif.sentAt).toLocaleString()}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </Card>

              <Card className="p-6">
                <h3 className="text-lg font-bold mb-4">Quick Actions</h3>
                <div className="space-y-3">
                  <Button
                    onClick={() => setActiveTab('verifications')}
                    className="w-full justify-start bg-purple-600 text-white hover:bg-purple-700"
                  >
                    <Shield size={16} className="mr-2" />
                    Review Verifications ({verificationApplications.length})
                  </Button>
                  
                  <Button
                    onClick={() => setActiveTab('properties')}
                    className="w-full justify-start bg-orange-600 text-white hover:bg-orange-700"
                  >
                    <Home size={16} className="mr-2" />
                    Review Properties ({propertySubmissions.length})
                  </Button>
                  
                  <Button
                    onClick={() => onNavigate('listings')}
                    variant="outline"
                    className="w-full justify-start"
                  >
                    <Eye size={16} className="mr-2" />
                    View Public Listings
                  </Button>
                </div>
              </Card>
            </div>
          </TabsContent>

          {/* Verifications Tab */}
          <TabsContent value="verifications">
            <div className="space-y-6">
              {verificationApplications.map((app) => (
                <VerificationCard
                  key={app.id}
                  application={app}
                  onAction={handleVerificationAction}
                />
              ))}
              
              {verificationApplications.length === 0 && (
                <Card className="p-8 text-center">
                  <Shield size={48} className="mx-auto mb-4 text-gray-400" />
                  <h3 className="font-bold mb-2">No Pending Verifications</h3>
                  <p className="text-gray-600">All verification applications have been processed.</p>
                </Card>
              )}
            </div>
          </TabsContent>

          {/* Properties Tab */}
          <TabsContent value="properties">
            <div className="space-y-6">
              {propertySubmissions.map((property) => (
                <PropertyCard
                  key={property.id}
                  property={property}
                  onAction={handlePropertyAction}
                />
              ))}
              
              {propertySubmissions.length === 0 && (
                <Card className="p-8 text-center">
                  <Home size={48} className="mx-auto mb-4 text-gray-400" />
                  <h3 className="font-bold mb-2">No Pending Properties</h3>
                  <p className="text-gray-600">All property submissions have been processed.</p>
                </Card>
              )}
            </div>
          </TabsContent>

          {/* Notifications Tab */}
          <TabsContent value="notifications">
            <Card className="p-6">
              <h3 className="text-lg font-bold mb-4">System Notifications</h3>
              <div className="space-y-4">
                {notifications.map((notif, index) => (
                  <div key={index} className="border-l-4 border-blue-500 pl-4 py-2">
                    <div className="font-medium">{notif.subject}</div>
                    <div className="text-sm text-gray-600">{notif.message}</div>
                    <div className="text-xs text-gray-400 mt-1">
                      {new Date(notif.sentAt).toLocaleString()}
                    </div>
                  </div>
                ))}
              </div>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}

// Verification Card Component
function VerificationCard({ 
  application, 
  onAction 
}: { 
  application: VerificationApplication;
  onAction: (id: string, action: 'approve' | 'reject', notes: string) => void;
}) {
  const [adminNotes, setAdminNotes] = useState('');

  return (
    <Card className="p-6">
      <div className="flex justify-between items-start mb-4">
        <div>
          <h4 className="font-bold text-lg">{application.personalInfo.fullName}</h4>
          <p className="text-gray-600">{application.userEmail}</p>
        </div>
        <Badge className="bg-yellow-100 text-yellow-800">
          <Clock size={14} className="mr-1" />
          Pending
        </Badge>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
        <div>
          <h5 className="font-medium mb-2">Personal Information</h5>
          <div className="text-sm space-y-1">
            <p><strong>Fiji ID:</strong> {application.personalInfo.fijiIdNumber}</p>
            <p><strong>Phone:</strong> {application.personalInfo.phone}</p>
            <p><strong>Address:</strong> {application.personalInfo.address}</p>
            <p><strong>DOB:</strong> {application.personalInfo.dateOfBirth}</p>
          </div>
        </div>
        
        <div>
          <h5 className="font-medium mb-2">Landlord Information</h5>
          <div className="text-sm space-y-1">
            <p><strong>Properties:</strong> {application.landlordInfo.propertyCount}</p>
            <p><strong>Experience:</strong> {application.landlordInfo.experienceYears} years</p>
            <p><strong>References:</strong> {application.landlordInfo.references || 'None provided'}</p>
          </div>
        </div>
      </div>

      <div className="mb-4">
        <label className="block text-sm font-medium mb-2">Admin Notes</label>
        <Textarea
          value={adminNotes}
          onChange={(e) => setAdminNotes(e.target.value)}
          placeholder="Add notes about this verification..."
          rows={3}
        />
      </div>

      <div className="flex gap-3">
        <Button
          onClick={() => onAction(application.id, 'approve', adminNotes)}
          className="bg-green-600 text-white hover:bg-green-700"
        >
          <CheckCircle size={16} className="mr-2" />
          Approve
        </Button>
        <Button
          onClick={() => onAction(application.id, 'reject', adminNotes)}
          variant="outline"
          className="border-red-300 text-red-600 hover:bg-red-50"
        >
          <XCircle size={16} className="mr-2" />
          Reject
        </Button>
      </div>
    </Card>
  );
}

// Property Card Component
function PropertyCard({ 
  property, 
  onAction 
}: { 
  property: PropertySubmission;
  onAction: (id: string, action: 'approve' | 'reject', notes: string) => void;
}) {
  const [adminNotes, setAdminNotes] = useState('');

  return (
    <Card className="p-6">
      <div className="flex justify-between items-start mb-4">
        <div>
          <h4 className="font-bold text-lg">{property.title}</h4>
          <p className="text-gray-600">{property.location}</p>
        </div>
        <Badge className="bg-yellow-100 text-yellow-800">
          <Clock size={14} className="mr-1" />
          Pending
        </Badge>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4 text-sm">
        <div>
          <strong>Price:</strong> {property.price}
        </div>
        <div>
          <strong>Type:</strong> {property.type}
        </div>
        <div>
          <strong>Bedrooms:</strong> {property.bedrooms}
        </div>
        <div>
          <strong>Bathrooms:</strong> {property.bathrooms}
        </div>
      </div>

      <div className="mb-4 text-sm">
        <p><strong>Submitted by:</strong> {property.submittedBy}</p>
        <p><strong>Submitted:</strong> {new Date(property.submittedAt).toLocaleString()}</p>
      </div>

      <div className="mb-4">
        <label className="block text-sm font-medium mb-2">Admin Notes</label>
        <Textarea
          value={adminNotes}
          onChange={(e) => setAdminNotes(e.target.value)}
          placeholder="Add notes about this property..."
          rows={3}
        />
      </div>

      <div className="flex gap-3">
        <Button
          onClick={() => onAction(property.id, 'approve', adminNotes)}
          className="bg-green-600 text-white hover:bg-green-700"
        >
          <CheckCircle size={16} className="mr-2" />
          Approve
        </Button>
        <Button
          onClick={() => onAction(property.id, 'reject', adminNotes)}
          variant="outline"
          className="border-red-300 text-red-600 hover:bg-red-50"
        >
          <XCircle size={16} className="mr-2" />
          Reject
        </Button>
      </div>
    </Card>
  );
}