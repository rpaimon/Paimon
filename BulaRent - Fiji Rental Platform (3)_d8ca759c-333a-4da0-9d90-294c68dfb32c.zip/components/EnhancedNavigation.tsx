import { useState } from 'react';
import { Menu, X, Home, Search, Plus, User, Bell, Shield } from 'lucide-react';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { useAuth } from './auth/AuthContext';
import AuthModal from './auth/AuthModal';

interface EnhancedNavigationProps {
  currentPage: string;
  onNavigate: (page: string) => void;
}

export default function EnhancedNavigation({ currentPage, onNavigate }: EnhancedNavigationProps) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [authModalOpen, setAuthModalOpen] = useState(false);
  const [authMode, setAuthMode] = useState<'signin' | 'signup'>('signin');
  const { user, signOut } = useAuth();

  const navigationItems = [
    { id: 'home', label: 'Home', icon: Home },
    { id: 'listings', label: 'Properties', icon: Search },
    { id: 'about', label: 'About', icon: null },
    { id: 'contact', label: 'Contact', icon: null }
  ];

  const handleAuthClick = (mode: 'signin' | 'signup') => {
    setAuthMode(mode);
    setAuthModalOpen(true);
    setMobileMenuOpen(false);
  };

  const handleSignOut = async () => {
    try {
      await signOut();
      setMobileMenuOpen(false);
      onNavigate('home');
    } catch (error) {
      console.error('Sign out error:', error);
    }
  };

  return (
    <>
      <nav className="bg-white shadow-sm border-b sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            {/* Logo */}
            <div className="flex items-center gap-3 cursor-pointer" onClick={() => onNavigate('home')}>
              <div className="bg-tropical-green text-white px-3 py-2 rounded-lg">
                <span className="font-bold text-lg">BR</span>
              </div>
              <div>
                <span className="font-bold text-xl text-gray-900">BulaRent</span>
                <Badge className="ml-2 bg-fiji-orange text-white text-xs">Suva MVP</Badge>
              </div>
            </div>

            {/* Desktop Navigation */}
            <div className="hidden md:flex items-center space-x-8">
              {navigationItems.map((item) => (
                <button
                  key={item.id}
                  onClick={() => onNavigate(item.id)}
                  className={`text-sm font-medium transition-colors hover:text-tropical-green ${
                    currentPage === item.id ? 'text-tropical-green' : 'text-gray-700'
                  }`}
                >
                  {item.label}
                </button>
              ))}
            </div>

            {/* Desktop Actions */}
            <div className="hidden md:flex items-center space-x-4">
              {user ? (
                <>
                  <Button
                    onClick={() => onNavigate('submit')}
                    className="bg-tropical-green text-white hover:bg-green-600"
                  >
                    <Plus size={16} className="mr-2" />
                    List Property
                  </Button>
                  
                  {!user.verified && (
                    <Button
                      onClick={() => onNavigate('verification')}
                      variant="outline"
                      className="border-fiji-orange text-fiji-orange hover:bg-orange-50"
                    >
                      <Shield size={16} className="mr-2" />
                      Get Verified
                    </Button>
                  )}
                  
                  <div className="relative">
                    <button
                      onClick={() => onNavigate('dashboard')}
                      className="flex items-center gap-2 p-2 rounded-lg hover:bg-gray-100 transition-colors"
                    >
                      <div className="w-8 h-8 bg-tropical-green text-white rounded-full flex items-center justify-center font-bold text-sm">
                        {user.name?.charAt(0) || user.email.charAt(0)}
                      </div>
                      <span className="text-sm font-medium">{user.name || 'User'}</span>
                      {user.verified && (
                        <Shield size={14} className="text-green-500" />
                      )}
                    </button>
                  </div>
                  
                  <Button
                    onClick={handleSignOut}
                    variant="outline"
                    size="sm"
                  >
                    Sign Out
                  </Button>
                </>
              ) : (
                <>
                  <Button
                    onClick={() => handleAuthClick('signin')}
                    variant="outline"
                  >
                    Sign In
                  </Button>
                  <Button
                    onClick={() => handleAuthClick('signup')}
                    className="bg-tropical-green text-white hover:bg-green-600"
                  >
                    Get Started
                  </Button>
                </>
              )}
            </div>

            {/* Mobile Menu Button */}
            <div className="md:hidden">
              <button
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                className="p-2 rounded-md text-gray-700 hover:text-tropical-green hover:bg-gray-100"
              >
                {mobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
              </button>
            </div>
          </div>
        </div>

        {/* Mobile Menu */}
        {mobileMenuOpen && (
          <div className="md:hidden border-t bg-white">
            <div className="px-4 py-3 space-y-3">
              {/* Navigation Items */}
              {navigationItems.map((item) => (
                <button
                  key={item.id}
                  onClick={() => {
                    onNavigate(item.id);
                    setMobileMenuOpen(false);
                  }}
                  className={`flex items-center gap-3 w-full text-left p-3 rounded-lg transition-colors ${
                    currentPage === item.id
                      ? 'bg-green-50 text-tropical-green'
                      : 'text-gray-700 hover:bg-gray-50'
                  }`}
                >
                  {item.icon && <item.icon size={20} />}
                  <span className="font-medium">{item.label}</span>
                </button>
              ))}

              {/* User Actions */}
              <div className="border-t pt-3 mt-3">
                {user ? (
                  <>
                    <div className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg mb-3">
                      <div className="w-10 h-10 bg-tropical-green text-white rounded-full flex items-center justify-center font-bold">
                        {user.name?.charAt(0) || user.email.charAt(0)}
                      </div>
                      <div>
                        <div className="font-medium">{user.name || 'User'}</div>
                        <div className="text-sm text-gray-600">{user.email}</div>
                      </div>
                      {user.verified && (
                        <Shield size={16} className="text-green-500 ml-auto" />
                      )}
                    </div>

                    <button
                      onClick={() => {
                        onNavigate('submit');
                        setMobileMenuOpen(false);
                      }}
                      className="flex items-center gap-3 w-full text-left p-3 rounded-lg text-white bg-tropical-green hover:bg-green-600 transition-colors mb-2"
                    >
                      <Plus size={20} />
                      <span className="font-medium">List Property</span>
                    </button>

                    {!user.verified && (
                      <button
                        onClick={() => {
                          onNavigate('verification');
                          setMobileMenuOpen(false);
                        }}
                        className="flex items-center gap-3 w-full text-left p-3 rounded-lg border border-fiji-orange text-fiji-orange hover:bg-orange-50 transition-colors mb-2"
                      >
                        <Shield size={20} />
                        <span className="font-medium">Get Verified</span>
                      </button>
                    )}

                    <button
                      onClick={() => {
                        onNavigate('dashboard');
                        setMobileMenuOpen(false);
                      }}
                      className="flex items-center gap-3 w-full text-left p-3 rounded-lg text-gray-700 hover:bg-gray-50 transition-colors mb-2"
                    >
                      <User size={20} />
                      <span className="font-medium">My Dashboard</span>
                    </button>

                    <button
                      onClick={handleSignOut}
                      className="flex items-center gap-3 w-full text-left p-3 rounded-lg text-red-600 hover:bg-red-50 transition-colors"
                    >
                      <span className="font-medium">Sign Out</span>
                    </button>
                  </>
                ) : (
                  <>
                    <button
                      onClick={() => handleAuthClick('signin')}
                      className="flex items-center gap-3 w-full text-left p-3 rounded-lg border border-gray-300 text-gray-700 hover:bg-gray-50 transition-colors mb-2"
                    >
                      <User size={20} />
                      <span className="font-medium">Sign In</span>
                    </button>

                    <button
                      onClick={() => handleAuthClick('signup')}
                      className="flex items-center gap-3 w-full text-left p-3 rounded-lg text-white bg-tropical-green hover:bg-green-600 transition-colors"
                    >
                      <Plus size={20} />
                      <span className="font-medium">Get Started</span>
                    </button>
                  </>
                )}
              </div>
            </div>
          </div>
        )}
      </nav>

      {/* Auth Modal */}
      <AuthModal
        isOpen={authModalOpen}
        onClose={() => setAuthModalOpen(false)}
        initialMode={authMode}
      />
    </>
  );
}