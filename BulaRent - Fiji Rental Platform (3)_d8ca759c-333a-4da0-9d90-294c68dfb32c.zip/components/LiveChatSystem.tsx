import { useState, useEffect, useRef } from 'react';
import { X, Send, Phone, User, Shield, AlertTriangle, MessageSquare } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Badge } from './ui/badge';
import { useAuth } from './auth/AuthContext';
import { projectId, publicAnonKey } from '../utils/supabase/info';

interface LiveChatSystemProps {
  propertyId: string;
  propertyTitle: string;
  landlordName: string;
  landlordVerified: boolean;
  onClose: () => void;
}

interface ChatMessage {
  id: string;
  content: string;
  senderId: string;
  senderName: string;
  timestamp: string;
  isRead?: boolean;
}

export default function LiveChatSystem({ 
  propertyId, 
  propertyTitle, 
  landlordName, 
  landlordVerified, 
  onClose 
}: LiveChatSystemProps) {
  const { user, getAccessToken } = useAuth();
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [newMessage, setNewMessage] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [isConnected, setIsConnected] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const pollIntervalRef = useRef<NodeJS.Timeout | null>(null);

  useEffect(() => {
    if (user) {
      loadChatHistory();
      startPolling();
    }

    return () => {
      if (pollIntervalRef.current) {
        clearInterval(pollIntervalRef.current);
      }
    };
  }, [user, propertyId]);

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const loadChatHistory = async () => {
    if (!user) return;

    try {
      setLoading(true);
      setError(null);
      const token = getAccessToken();

      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-304c8b39/chats/${propertyId}`,
        {
          headers: {
            'Authorization': `Bearer ${token || publicAnonKey}`,
            'Content-Type': 'application/json'
          }
        }
      );

      if (response.ok) {
        const data = await response.json();
        setMessages(data.messages || []);
        setIsConnected(true);
      } else {
        const errorData = await response.json();
        setError(errorData.error || 'Failed to load chat history');
      }
    } catch (err) {
      console.error('Error loading chat history:', err);
      setError('Failed to connect to chat server');
    } finally {
      setLoading(false);
    }
  };

  const startPolling = () => {
    // Poll for new messages every 3 seconds
    pollIntervalRef.current = setInterval(() => {
      loadChatHistory();
    }, 3000);
  };

  const sendMessage = async () => {
    if (!newMessage.trim() || !user || loading) return;

    const messageContent = newMessage.trim();
    setNewMessage('');

    try {
      setLoading(true);
      const token = getAccessToken();

      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-304c8b39/chats/${propertyId}/messages`,
        {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${token || publicAnonKey}`,
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({
            content: messageContent
          })
        }
      );

      if (response.ok) {
        const data = await response.json();
        // Optimistically add the message
        const newMsg: ChatMessage = {
          id: data.message?.id || crypto.randomUUID(),
          content: messageContent,
          senderId: user.id,
          senderName: user.name || 'You',
          timestamp: new Date().toISOString(),
          isRead: false
        };
        setMessages(prev => [...prev, newMsg]);
        
        // Reload to get latest messages
        setTimeout(() => {
          loadChatHistory();
        }, 500);
      } else {
        const errorData = await response.json();
        setError(errorData.error || 'Failed to send message');
        setNewMessage(messageContent); // Restore message on error
      }
    } catch (err) {
      console.error('Error sending message:', err);
      setError('Failed to send message');
      setNewMessage(messageContent); // Restore message on error
    } finally {
      setLoading(false);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };

  const formatTime = (timestamp: string) => {
    return new Date(timestamp).toLocaleTimeString('en-FJ', {
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  if (!user) {
    return (
      <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
        <div className="bg-white rounded-xl shadow-2xl max-w-md w-full p-6">
          <div className="text-center">
            <h3 className="text-xl font-bold text-gray-900 mb-4">Sign In Required</h3>
            <p className="text-gray-600 mb-6">Please sign in to start a conversation with the landlord.</p>
            <Button onClick={onClose} className="w-full">
              Close
            </Button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-xl shadow-2xl max-w-md w-full h-[600px] flex flex-col">
        {/* Chat Header */}
        <div className="flex items-center justify-between p-4 border-b bg-tropical-green text-white rounded-t-xl">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center">
              <User size={20} />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-semibold">{landlordName}</span>
                {landlordVerified && (
                  <Badge className="bg-white/20 text-white text-xs px-1 py-0">
                    <Shield size={8} className="mr-1" />
                    Verified
                  </Badge>
                )}
              </div>
              <div className="text-sm opacity-90 line-clamp-1">{propertyTitle}</div>
            </div>
          </div>
          
          <div className="flex items-center gap-2">
            <div className={`w-2 h-2 rounded-full ${isConnected ? 'bg-green-300' : 'bg-red-300'}`} />
            <button
              onClick={onClose}
              className="p-1 hover:bg-white/20 rounded-full transition-colors"
            >
              <X size={20} />
            </button>
          </div>
        </div>

        {/* Messages Area */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3">
          {loading && messages.length === 0 ? (
            <div className="flex items-center justify-center h-full">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-tropical-green"></div>
            </div>
          ) : messages.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-full text-center">
              <div className="bg-gray-100 rounded-full p-4 mb-4">
                <MessageSquare size={32} className="text-gray-400" />
              </div>
              <h3 className="font-semibold text-gray-900 mb-2">Start the conversation</h3>
              <p className="text-gray-500 text-sm mb-4">
                Send a message to inquire about this property
              </p>
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-3 text-sm">
                <p className="text-blue-800">
                  💡 <strong>Tip:</strong> Ask about availability, viewing times, or specific amenities
                </p>
              </div>
            </div>
          ) : (
            messages.map((message) => (
              <div
                key={message.id}
                className={`flex ${message.senderId === user.id ? 'justify-end' : 'justify-start'}`}
              >
                <div
                  className={`max-w-[80%] rounded-lg px-3 py-2 ${
                    message.senderId === user.id
                      ? 'bg-tropical-green text-white'
                      : 'bg-gray-100 text-gray-900'
                  }`}
                >
                  <p className="text-sm">{message.content}</p>
                  <p
                    className={`text-xs mt-1 ${
                      message.senderId === user.id ? 'text-white/70' : 'text-gray-500'
                    }`}
                  >
                    {formatTime(message.timestamp)}
                  </p>
                </div>
              </div>
            ))
          )}
          
          {error && (
            <div className="bg-red-50 border border-red-200 rounded-lg p-3 flex items-start gap-2">
              <AlertTriangle size={16} className="text-red-600 mt-0.5 flex-shrink-0" />
              <div>
                <p className="text-red-800 text-sm font-medium">Error</p>
                <p className="text-red-700 text-sm">{error}</p>
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => {
                    setError(null);
                    loadChatHistory();
                  }}
                  className="mt-2 text-xs"
                >
                  Retry
                </Button>
              </div>
            </div>
          )}
          
          <div ref={messagesEndRef} />
        </div>

        {/* Safety Notice */}
        <div className="px-4 py-2 bg-yellow-50 border-t border-yellow-200">
          <p className="text-xs text-yellow-800">
            🛡️ <strong>Safety:</strong> Never send money or personal details via chat. Meet in person to view properties.
          </p>
        </div>

        {/* Message Input */}
        <div className="p-4 border-t">
          <div className="flex gap-2">
            <Input
              value={newMessage}
              onChange={(e) => setNewMessage(e.target.value)}
              onKeyPress={handleKeyPress}
              placeholder="Type your message..."
              disabled={loading}
              className="flex-1"
            />
            <Button
              onClick={sendMessage}
              disabled={!newMessage.trim() || loading}
              size="sm"
              className="bg-tropical-green text-white hover:bg-green-600 px-3"
            >
              <Send size={16} />
            </Button>
          </div>
          
          <div className="flex items-center justify-between mt-2">
            <p className="text-xs text-gray-500">
              Press Enter to send
            </p>
            <div className="flex items-center gap-2">
              <button
                onClick={() => {
                  if (navigator.vibrate) {
                    navigator.vibrate(100);
                  }
                  alert('📞 Phone feature would be available here');
                }}
                className="p-1 text-tropical-green hover:bg-green-50 rounded transition-colors"
                title="Call landlord"
              >
                <Phone size={14} />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}