import { useState } from 'react';
import { Heart, GitCompare, MapPin, Bed, Bath, Car, Star, Shield, Phone, MessageSquare, Share2 } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { useAuth } from './auth/AuthContext';

interface PropertyCardProps {
  property: {
    id: string;
    title: string;
    location: string;
    price: string;
    period: string;
    bedrooms: number;
    bathrooms: number;
    parking: number;
    type: string;
    image: string;
    description: string;
    features: string[];
    views: number;
    favorites: number;
    ownerId: string;
    verified: boolean;
    landlordVerified: boolean;
    nearLandmark?: string;
    weeklyRent?: number;
    mpaisaAccepted?: boolean;
    wifiIncluded?: boolean;
  };
  isFavorite: boolean;
  isInCompare: boolean;
  onToggleFavorite: (propertyId: string) => void;
  onToggleCompare: (propertyId: string) => void;
  onStartChat?: (propertyId: string) => void;
  variant?: 'card' | 'mobile-list';
}

export default function PropertyCard({ 
  property, 
  isFavorite, 
  isInCompare, 
  onToggleFavorite, 
  onToggleCompare,
  onStartChat,
  variant = 'card'
}: PropertyCardProps) {
  const { user } = useAuth();
  const [imageLoaded, setImageLoaded] = useState(false);

  const handleShare = () => {
    if (navigator.share) {
      navigator.share({
        title: property.title,
        text: property.description,
        url: window.location.href + `?property=${property.id}`
      });
    } else {
      // Fallback: copy to clipboard
      navigator.clipboard.writeText(window.location.href + `?property=${property.id}`);
      alert('Property link copied to clipboard!');
    }
  };

  const handleContactAction = (action: 'phone' | 'message') => {
    if (!user) {
      alert('🔒 Please sign in to view contact information and chat with landlords');
      return;
    }

    if (action === 'phone') {
      alert('📞 Contact feature would show landlord phone number here');
      // In real implementation: show phone number or make call
    } else if (action === 'message') {
      if (onStartChat) {
        onStartChat(property.id);
      } else {
        alert('💬 Chat feature would open here');
      }
    }
  };

  // Mobile List Variant (YouTube-style) - COMPLETELY REDESIGNED
  if (variant === 'mobile-list') {
    return (
      <div className="bg-white hover:bg-gray-50 transition-colors">
        <div className="p-4">
          {/* Top Row: Image and Main Content */}
          <div className="flex gap-3 mb-3">
            {/* Image */}
            <div className="relative flex-shrink-0">
              <div className="w-24 h-20 sm:w-28 sm:h-24 rounded-lg overflow-hidden bg-gray-200">
                <ImageWithFallback
                  src={property.image}
                  alt={property.title}
                  className="w-full h-full object-cover"
                  onLoad={() => setImageLoaded(true)}
                />
              </div>
              
              {/* Price Badge */}
              <div className="absolute -top-1 -right-1 bg-tropical-green text-white text-xs font-bold px-2 py-1 rounded-full">
                ${property.price.replace(/[^0-9]/g, '')}
              </div>
            </div>

            {/* Content */}
            <div className="flex-1 min-w-0">
              {/* Title */}
              <h3 className="font-bold text-gray-900 text-sm line-clamp-2 mb-1">
                {property.title}
              </h3>
              
              {/* Location & Landmark */}
              <div className="space-y-1 mb-2">
                <div className="flex items-center text-gray-600 text-xs">
                  <MapPin size={12} className="mr-1 flex-shrink-0" />
                  <span className="truncate">{property.location}</span>
                </div>
                {property.nearLandmark && (
                  <div className="landmark-tag text-xs">
                    📍 {property.nearLandmark}
                  </div>
                )}
              </div>

              {/* Property Details */}
              <div className="flex items-center gap-3 text-xs text-gray-500 mb-2">
                <div className="flex items-center gap-1">
                  <Bed size={12} />
                  <span>{property.bedrooms}</span>
                </div>
                <div className="flex items-center gap-1">
                  <Bath size={12} />
                  <span>{property.bathrooms}</span>
                </div>
                {property.parking > 0 && (
                  <div className="flex items-center gap-1">
                    <Car size={12} />
                    <span>{property.parking}</span>
                  </div>
                )}
                <div className="flex items-center gap-1 ml-auto">
                  <Star size={12} className="text-yellow-400 fill-current" />
                  <span>4.{Math.floor(Math.random() * 9) + 1}</span>
                </div>
              </div>

              {/* Features & Badges */}
              <div className="flex items-center gap-1 mb-2">
                {/* Verification Badge */}
                {property.landlordVerified ? (
                  <Badge className="verified-badge text-xs px-1.5 py-0.5">
                    <Shield size={8} className="mr-1" />
                    Verified
                  </Badge>
                ) : (
                  <Badge className="unverified-badge text-xs px-1.5 py-0.5">
                    🚨 Check
                  </Badge>
                )}

                {/* M-PAiSA Badge */}
                {property.mpaisaAccepted && (
                  <Badge className="bg-purple-100 text-purple-700 text-xs px-1.5 py-0.5">
                    💳
                  </Badge>
                )}

                {/* WiFi Badge */}
                {property.wifiIncluded && (
                  <Badge className="bg-green-100 text-green-700 text-xs px-1.5 py-0.5">
                    📶
                  </Badge>
                )}
              </div>
            </div>
          </div>

          {/* Bottom Row: Action Buttons - SEPARATE ROW */}
          <div className="flex items-center justify-between pt-3 border-t border-gray-100">
            {/* Left: Favorite & Compare */}
            <div className="flex items-center gap-2">
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  onToggleFavorite(property.id);
                }}
                className={`flex items-center gap-1 px-2 py-1 rounded-full text-xs transition-colors ${
                  isFavorite 
                    ? 'text-red-500 bg-red-50' 
                    : 'text-gray-400 hover:text-red-500 hover:bg-red-50'
                }`}
              >
                <Heart size={14} fill={isFavorite ? 'currentColor' : 'none'} />
                <span className="hidden sm:inline">Save</span>
              </button>
              
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  onToggleCompare(property.id);
                }}
                className={`flex items-center gap-1 px-2 py-1 rounded-full text-xs transition-colors ${
                  isInCompare 
                    ? 'text-blue-500 bg-blue-50' 
                    : 'text-gray-400 hover:text-blue-500 hover:bg-blue-50'
                }`}
              >
                <GitCompare size={14} />
                <span className="hidden sm:inline">Compare</span>
              </button>
            </div>

            {/* Right: Contact Actions */}
            <div className="flex items-center gap-2">
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  handleContactAction('phone');
                }}
                className={`flex items-center gap-1 px-2 py-1 rounded-full text-xs transition-colors ${
                  user 
                    ? 'text-tropical-green hover:bg-green-50' 
                    : 'text-gray-400 hover:bg-gray-50'
                }`}
              >
                <Phone size={14} />
                {!user && <span className="text-xs">🔒</span>}
                <span className="hidden sm:inline">{user ? 'Call' : 'Sign in'}</span>
              </button>
              
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  handleContactAction('message');
                }}
                className={`flex items-center gap-1 px-2 py-1 rounded-full text-xs transition-colors ${
                  user 
                    ? 'text-blue-600 hover:bg-blue-50' 
                    : 'text-gray-400 hover:bg-gray-50'
                }`}
              >
                <MessageSquare size={14} />
                {!user && <span className="text-xs">🔒</span>}
                <span className="hidden sm:inline">{user ? 'Chat' : 'Sign in'}</span>
              </button>
              
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  handleShare();
                }}
                className="flex items-center gap-1 px-2 py-1 rounded-full text-gray-500 hover:bg-gray-50 transition-colors text-xs"
              >
                <Share2 size={14} />
                <span className="hidden sm:inline">Share</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // Default Card Variant - COMPLETELY REDESIGNED
  return (
    <div className="bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-2xl transition-shadow duration-300 cursor-pointer group border border-gray-100">
      <div className="relative">
        <div className="aspect-video overflow-hidden bg-gray-200">
          <ImageWithFallback
            src={property.image}
            alt={property.title}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
            onLoad={() => setImageLoaded(true)}
          />
        </div>
        
        {/* Top Overlay: Price + Actions */}
        <div className="absolute top-0 left-0 right-0 p-3 flex items-start justify-between">
          {/* Left: Verification Badge */}
          <div className="flex flex-col gap-1">
            {property.landlordVerified ? (
              <Badge className="verified-badge text-xs">
                <Shield size={10} className="mr-1" />
                VERIFIED
              </Badge>
            ) : (
              <Badge className="unverified-badge text-xs">
                🚨 UNVERIFIED
              </Badge>
            )}
          </div>

          {/* Right: Price + Action Buttons */}
          <div className="flex flex-col items-end gap-2">
            {/* Price Badge */}
            <div className="bg-tropical-green text-white px-3 py-1 rounded-full font-semibold text-sm">
              {property.price}
            </div>
            
            {/* Action Buttons - VERTICAL STACK WITH PROPER SPACING */}
            <div className="flex flex-col gap-2">
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  onToggleFavorite(property.id);
                }}
                className={`w-10 h-10 rounded-full shadow-lg transition-all duration-200 flex items-center justify-center ${
                  isFavorite 
                    ? 'bg-red-500 text-white scale-110' 
                    : 'bg-white text-gray-600 hover:text-red-500 hover:scale-105'
                }`}
              >
                <Heart size={16} fill={isFavorite ? 'currentColor' : 'none'} />
              </button>
              
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  onToggleCompare(property.id);
                }}
                className={`w-10 h-10 rounded-full shadow-lg transition-all duration-200 flex items-center justify-center ${
                  isInCompare 
                    ? 'bg-blue-500 text-white scale-110' 
                    : 'bg-white text-gray-600 hover:text-blue-500 hover:scale-105'
                }`}
              >
                <GitCompare size={16} />
              </button>
            </div>
          </div>
        </div>

        {/* Bottom Overlay: Property Type + M-PAiSA */}
        <div className="absolute bottom-3 left-3 right-3 flex items-end justify-between">
          <Badge className="bg-white/90 text-gray-800 text-xs">
            {property.type}
          </Badge>

          {property.mpaisaAccepted && (
            <Badge className="bg-purple-100 text-purple-700 text-xs">
              💳 M-PAiSA
            </Badge>
          )}
        </div>
      </div>
      
      <div className="p-4">
        <h3 className="font-bold text-lg text-gray-900 mb-2 group-hover:text-tropical-green transition-colors line-clamp-1">
          {property.title}
        </h3>
        
        {/* Location with Landmark */}
        <div className="space-y-1 mb-3">
          <div className="flex items-center text-gray-600">
            <MapPin size={14} className="mr-1 flex-shrink-0" />
            <span className="text-sm">{property.location}</span>
          </div>
          {property.nearLandmark && (
            <div className="landmark-tag text-xs">
              📍 {property.nearLandmark}
            </div>
          )}
        </div>
        
        {/* Features */}
        <div className="flex flex-wrap gap-1 mb-3">
          {property.features.slice(0, 3).map((feature, index) => (
            <span 
              key={index}
              className="bg-gray-100 text-gray-600 px-2 py-1 rounded text-xs"
            >
              {feature}
            </span>
          ))}
          {property.features.length > 3 && (
            <span className="text-xs text-gray-500">
              +{property.features.length - 3} more
            </span>
          )}
        </div>
        
        {/* Property Details */}
        <div className="flex items-center justify-between text-sm text-gray-500 mb-4">
          <div className="flex items-center gap-3">
            <span>{property.bedrooms} bed</span>
            <span>{property.bathrooms} bath</span>
            {property.parking > 0 && <span>{property.parking} park</span>}
          </div>
          <div className="flex items-center gap-1">
            <Star size={12} className="text-yellow-400 fill-current" />
            <span className="text-xs">4.{Math.floor(Math.random() * 9) + 1}</span>
          </div>
        </div>

        {/* Action Buttons - REDESIGNED WITH BETTER SPACING */}
        <div className="grid grid-cols-3 gap-2">
          <Button 
            size="sm" 
            className="bg-tropical-green text-white hover:bg-green-600 text-xs py-2"
            onClick={(e) => {
              e.stopPropagation();
              // Handle view details
            }}
          >
            View
          </Button>
          <Button 
            size="sm" 
            variant="outline" 
            className={`text-xs py-2 relative ${
              user 
                ? 'border-tropical-green text-tropical-green hover:bg-green-50' 
                : 'border-gray-300 text-gray-400'
            }`}
            onClick={(e) => {
              e.stopPropagation();
              handleContactAction('phone');
            }}
          >
            <Phone size={14} className="mr-1" />
            Call
            {!user && <span className="absolute -top-1 -right-1 text-xs">🔒</span>}
          </Button>
          <Button 
            size="sm" 
            variant="outline" 
            className={`text-xs py-2 relative ${
              user 
                ? 'border-blue-500 text-blue-600 hover:bg-blue-50' 
                : 'border-gray-300 text-gray-400'
            }`}
            onClick={(e) => {
              e.stopPropagation();
              handleContactAction('message');
            }}
          >
            <MessageSquare size={14} className="mr-1" />
            Chat
            {!user && <span className="absolute -top-1 -right-1 text-xs">🔒</span>}
          </Button>
        </div>
      </div>
    </div>
  );
}