import { useState } from 'react';
import { ArrowLeft, Upload, Camera, Shield, CheckCircle, AlertCircle, FileText, User, MapPin } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Badge } from './ui/badge';
import { Card } from './ui/card';
import { useAuth } from './auth/AuthContext';
import { projectId, publicAnonKey } from '../utils/supabase/info';

interface VerificationPageProps {
  onNavigate: (page: string) => void;
}

interface VerificationData {
  fijiIdNumber: string;
  fullName: string;
  dateOfBirth: string;
  address: string;
  phone: string;
  email: string;
  propertyCount: string;
  experienceYears: string;
  references: string;
  fijiIdFront?: File;
  fijiIdBack?: File;
  selfieVideo?: File;
  proofOfProperty?: File[];
}

export default function VerificationPage({ onNavigate }: VerificationPageProps) {
  const { user, getAccessToken } = useAuth();
  const [currentStep, setCurrentStep] = useState(1);
  const [loading, setLoading] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [uploadProgress, setUploadProgress] = useState<Record<string, number>>({});
  
  const [formData, setFormData] = useState<VerificationData>({
    fijiIdNumber: '',
    fullName: '',
    dateOfBirth: '',
    address: '',
    phone: '',
    email: user?.email || '',
    propertyCount: '',
    experienceYears: '',
    references: ''
  });

  const [errors, setErrors] = useState<Record<string, string>>({});

  const totalSteps = 4;

  const validateStep = (step: number): boolean => {
    const newErrors: Record<string, string> = {};

    switch (step) {
      case 1: // Personal Information
        if (!formData.fijiIdNumber.trim()) newErrors.fijiIdNumber = 'Fiji ID number is required';
        if (!formData.fullName.trim()) newErrors.fullName = 'Full name is required';
        if (!formData.dateOfBirth) newErrors.dateOfBirth = 'Date of birth is required';
        if (!formData.address.trim()) newErrors.address = 'Address is required';
        if (!formData.phone.trim()) newErrors.phone = 'Phone number is required';
        break;
      
      case 2: // Document Upload
        if (!formData.fijiIdFront) newErrors.fijiIdFront = 'Front of Fiji ID is required';
        if (!formData.fijiIdBack) newErrors.fijiIdBack = 'Back of Fiji ID is required';
        break;
      
      case 3: // Video Verification
        if (!formData.selfieVideo) newErrors.selfieVideo = 'Video verification is required';
        break;
      
      case 4: // Property Information
        if (!formData.propertyCount) newErrors.propertyCount = 'Property count is required';
        if (!formData.experienceYears) newErrors.experienceYears = 'Experience is required';
        break;
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleFileUpload = (field: keyof VerificationData, file: File | File[]) => {
    setFormData(prev => ({ ...prev, [field]: file }));
    
    // Simulate upload progress
    const fileName = Array.isArray(file) ? file[0]?.name || 'files' : file.name;
    setUploadProgress(prev => ({ ...prev, [field]: 0 }));
    
    const interval = setInterval(() => {
      setUploadProgress(prev => {
        const current = prev[field] || 0;
        if (current >= 100) {
          clearInterval(interval);
          return prev;
        }
        return { ...prev, [field]: current + 10 };
      });
    }, 200);
  };

  const handleVideoCapture = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ 
        video: true, 
        audio: true 
      });
      
      // For demo purposes, we'll simulate video capture
      alert('📹 Video capture would open here. Please record a 30-second video saying: "I am [Your Name] and I want to verify my BulaRent landlord account for property rentals in Suva, Fiji."');
      
      // Simulate file creation
      const blob = new Blob(['dummy video'], { type: 'video/mp4' });
      const file = new File([blob], 'verification-video.mp4', { type: 'video/mp4' });
      handleFileUpload('selfieVideo', file);
      
      stream.getTracks().forEach(track => track.stop());
    } catch (error) {
      console.error('Camera access denied:', error);
      alert('Camera access required for video verification. Please allow camera permissions.');
    }
  };

  const submitApplication = async () => {
    if (!user) {
      alert('Please sign in to submit verification application');
      return;
    }

    setLoading(true);
    try {
      const token = getAccessToken();
      const applicationData = {
        userId: user.id,
        userEmail: user.email,
        applicationType: 'landlord_verification',
        personalInfo: {
          fijiIdNumber: formData.fijiIdNumber,
          fullName: formData.fullName,
          dateOfBirth: formData.dateOfBirth,
          address: formData.address,
          phone: formData.phone
        },
        landlordInfo: {
          propertyCount: parseInt(formData.propertyCount),
          experienceYears: parseInt(formData.experienceYears),
          references: formData.references
        },
        documents: {
          fijiIdFront: formData.fijiIdFront?.name,
          fijiIdBack: formData.fijiIdBack?.name,
          selfieVideo: formData.selfieVideo?.name,
          proofOfProperty: formData.proofOfProperty?.map(f => f.name)
        },
        status: 'pending',
        submittedAt: new Date().toISOString(),
        adminNotes: 'New verification application submitted'
      };

      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-304c8b39/verification-applications`,
        {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json'
          },
          body: JSON.stringify(applicationData)
        }
      );

      if (response.ok) {
        setSubmitted(true);
        
        // Send email notification to admin
        await fetch(
          `https://${projectId}.supabase.co/functions/v1/make-server-304c8b39/send-notification`,
          {
            method: 'POST',
            headers: {
              'Authorization': `Bearer ${token}`,
              'Content-Type': 'application/json'
            },
            body: JSON.stringify({
              type: 'verification_application',
              to: 'Rehansikdar@gmail.com',
              subject: 'New BulaRent Landlord Verification Application',
              message: `New verification application received from ${formData.fullName} (${formData.email}). Please review in admin dashboard.`,
              applicationData
            })
          }
        );
      } else {
        throw new Error('Failed to submit application');
      }
    } catch (error) {
      console.error('Submission error:', error);
      setErrors({ general: 'Failed to submit application. Please try again.' });
    } finally {
      setLoading(false);
    }
  };

  if (!user) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-green-50 to-blue-50 flex items-center justify-center p-4">
        <Card className="max-w-md w-full p-8 text-center">
          <div className="text-6xl mb-4">🔒</div>
          <h2 className="text-2xl font-bold mb-4">Sign In Required</h2>
          <p className="text-gray-600 mb-6">
            You need to be signed in to apply for landlord verification.
          </p>
          <Button 
            onClick={() => onNavigate('home')}
            className="bg-tropical-green text-white"
          >
            Sign In
          </Button>
        </Card>
      </div>
    );
  }

  if (submitted) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-green-50 to-blue-50 flex items-center justify-center p-4">
        <Card className="max-w-2xl w-full p-8 text-center">
          <div className="text-6xl mb-6">✅</div>
          <h2 className="text-3xl font-bold text-green-800 mb-4">Application Submitted!</h2>
          <p className="text-lg text-gray-600 mb-6">
            Your landlord verification application has been successfully submitted. 
            We'll review your documents and get back to you within 2-3 business days.
          </p>
          
          <div className="bg-blue-50 border border-blue-200 rounded-xl p-6 mb-6">
            <h3 className="font-bold text-blue-800 mb-3">What happens next?</h3>
            <ul className="text-left text-blue-700 space-y-2">
              <li>• Our team will verify your Fiji ID documents</li>
              <li>• Video verification will be reviewed for authenticity</li>
              <li>• Property ownership documents will be validated</li>
              <li>• You'll receive an email notification with the decision</li>
              <li>• If approved, your verification badge will be activated</li>
            </ul>
          </div>

          <div className="flex gap-4 justify-center">
            <Button 
              onClick={() => onNavigate('dashboard')}
              className="bg-tropical-green text-white"
            >
              Go to Dashboard
            </Button>
            <Button 
              onClick={() => onNavigate('home')}
              variant="outline"
            >
              Back to Home
            </Button>
          </div>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-blue-50">
      {/* Header */}
      <div className="bg-white shadow-sm">
        <div className="max-w-4xl mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <button
                onClick={() => onNavigate('home')}
                className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
              >
                <ArrowLeft size={20} />
              </button>
              <div>
                <h1 className="text-2xl font-bold text-gray-900">Landlord Verification</h1>
                <p className="text-gray-600">Get your verified landlord badge - FJD $10/month</p>
              </div>
            </div>
            <Badge className="premium-badge text-lg px-4 py-2">
              <Shield size={16} className="mr-2" />
              Premium Verification
            </Badge>
          </div>
        </div>
      </div>

      {/* Progress Indicator */}
      <div className="max-w-4xl mx-auto px-4 py-8">
        <div className="flex items-center justify-between mb-8">
          {[1, 2, 3, 4].map((step) => (
            <div key={step} className="flex items-center">
              <div className={`w-10 h-10 rounded-full flex items-center justify-center font-bold ${
                step <= currentStep 
                  ? 'bg-tropical-green text-white' 
                  : 'bg-gray-200 text-gray-500'
              }`}>
                {step < currentStep ? <CheckCircle size={20} /> : step}
              </div>
              {step < totalSteps && (
                <div className={`w-20 h-1 ${
                  step < currentStep ? 'bg-tropical-green' : 'bg-gray-200'
                }`} />
              )}
            </div>
          ))}
        </div>

        <Card className="p-8">
          {errors.general && (
            <div className="bg-red-50 border border-red-200 text-red-700 p-4 rounded-xl mb-6">
              {errors.general}
            </div>
          )}

          {/* Step 1: Personal Information */}
          {currentStep === 1 && (
            <div className="space-y-6">
              <div className="text-center mb-8">
                <div className="text-4xl mb-4">🆔</div>
                <h2 className="text-2xl font-bold mb-2">Personal Information</h2>
                <p className="text-gray-600">We need to verify your identity using your Fiji ID</p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <Label htmlFor="fijiId">Fiji ID Number *</Label>
                  <Input
                    id="fijiId"
                    placeholder="e.g. 123456789"
                    value={formData.fijiIdNumber}
                    onChange={(e) => setFormData({ ...formData, fijiIdNumber: e.target.value })}
                    className={errors.fijiIdNumber ? 'border-red-300' : ''}
                  />
                  {errors.fijiIdNumber && <p className="text-red-500 text-sm mt-1">{errors.fijiIdNumber}</p>}
                </div>

                <div>
                  <Label htmlFor="fullName">Full Name (as on ID) *</Label>
                  <Input
                    id="fullName"
                    placeholder="Enter your full name"
                    value={formData.fullName}
                    onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
                    className={errors.fullName ? 'border-red-300' : ''}
                  />
                  {errors.fullName && <p className="text-red-500 text-sm mt-1">{errors.fullName}</p>}
                </div>

                <div>
                  <Label htmlFor="dob">Date of Birth *</Label>
                  <Input
                    id="dob"
                    type="date"
                    value={formData.dateOfBirth}
                    onChange={(e) => setFormData({ ...formData, dateOfBirth: e.target.value })}
                    className={errors.dateOfBirth ? 'border-red-300' : ''}
                  />
                  {errors.dateOfBirth && <p className="text-red-500 text-sm mt-1">{errors.dateOfBirth}</p>}
                </div>

                <div>
                  <Label htmlFor="phone">Phone Number *</Label>
                  <Input
                    id="phone"
                    placeholder="+679 123 4567"
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    className={errors.phone ? 'border-red-300' : ''}
                  />
                  {errors.phone && <p className="text-red-500 text-sm mt-1">{errors.phone}</p>}
                </div>
              </div>

              <div>
                <Label htmlFor="address">Current Address *</Label>
                <Textarea
                  id="address"
                  placeholder="Enter your full address in Suva"
                  rows={3}
                  value={formData.address}
                  onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                  className={errors.address ? 'border-red-300' : ''}
                />
                {errors.address && <p className="text-red-500 text-sm mt-1">{errors.address}</p>}
              </div>
            </div>
          )}

          {/* Step 2: Document Upload */}
          {currentStep === 2 && (
            <div className="space-y-6">
              <div className="text-center mb-8">
                <div className="text-4xl mb-4">📄</div>
                <h2 className="text-2xl font-bold mb-2">Upload Documents</h2>
                <p className="text-gray-600">Upload clear photos of both sides of your Fiji ID</p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <Label>Front of Fiji ID *</Label>
                  <div className="mt-2 border-2 border-dashed border-gray-300 rounded-xl p-6 text-center hover:border-tropical-green transition-colors">
                    <Upload className="mx-auto mb-4 text-gray-400" size={40} />
                    <input
                      type="file"
                      accept="image/*"
                      onChange={(e) => e.target.files?.[0] && handleFileUpload('fijiIdFront', e.target.files[0])}
                      className="hidden"
                      id="fijiIdFront"
                    />
                    <label htmlFor="fijiIdFront" className="cursor-pointer">
                      <div className="text-sm font-medium text-gray-700 mb-1">
                        {formData.fijiIdFront ? formData.fijiIdFront.name : 'Click to upload'}
                      </div>
                      <div className="text-xs text-gray-500">PNG, JPG up to 10MB</div>
                    </label>
                    {uploadProgress.fijiIdFront !== undefined && (
                      <div className="mt-3">
                        <div className="bg-gray-200 rounded-full h-2">
                          <div 
                            className="bg-tropical-green h-2 rounded-full transition-all duration-300"
                            style={{ width: `${uploadProgress.fijiIdFront}%` }}
                          />
                        </div>
                      </div>
                    )}
                  </div>
                  {errors.fijiIdFront && <p className="text-red-500 text-sm mt-1">{errors.fijiIdFront}</p>}
                </div>

                <div>
                  <Label>Back of Fiji ID *</Label>
                  <div className="mt-2 border-2 border-dashed border-gray-300 rounded-xl p-6 text-center hover:border-tropical-green transition-colors">
                    <Upload className="mx-auto mb-4 text-gray-400" size={40} />
                    <input
                      type="file"
                      accept="image/*"
                      onChange={(e) => e.target.files?.[0] && handleFileUpload('fijiIdBack', e.target.files[0])}
                      className="hidden"
                      id="fijiIdBack"
                    />
                    <label htmlFor="fijiIdBack" className="cursor-pointer">
                      <div className="text-sm font-medium text-gray-700 mb-1">
                        {formData.fijiIdBack ? formData.fijiIdBack.name : 'Click to upload'}
                      </div>
                      <div className="text-xs text-gray-500">PNG, JPG up to 10MB</div>
                    </label>
                    {uploadProgress.fijiIdBack !== undefined && (
                      <div className="mt-3">
                        <div className="bg-gray-200 rounded-full h-2">
                          <div 
                            className="bg-tropical-green h-2 rounded-full transition-all duration-300"
                            style={{ width: `${uploadProgress.fijiIdBack}%` }}
                          />
                        </div>
                      </div>
                    )}
                  </div>
                  {errors.fijiIdBack && <p className="text-red-500 text-sm mt-1">{errors.fijiIdBack}</p>}
                </div>
              </div>

              <div className="bg-yellow-50 border border-yellow-200 rounded-xl p-4">
                <div className="flex items-start gap-3">
                  <AlertCircle className="text-yellow-600 mt-0.5" size={20} />
                  <div>
                    <h4 className="font-medium text-yellow-800 mb-1">Photo Guidelines</h4>
                    <ul className="text-sm text-yellow-700 space-y-1">
                      <li>• Ensure all text is clearly readable</li>
                      <li>• Take photos in good lighting</li>
                      <li>• Avoid shadows or glare</li>
                      <li>• Include all corners of the ID card</li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Step 3: Video Verification */}
          {currentStep === 3 && (
            <div className="space-y-6">
              <div className="text-center mb-8">
                <div className="text-4xl mb-4">🎥</div>
                <h2 className="text-2xl font-bold mb-2">Video Verification</h2>
                <p className="text-gray-600">Record a short video to verify your identity</p>
              </div>

              <div className="max-w-md mx-auto">
                <div className="border-2 border-dashed border-gray-300 rounded-xl p-8 text-center">
                  <Camera className="mx-auto mb-4 text-gray-400" size={60} />
                  
                  {!formData.selfieVideo ? (
                    <div>
                      <Button 
                        onClick={handleVideoCapture}
                        className="bg-tropical-green text-white mb-4"
                      >
                        <Camera className="mr-2" size={18} />
                        Start Video Recording
                      </Button>
                      <div className="text-sm text-gray-600">
                        Record a 30-second video saying your name and purpose
                      </div>
                    </div>
                  ) : (
                    <div>
                      <CheckCircle className="mx-auto mb-4 text-green-500" size={60} />
                      <div className="text-sm font-medium text-gray-700 mb-1">
                        {formData.selfieVideo.name}
                      </div>
                      <div className="text-xs text-gray-500">Video recorded successfully</div>
                      {uploadProgress.selfieVideo !== undefined && (
                        <div className="mt-3">
                          <div className="bg-gray-200 rounded-full h-2">
                            <div 
                              className="bg-tropical-green h-2 rounded-full transition-all duration-300"
                              style={{ width: `${uploadProgress.selfieVideo}%` }}
                            />
                          </div>
                        </div>
                      )}
                    </div>
                  )}
                </div>
                {errors.selfieVideo && <p className="text-red-500 text-sm mt-2 text-center">{errors.selfieVideo}</p>}
              </div>

              <div className="bg-blue-50 border border-blue-200 rounded-xl p-4">
                <h4 className="font-medium text-blue-800 mb-2">What to say in your video:</h4>
                <div className="text-sm text-blue-700 bg-white p-3 rounded-lg border">
                  "I am [Your Full Name] and I want to verify my BulaRent landlord account for property rentals in Suva, Fiji. Today's date is [Current Date]."
                </div>
              </div>
            </div>
          )}

          {/* Step 4: Property Information */}
          {currentStep === 4 && (
            <div className="space-y-6">
              <div className="text-center mb-8">
                <div className="text-4xl mb-4">🏠</div>
                <h2 className="text-2xl font-bold mb-2">Property Information</h2>
                <p className="text-gray-600">Tell us about your rental properties</p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <Label htmlFor="propertyCount">How many properties do you own? *</Label>
                  <Input
                    id="propertyCount"
                    type="number"
                    min="1"
                    placeholder="e.g. 3"
                    value={formData.propertyCount}
                    onChange={(e) => setFormData({ ...formData, propertyCount: e.target.value })}
                    className={errors.propertyCount ? 'border-red-300' : ''}
                  />
                  {errors.propertyCount && <p className="text-red-500 text-sm mt-1">{errors.propertyCount}</p>}
                </div>

                <div>
                  <Label htmlFor="experience">Years of rental experience *</Label>
                  <Input
                    id="experience"
                    type="number"
                    min="0"
                    placeholder="e.g. 5"
                    value={formData.experienceYears}
                    onChange={(e) => setFormData({ ...formData, experienceYears: e.target.value })}
                    className={errors.experienceYears ? 'border-red-300' : ''}
                  />
                  {errors.experienceYears && <p className="text-red-500 text-sm mt-1">{errors.experienceYears}</p>}
                </div>
              </div>

              <div>
                <Label htmlFor="references">References (Optional)</Label>
                <Textarea
                  id="references"
                  placeholder="Names and contact details of previous tenants or business partners who can vouch for you"
                  rows={4}
                  value={formData.references}
                  onChange={(e) => setFormData({ ...formData, references: e.target.value })}
                />
              </div>

              <div>
                <Label>Property Ownership Documents (Optional)</Label>
                <div className="mt-2 border-2 border-dashed border-gray-300 rounded-xl p-6 text-center hover:border-tropical-green transition-colors">
                  <FileText className="mx-auto mb-4 text-gray-400" size={40} />
                  <input
                    type="file"
                    accept=".pdf,.doc,.docx,image/*"
                    multiple
                    onChange={(e) => e.target.files && handleFileUpload('proofOfProperty', Array.from(e.target.files))}
                    className="hidden"
                    id="proofOfProperty"
                  />
                  <label htmlFor="proofOfProperty" className="cursor-pointer">
                    <div className="text-sm font-medium text-gray-700 mb-1">
                      {formData.proofOfProperty ? 
                        `${formData.proofOfProperty.length} file(s) selected` : 
                        'Upload property documents'
                      }
                    </div>
                    <div className="text-xs text-gray-500">PDF, DOC, or images</div>
                  </label>
                </div>
                <p className="text-xs text-gray-500 mt-2">
                  Upload property titles, lease agreements, or other ownership documents to speed up verification
                </p>
              </div>
            </div>
          )}

          {/* Navigation Buttons */}
          <div className="flex justify-between mt-8 pt-6 border-t">
            <Button
              onClick={() => setCurrentStep(Math.max(1, currentStep - 1))}
              variant="outline"
              disabled={currentStep === 1}
            >
              <ArrowLeft className="mr-2" size={18} />
              Previous
            </Button>

            {currentStep < totalSteps ? (
              <Button
                onClick={() => {
                  if (validateStep(currentStep)) {
                    setCurrentStep(currentStep + 1);
                  }
                }}
                className="bg-tropical-green text-white"
              >
                Continue
                <ArrowLeft className="ml-2 rotate-180" size={18} />
              </Button>
            ) : (
              <Button
                onClick={submitApplication}
                disabled={loading}
                className="bg-gradient-to-r from-tropical-green to-green-600 text-white px-8"
              >
                {loading ? (
                  <div className="flex items-center gap-2">
                    <div className="animate-spin h-4 w-4 border-2 border-white border-t-transparent rounded-full" />
                    Submitting...
                  </div>
                ) : (
                  <>
                    <Shield className="mr-2" size={18} />
                    Submit Application
                  </>
                )}
              </Button>
            )}
          </div>
        </Card>

        {/* Pricing Information */}
        <Card className="mt-8 p-6 bg-gradient-to-r from-green-50 to-blue-50">
          <div className="text-center">
            <h3 className="text-2xl font-bold mb-4">Verification Badge Benefits</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="text-center">
                <div className="text-3xl mb-2">⭐</div>
                <h4 className="font-bold mb-2">Trusted Status</h4>
                <p className="text-sm text-gray-600">Get verified badge shown to all tenants</p>
              </div>
              <div className="text-center">
                <div className="text-3xl mb-2">📈</div>
                <h4 className="font-bold mb-2">Higher Visibility</h4>
                <p className="text-sm text-gray-600">Your properties appear first in search results</p>
              </div>
              <div className="text-center">
                <div className="text-3xl mb-2">💰</div>
                <h4 className="font-bold mb-2">Premium Features</h4>
                <p className="text-sm text-gray-600">Access to advanced landlord tools</p>
              </div>
            </div>
            <div className="mt-6">
              <Badge className="premium-badge text-lg px-6 py-2">
                Only FJD $10/month • Cancel anytime
              </Badge>
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
}