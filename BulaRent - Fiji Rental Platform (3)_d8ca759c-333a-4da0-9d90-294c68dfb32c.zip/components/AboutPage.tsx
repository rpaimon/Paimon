import { MapPin, Users, Award, Target } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface AboutPageProps {
  onNavigate: (page: string) => void;
}

export default function AboutPage({ onNavigate }: AboutPageProps) {
  const teamMembers = [
    {
      name: 'Sitiveni Ratunabuabua',
      role: 'Founder & CEO',
      image: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=300&h=300&fit=crop',
      bio: 'Born and raised in Suva, Sitiveni has over 10 years in real estate.'
    },
    {
      name: 'Mere Delana',
      role: 'Head of Operations',
      image: 'https://images.unsplash.com/photo-1494790108755-2616b612b786?w=300&h=300&fit=crop',
      bio: 'Property management expert with extensive knowledge of Fiji markets.'
    },
    {
      name: 'Jone Vuki',
      role: 'Technology Lead',
      image: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=300&h=300&fit=crop',
      bio: 'Software engineer passionate about building user-friendly platforms.'
    }
  ];

  const stats = [
    { number: '500+', label: 'Properties Listed', icon: MapPin },
    { number: '2,000+', label: 'Happy Tenants', icon: Users },
    { number: '3+', label: 'Years Experience', icon: Award },
    { number: '95%', label: 'Success Rate', icon: Target }
  ];

  return (
    <div className="min-h-screen bg-white">
      {/* Hero Section */}
      <div className="relative bg-gradient-to-br from-ocean-blue to-deep-blue text-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-4xl md:text-6xl font-bold mb-6">
              About BulaRent
            </h1>
            <p className="text-xl md:text-2xl max-w-3xl mx-auto opacity-90">
              Fiji's first dedicated rental listing platform, connecting property owners with tenants across our beautiful islands.
            </p>
          </div>
        </div>
        <div className="absolute bottom-0 left-0 right-0 h-20 bg-gradient-to-t from-white to-transparent"></div>
      </div>

      {/* Mission Section */}
      <div className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-6">
                Our Mission
              </h2>
              <p className="text-lg text-gray-600 mb-6">
                BulaRent was born from a simple observation: finding quality rental properties in Fiji was unnecessarily difficult. Traditional methods relied on word-of-mouth, classified ads, and outdated listings that left both landlords and tenants frustrated.
              </p>
              <p className="text-lg text-gray-600 mb-6">
                We created BulaRent to bridge this gap, providing a modern, user-friendly platform where property owners can showcase their rentals and tenants can find their perfect home with ease. Our goal is to simplify the rental process while maintaining the personal touch that makes Fiji special.
              </p>
              <p className="text-lg text-gray-600">
                Whether you're a local family looking for a new home, an expat relocating to Fiji, or a property owner wanting to reach quality tenants, BulaRent is here to make your rental journey smooth and successful.
              </p>
            </div>
            <div className="relative">
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1571003123894-1f0594d2b5d9?w=600&h=400&fit=crop"
                alt="Traditional Fijian bure"
                className="rounded-lg shadow-2xl"
              />
              <div className="absolute -bottom-6 -right-6 bg-coral text-white p-6 rounded-lg shadow-lg">
                <p className="font-bold text-lg">Bula!</p>
                <p className="text-sm">Welcome to your new home</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Stats Section */}
      <div className="py-16 bg-sand-beige">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Our Impact
            </h2>
            <p className="text-xl text-gray-600">
              Building trust through transparency and results
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            {stats.map((stat, index) => (
              <div key={index} className="text-center bg-white rounded-lg p-6 shadow-lg">
                <div className="bg-tropical-green text-white rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                  <stat.icon size={32} />
                </div>
                <div className="text-3xl font-bold text-ocean-blue mb-2">{stat.number}</div>
                <div className="text-gray-600">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Team Section */}
      <div className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Meet Our Team
            </h2>
            <p className="text-xl text-gray-600">
              Local experts passionate about helping you find home
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {teamMembers.map((member, index) => (
              <div key={index} className="text-center bg-white rounded-lg shadow-lg overflow-hidden hover:shadow-2xl transition-shadow duration-300">
                <ImageWithFallback
                  src={member.image}
                  alt={member.name}
                  className="w-full h-64 object-cover"
                />
                <div className="p-6">
                  <h3 className="font-bold text-xl text-gray-900 mb-2">{member.name}</h3>
                  <p className="text-ocean-blue font-medium mb-3">{member.role}</p>
                  <p className="text-gray-600">{member.bio}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Values Section */}
      <div className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Our Values
            </h2>
            <p className="text-xl text-gray-600">
              Principles that guide everything we do
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center p-6">
              <div className="bg-ocean-blue text-white rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                <Award size={32} />
              </div>
              <h3 className="font-bold text-xl mb-3">Transparency</h3>
              <p className="text-gray-600">
                We believe in honest, upfront communication about properties, pricing, and processes. No hidden fees or surprises.
              </p>
            </div>
            <div className="text-center p-6">
              <div className="bg-coral text-white rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                <Users size={32} />
              </div>
              <h3 className="font-bold text-xl mb-3">Community</h3>
              <p className="text-gray-600">
                We're committed to strengthening Fiji's communities by helping families find homes where they can thrive and grow.
              </p>
            </div>
            <div className="text-center p-6">
              <div className="bg-tropical-green text-white rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                <Target size={32} />
              </div>
              <h3 className="font-bold text-xl mb-3">Excellence</h3>
              <p className="text-gray-600">
                We strive for excellence in every interaction, constantly improving our platform and services based on your feedback.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* CTA Section */}
      <div className="py-16 bg-gradient-to-r from-ocean-blue to-tropical-green text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">
            Ready to Find Your Perfect Rental?
          </h2>
          <p className="text-xl mb-8 opacity-90">
            Join thousands of satisfied customers who have found their home through BulaRent
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button
              onClick={() => onNavigate('listings')}
              className="bg-white text-ocean-blue px-8 py-3 rounded-lg hover:bg-gray-100 transition-colors duration-300"
            >
              Browse Properties
            </button>
            <button
              onClick={() => onNavigate('submit')}
              className="bg-transparent border-2 border-white text-white px-8 py-3 rounded-lg hover:bg-white hover:text-ocean-blue transition-colors duration-300"
            >
              List Your Property
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}