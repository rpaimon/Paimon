import { useState, useEffect, useRef } from 'react';
import { Send, MessageCircle, X, User, Phone, Mail } from 'lucide-react';
import { useAuth } from './auth/AuthContext';
import { projectId } from '../utils/supabase/info';

interface ChatSystemProps {
  propertyId: string;
  propertyTitle: string;
  propertyOwnerId: string;
  propertyOwnerName?: string;
  isOpen: boolean;
  onClose: () => void;
}

interface Message {
  id: string;
  senderId: string;
  receiverId: string;
  propertyId: string;
  message: string;
  timestamp: string;
  read: boolean;
}

interface Chat {
  id: string;
  messages: Message[];
  lastMessage?: Message;
  updatedAt: string;
}

export default function ChatSystem({ 
  propertyId, 
  propertyTitle, 
  propertyOwnerId, 
  propertyOwnerName,
  isOpen, 
  onClose 
}: ChatSystemProps) {
  const { user, getAccessToken } = useAuth();
  const [messages, setMessages] = useState<Message[]>([]);
  const [newMessage, setNewMessage] = useState('');
  const [loading, setLoading] = useState(false);
  const [sending, setSending] = useState(false);
  const [chatId, setChatId] = useState<string>('');
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (isOpen && user && propertyOwnerId) {
      initializeChat();
      // Set up polling for new messages (in a real app, you'd use WebSocket)
      const interval = setInterval(loadMessages, 3000);
      return () => clearInterval(interval);
    }
  }, [isOpen, user, propertyOwnerId]);

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const initializeChat = async () => {
    if (!user) return;
    
    const token = getAccessToken();
    if (!token) return;

    try {
      setLoading(true);
      
      // Generate chat ID based on user IDs and property
      const participants = [user.id, propertyOwnerId].sort();
      const generatedChatId = `chat_${participants.join('_')}_${propertyId}`;
      setChatId(generatedChatId);
      
      await loadMessages(generatedChatId);
    } catch (error) {
      console.error('Error initializing chat:', error);
    } finally {
      setLoading(false);
    }
  };

  const loadMessages = async (specificChatId?: string) => {
    if (!user) return;
    
    const token = getAccessToken();
    if (!token) return;

    try {
      const targetChatId = specificChatId || chatId;
      if (!targetChatId) return;

      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-304c8b39/chats/${targetChatId}`,
        {
          headers: {
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json'
          }
        }
      );

      if (response.ok) {
        const data = await response.json();
        if (data.chat && data.chat.messages) {
          setMessages(data.chat.messages);
        }
      }
    } catch (error) {
      console.error('Error loading messages:', error);
    }
  };

  const sendMessage = async () => {
    if (!newMessage.trim() || !user || sending) return;

    const token = getAccessToken();
    if (!token) return;

    try {
      setSending(true);
      
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-304c8b39/messages`,
        {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({
            propertyId,
            receiverId: propertyOwnerId,
            message: newMessage
          })
        }
      );

      if (response.ok) {
        setNewMessage('');
        await loadMessages(); // Reload messages to show the new one
      } else {
        const errorData = await response.json();
        alert(`Failed to send message: ${errorData.error}`);
      }
    } catch (error) {
      console.error('Error sending message:', error);
      alert('Failed to send message. Please try again.');
    } finally {
      setSending(false);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };

  const formatTime = (timestamp: string) => {
    const date = new Date(timestamp);
    const now = new Date();
    const isToday = date.toDateString() === now.toDateString();
    
    if (isToday) {
      return date.toLocaleTimeString('en-US', { 
        hour: 'numeric', 
        minute: '2-digit', 
        hour12: true 
      });
    } else {
      return date.toLocaleDateString('en-US', { 
        month: 'short', 
        day: 'numeric',
        hour: 'numeric',
        minute: '2-digit'
      });
    }
  };

  if (!isOpen) return null;

  if (!user) {
    return (
      <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
        <div className="bg-white rounded-xl shadow-2xl max-w-md w-full p-6">
          <div className="text-center">
            <MessageCircle size={48} className="text-gray-300 mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-gray-900 mb-2">Sign In Required</h3>
            <p className="text-gray-600 mb-4">
              Please sign in to start a conversation with the property owner.
            </p>
            <button
              onClick={onClose}
              className="bg-ocean-blue hover:bg-deep-blue text-white px-6 py-2 rounded-lg transition-colors"
            >
              Close
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-xl shadow-2xl max-w-2xl w-full h-[600px] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b bg-ocean-blue text-white rounded-t-xl">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-white bg-opacity-20 rounded-full flex items-center justify-center">
              <User size={20} />
            </div>
            <div>
              <h3 className="font-semibold">{propertyOwnerName || 'Property Owner'}</h3>
              <p className="text-sm opacity-90 truncate max-w-[200px]">{propertyTitle}</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button className="p-2 hover:bg-white hover:bg-opacity-20 rounded-lg transition-colors">
              <Phone size={18} />
            </button>
            <button className="p-2 hover:bg-white hover:bg-opacity-20 rounded-lg transition-colors">
              <Mail size={18} />
            </button>
            <button
              onClick={onClose}
              className="p-2 hover:bg-white hover:bg-opacity-20 rounded-lg transition-colors"
            >
              <X size={18} />
            </button>
          </div>
        </div>

        {/* Messages Area */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {loading ? (
            <div className="text-center py-8">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-ocean-blue mx-auto"></div>
              <p className="text-gray-600 mt-2">Loading conversation...</p>
            </div>
          ) : messages.length === 0 ? (
            <div className="text-center py-8">
              <MessageCircle size={48} className="text-gray-300 mx-auto mb-4" />
              <h4 className="font-semibold text-gray-900 mb-2">Start the conversation</h4>
              <p className="text-gray-600 text-sm">
                Send a message to inquire about this property.
              </p>
            </div>
          ) : (
            <>
              {messages.map((message) => (
                <div
                  key={message.id}
                  className={`flex ${message.senderId === user.id ? 'justify-end' : 'justify-start'}`}
                >
                  <div
                    className={`max-w-[70%] px-4 py-2 rounded-lg ${
                      message.senderId === user.id
                        ? 'bg-ocean-blue text-white'
                        : 'bg-gray-100 text-gray-900'
                    }`}
                  >
                    <p className="text-sm">{message.message}</p>
                    <p className={`text-xs mt-1 ${
                      message.senderId === user.id ? 'text-blue-100' : 'text-gray-500'
                    }`}>
                      {formatTime(message.timestamp)}
                    </p>
                  </div>
                </div>
              ))}
              <div ref={messagesEndRef} />
            </>
          )}
        </div>

        {/* Message Input */}
        <div className="p-4 border-t">
          <div className="flex gap-2">
            <textarea
              value={newMessage}
              onChange={(e) => setNewMessage(e.target.value)}
              onKeyPress={handleKeyPress}
              placeholder="Type your message..."
              className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-ocean-blue focus:border-transparent resize-none"
              rows={2}
              disabled={sending}
            />
            <button
              onClick={sendMessage}
              disabled={!newMessage.trim() || sending}
              className="bg-ocean-blue hover:bg-deep-blue disabled:bg-gray-300 disabled:cursor-not-allowed text-white p-2 rounded-lg transition-colors flex items-center justify-center min-w-[44px]"
            >
              {sending ? (
                <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div>
              ) : (
                <Send size={18} />
              )}
            </button>
          </div>
          <div className="flex items-center justify-between mt-2 text-xs text-gray-500">
            <span>Press Enter to send, Shift+Enter for new line</span>
            {user.userType === 'tenant' && (
              <span>Inquiring about: {propertyTitle}</span>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}