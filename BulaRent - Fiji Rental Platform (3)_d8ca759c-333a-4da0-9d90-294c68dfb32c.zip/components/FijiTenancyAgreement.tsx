import { useState } from 'react';
import { Download, FileText, AlertTriangle, CheckCircle, Phone, ExternalLink } from 'lucide-react';
import { Button } from './ui/button';
import { Card, CardContent } from './ui/card';
import { Badge } from './ui/badge';

interface FijiTenancyAgreementProps {
  onNavigate: (page: string) => void;
}

export default function FijiTenancyAgreement({ onNavigate }: FijiTenancyAgreementProps) {
  const [selectedLanguage, setSelectedLanguage] = useState<'english' | 'fijian'>('english');
  const [agreementType, setAgreementType] = useState<'residential' | 'commercial'>('residential');

  const downloadTemplate = (type: string, language: string) => {
    // In a real implementation, this would download the actual document
    alert(`Downloading ${type} tenancy agreement in ${language}. This would be a real PDF download in production.`);
  };

  const keyProvisions = [
    {
      title: "Rent Amount & Payment",
      description: "Clear specification of rent amount, due dates, and accepted payment methods including M-PAiSA",
      required: true
    },
    {
      title: "Security Deposit",
      description: "Typically 2-4 weeks rent, must be held in separate account and returned at lease end",
      required: true
    },
    {
      title: "Lease Duration",
      description: "Fixed term (6-12 months) or periodic tenancy (week-to-week, month-to-month)",
      required: true
    },
    {
      title: "Property Condition",
      description: "Detailed inventory of property condition at start and end of tenancy",
      required: true
    },
    {
      title: "Maintenance Responsibilities",
      description: "Clear division between landlord and tenant maintenance obligations",
      required: true
    },
    {
      title: "Termination Notice",
      description: "Required notice periods: 28 days for tenants, 42 days for landlords (without cause)",
      required: true
    },
    {
      title: "Utilities & Services",
      description: "Specification of which utilities are included and which are tenant responsibility",
      required: false
    },
    {
      title: "Pets & Guests Policy",
      description: "Clear rules about pets, overnight guests, and use of common areas",
      required: false
    }
  ];

  const legalRequirements = [
    "Must be in writing for tenancies over 12 months",
    "Both parties must sign and date the agreement",
    "Landlord must provide copy to tenant within 7 days",
    "Security deposit must be lodged with approved bond authority",
    "Property must meet basic health and safety standards",
    "Rent increases require proper notice (typically 90 days)"
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Fiji Tenancy Agreement Templates
          </h1>
          <p className="text-lg text-gray-600 mb-6">
            Official templates and guidelines for residential and commercial leases in Fiji
          </p>
          
          <div className="flex justify-center">
            <Badge className="bg-fiji-green text-white">
              📋 Government Approved Templates
            </Badge>
          </div>
        </div>

        {/* Quick Actions */}
        <div className="grid md:grid-cols-2 gap-6 mb-8">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center gap-3 mb-4">
                <div className="bg-fiji-blue text-white p-2 rounded-lg">
                  <FileText size={24} />
                </div>
                <h3 className="text-xl font-bold text-gray-900">Residential Lease</h3>
              </div>
              
              <p className="text-gray-600 mb-4">
                Standard residential tenancy agreement for flats, bures, houses, and rooms in Fiji
              </p>
              
              <div className="space-y-3">
                <div className="flex gap-2">
                  <Button
                    onClick={() => downloadTemplate('Residential', 'English')}
                    className="flex-1 bg-fiji-blue text-white hover:bg-fiji-dark-blue"
                  >
                    <Download size={16} className="mr-2" />
                    English Template
                  </Button>
                  <Button
                    onClick={() => downloadTemplate('Residential', 'Fijian')}
                    variant="outline"
                    className="flex-1 border-fiji-blue text-fiji-blue hover:bg-fiji-light-blue"
                  >
                    <Download size={16} className="mr-2" />
                    Fijian Template
                  </Button>
                </div>
                
                <div className="text-sm text-gray-500 text-center">
                  PDF format • Fillable fields • Legal compliance checked
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center gap-3 mb-4">
                <div className="bg-fiji-orange text-white p-2 rounded-lg">
                  <FileText size={24} />
                </div>
                <h3 className="text-xl font-bold text-gray-900">Commercial Lease</h3>
              </div>
              
              <p className="text-gray-600 mb-4">
                Business premises lease agreement for shops, offices, and commercial spaces
              </p>
              
              <div className="space-y-3">
                <div className="flex gap-2">
                  <Button
                    onClick={() => downloadTemplate('Commercial', 'English')}
                    className="flex-1 bg-fiji-orange text-white hover:bg-sunset-orange"
                  >
                    <Download size={16} className="mr-2" />
                    English Template
                  </Button>
                  <Button
                    onClick={() => downloadTemplate('Commercial', 'Fijian')}
                    variant="outline"
                    className="flex-1 border-fiji-orange text-fiji-orange hover:bg-orange-50"
                  >
                    <Download size={16} className="mr-2" />
                    Fijian Template
                  </Button>
                </div>
                
                <div className="text-sm text-gray-500 text-center">
                  PDF format • Business clauses • GST provisions included
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Legal Requirements */}
        <Card className="mb-8">
          <CardContent className="p-6">
            <h3 className="text-xl font-bold text-gray-900 mb-4 flex items-center gap-2">
              <AlertTriangle className="text-fiji-orange" size={24} />
              Legal Requirements in Fiji
            </h3>
            
            <div className="grid md:grid-cols-2 gap-6">
              <div>
                <h4 className="font-semibold text-gray-900 mb-3">Mandatory Provisions</h4>
                <ul className="space-y-2">
                  {legalRequirements.map((requirement, index) => (
                    <li key={index} className="flex items-start gap-2 text-sm">
                      <CheckCircle size={16} className="text-fiji-green mt-0.5 flex-shrink-0" />
                      <span className="text-gray-700">{requirement}</span>
                    </li>
                  ))}
                </ul>
              </div>
              
              <div>
                <h4 className="font-semibold text-gray-900 mb-3">Important Notes</h4>
                <div className="space-y-3 text-sm text-gray-700">
                  <div className="bg-yellow-50 border-l-4 border-yellow-400 p-3">
                    <p className="font-medium text-yellow-800">iTaukei Land Special Requirements</p>
                    <p className="text-yellow-700 mt-1">
                      For properties on iTaukei land, additional approvals may be required. 
                      Consult the Ministry of Lands before signing.
                    </p>
                  </div>
                  
                  <div className="bg-blue-50 border-l-4 border-blue-400 p-3">
                    <p className="font-medium text-blue-800">M-PAiSA Payment Clauses</p>
                    <p className="text-blue-700 mt-1">
                      Include provisions for digital payments via M-PAiSA for modern convenience.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Key Provisions Guide */}
        <Card className="mb-8">
          <CardContent className="p-6">
            <h3 className="text-xl font-bold text-gray-900 mb-4">
              Key Provisions Guide
            </h3>
            
            <div className="grid gap-4">
              {keyProvisions.map((provision, index) => (
                <div key={index} className="border border-gray-200 rounded-lg p-4">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-2">
                        <h4 className="font-semibold text-gray-900">{provision.title}</h4>
                        {provision.required && (
                          <Badge className="bg-red-100 text-red-700 text-xs">Required</Badge>
                        )}
                      </div>
                      <p className="text-gray-600 text-sm">{provision.description}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Resources & Contacts */}
        <Card className="mb-8">
          <CardContent className="p-6">
            <h3 className="text-xl font-bold text-gray-900 mb-4">
              Additional Resources & Support
            </h3>
            
            <div className="grid md:grid-cols-2 gap-6">
              <div>
                <h4 className="font-semibold text-gray-900 mb-3">Government Agencies</h4>
                <div className="space-y-3">
                  <div className="flex items-center gap-3">
                    <Phone size={16} className="text-fiji-blue" />
                    <div>
                      <p className="font-medium">Ministry of Housing</p>
                      <p className="text-sm text-gray-600">+679 330 1611</p>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-3">
                    <Phone size={16} className="text-fiji-blue" />
                    <div>
                      <p className="font-medium">Consumer Council of Fiji</p>
                      <p className="text-sm text-gray-600">+679 330 0792</p>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-3">
                    <ExternalLink size={16} className="text-fiji-blue" />
                    <div>
                      <p className="font-medium">Fiji Law Society</p>
                      <p className="text-sm text-gray-600">Legal advice referrals</p>
                    </div>
                  </div>
                </div>
              </div>
              
              <div>
                <h4 className="font-semibold text-gray-900 mb-3">Online Resources</h4>
                <div className="space-y-2">
                  <a href="#" className="block text-fiji-blue hover:text-fiji-dark-blue transition-colors">
                    → Tenant Rights Guide (PDF)
                  </a>
                  <a href="#" className="block text-fiji-blue hover:text-fiji-dark-blue transition-colors">
                    → Landlord Obligations Checklist
                  </a>
                  <a href="#" className="block text-fiji-blue hover:text-fiji-dark-blue transition-colors">
                    → Rent Increase Guidelines
                  </a>
                  <a href="#" className="block text-fiji-blue hover:text-fiji-dark-blue transition-colors">
                    → Property Inspection Forms
                  </a>
                  <a href="#" className="block text-fiji-blue hover:text-fiji-dark-blue transition-colors">
                    → Dispute Resolution Process
                  </a>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Legal Disclaimer */}
        <div className="bg-red-50 border border-red-200 rounded-lg p-6 mb-8">
          <div className="flex items-start gap-3">
            <AlertTriangle className="text-red-600 mt-1" size={20} />
            <div>
              <h4 className="font-semibold text-red-800 mb-2">Legal Disclaimer</h4>
              <p className="text-red-700 text-sm">
                These templates are provided for general guidance only and do not constitute legal advice. 
                While we strive to keep templates current with Fiji law, regulations may change. 
                For complex situations or disputes, consult a qualified lawyer familiar with Fiji property law. 
                BulaRent is not responsible for any legal issues arising from use of these templates.
              </p>
            </div>
          </div>
        </div>

        {/* Back Navigation */}
        <div className="text-center">
          <Button
            onClick={() => onNavigate('home')}
            variant="outline"
            className="border-fiji-blue text-fiji-blue hover:bg-fiji-light-blue"
          >
            ← Back to BulaRent Home
          </Button>
        </div>
      </div>
    </div>
  );
}