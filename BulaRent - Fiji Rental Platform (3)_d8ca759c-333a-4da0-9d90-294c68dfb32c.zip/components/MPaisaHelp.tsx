import { useState } from 'react';
import { Smartphone, CreditCard, Shield, AlertTriangle, Phone, MessageSquare, DollarSign, Clock } from 'lucide-react';
import { Button } from './ui/button';
import { Card, CardContent } from './ui/card';
import { Badge } from './ui/badge';

interface MPaisaHelpProps {
  onNavigate: (page: string) => void;
}

export default function MPaisaHelp({ onNavigate }: MPaisaHelpProps) {
  const [selectedTab, setSelectedTab] = useState<'getting-started' | 'transactions' | 'fees' | 'security'>('getting-started');

  const gettingStartedSteps = [
    {
      step: 1,
      title: "Get a Vodafone SIM",
      description: "Visit any Vodafone store with valid ID (birth certificate, passport, or driver's license)",
      cost: "FJD $5-10",
      time: "5-10 minutes"
    },
    {
      step: 2,
      title: "Register for M-PAiSA",
      description: "Dial *85# or visit Vodafone agent with ID and proof of address",
      cost: "Free",
      time: "15-30 minutes"
    },
    {
      step: 3,
      title: "Fund Your Account",
      description: "Deposit cash at any Vodafone agent or authorized retailer",
      cost: "Minimum FJD $5",
      time: "Immediate"
    },
    {
      step: 4,
      title: "Set Your PIN",
      description: "Create a secure 4-digit PIN for transactions",
      cost: "Free",
      time: "2 minutes"
    }
  ];

  const transactionTypes = [
    {
      type: "Send Money",
      description: "Transfer funds to other M-PAiSA users",
      howTo: "Dial *85# → Send Money → Enter recipient number → Amount → PIN",
      fees: "FJD $0.50 - $2.00",
      limits: "FJD $500/day, FJD $1,500/month"
    },
    {
      type: "Cash Out",
      description: "Withdraw cash from your M-PAiSA account",
      howTo: "Visit Vodafone agent → Provide phone number → Verify PIN → Receive cash",
      fees: "FJD $1.00 - $3.00",
      limits: "FJD $500/transaction"
    },
    {
      type: "Pay Bills",
      description: "Pay utility bills, rent, and other services",
      howTo: "Dial *85# → Pay Bills → Select biller → Enter amount → PIN",
      fees: "FJD $0.50 - $1.50",
      limits: "FJD $1,000/transaction"
    },
    {
      type: "Buy Airtime",
      description: "Top up your phone or others' phones",
      howTo: "Dial *85# → Buy Airtime → Enter number → Amount → PIN",
      fees: "No fee",
      limits: "FJD $200/transaction"
    }
  ];

  const feesStructure = [
    { range: "FJD $0.01 - $50", sendFee: "FJD $0.50", cashOutFee: "FJD $1.00" },
    { range: "FJD $50.01 - $100", sendFee: "FJD $0.80", cashOutFee: "FJD $1.50" },
    { range: "FJD $100.01 - $200", sendFee: "FJD $1.20", cashOutFee: "FJD $2.00" },
    { range: "FJD $200.01 - $500", sendFee: "FJD $2.00", cashOutFee: "FJD $3.00" },
  ];

  const securityTips = [
    {
      title: "Protect Your PIN",
      description: "Never share your M-PAiSA PIN with anyone. Vodafone will never ask for your PIN.",
      icon: Shield,
      severity: "critical"
    },
    {
      title: "Verify Recipients",
      description: "Always double-check phone numbers before sending money. Transactions cannot be reversed.",
      icon: Phone,
      severity: "high"
    },
    {
      title: "Use Official Agents",
      description: "Only transact at official Vodafone agents displaying valid certification.",
      icon: CreditCard,
      severity: "medium"
    },
    {
      title: "Keep Records",
      description: "Save all transaction SMS confirmations for your records and disputes.",
      icon: MessageSquare,
      severity: "medium"
    }
  ];

  const commonIssues = [
    {
      problem: "Transaction Failed",
      solutions: [
        "Check account balance",
        "Verify recipient number",
        "Wait 5 minutes and retry",
        "Contact customer service"
      ]
    },
    {
      problem: "Forgotten PIN",
      solutions: [
        "Visit Vodafone store with ID",
        "Call 123 for assistance",
        "Reset PIN at authorized agent"
      ]
    },
    {
      problem: "Account Blocked",
      solutions: [
        "Contact customer service immediately",
        "Visit nearest Vodafone store",
        "Provide ID and account details"
      ]
    },
    {
      problem: "Wrong Amount Sent",
      solutions: [
        "Contact recipient immediately",
        "Call customer service",
        "File formal complaint if needed"
      ]
    }
  ];

  const rentalPaymentGuide = [
    {
      step: "Landlord Setup",
      description: "Landlord provides M-PAiSA number and preferred payment reference format",
      example: "Number: +679 123 4567, Reference: 'RENT-[Month]-[Unit]'"
    },
    {
      step: "Tenant Payment",
      description: "Send exact rent amount with correct reference on due date",
      example: "Send FJD $800, Reference: 'RENT-JAN2025-UNIT2A'"
    },
    {
      step: "Confirmation",
      description: "Both parties receive SMS confirmation with transaction ID",
      example: "Transaction ID: MP123456789 - Keep for records"
    },
    {
      step: "Receipt",
      description: "Screenshot confirmation SMS or request receipt from landlord",
      example: "Date, Amount, Transaction ID, Reference noted"
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            M-PAiSA Help Guide
          </h1>
          <p className="text-lg text-gray-600 mb-6">
            Complete guide to using M-PAiSA for rent payments and everyday transactions in Fiji
          </p>
          
          <div className="flex justify-center gap-2">
            <Badge className="mpaisa-button">
              📱 Mobile Money
            </Badge>
            <Badge className="bg-green-500 text-white">
              🔒 Secure Payments
            </Badge>
          </div>
        </div>

        {/* Quick Contact */}
        <div className="bg-purple-50 border border-purple-200 rounded-lg p-4 mb-8">
          <div className="flex items-center justify-center gap-6 text-center">
            <div>
              <p className="font-semibold text-purple-800">Customer Service</p>
              <p className="text-purple-700">📞 123 (from Vodafone)</p>
            </div>
            <div>
              <p className="font-semibold text-purple-800">Quick Access</p>
              <p className="text-purple-700">📱 Dial *85#</p>
            </div>
            <div>
              <p className="font-semibold text-purple-800">Emergency</p>
              <p className="text-purple-700">📞 +679 999 2915</p>
            </div>
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="bg-white rounded-lg shadow mb-8">
          <div className="border-b border-gray-200">
            <nav className="flex">
              {[
                { id: 'getting-started', label: 'Getting Started', icon: Smartphone },
                { id: 'transactions', label: 'Transactions', icon: CreditCard },
                { id: 'fees', label: 'Fees & Limits', icon: DollarSign },
                { id: 'security', label: 'Security', icon: Shield }
              ].map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setSelectedTab(tab.id as any)}
                  className={`flex-1 py-4 px-6 text-center border-b-2 transition-colors ${
                    selectedTab === tab.id
                      ? 'border-purple-500 text-purple-600'
                      : 'border-transparent text-gray-500 hover:text-gray-700'
                  }`}
                >
                  <div className="flex items-center justify-center gap-2">
                    <tab.icon size={18} />
                    <span className="hidden md:inline">{tab.label}</span>
                  </div>
                </button>
              ))}
            </nav>
          </div>

          <div className="p-6">
            {/* Getting Started Tab */}
            {selectedTab === 'getting-started' && (
              <div className="space-y-6">
                <h3 className="text-xl font-bold text-gray-900 mb-4">
                  Setting Up M-PAiSA Account
                </h3>
                
                <div className="space-y-4">
                  {gettingStartedSteps.map((step, index) => (
                    <div key={index} className="flex items-start gap-4">
                      <div className="bg-purple-600 text-white rounded-full w-8 h-8 flex items-center justify-center text-sm font-semibold flex-shrink-0 mt-1">
                        {step.step}
                      </div>
                      
                      <div className="flex-1 border border-gray-200 rounded-lg p-4">
                        <div className="flex items-start justify-between mb-2">
                          <h4 className="font-semibold text-gray-900">{step.title}</h4>
                          <div className="flex gap-2">
                            <Badge variant="outline" className="text-xs">
                              <Clock size={10} className="mr-1" />
                              {step.time}
                            </Badge>
                            <Badge variant="outline" className="text-xs">
                              <DollarSign size={10} className="mr-1" />
                              {step.cost}
                            </Badge>
                          </div>
                        </div>
                        <p className="text-gray-600 text-sm">{step.description}</p>
                      </div>
                    </div>
                  ))}
                </div>

                <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                  <h4 className="font-semibold text-blue-800 mb-2">What You Need:</h4>
                  <ul className="text-blue-700 text-sm space-y-1">
                    <li>• Valid Fiji ID (birth certificate, passport, or driver's license)</li>
                    <li>• Proof of address (utility bill or bank statement)</li>
                    <li>• Minimum FJD $5 for initial deposit</li>
                    <li>• Mobile phone compatible with Vodafone network</li>
                  </ul>
                </div>
              </div>
            )}

            {/* Transactions Tab */}
            {selectedTab === 'transactions' && (
              <div className="space-y-6">
                <h3 className="text-xl font-bold text-gray-900 mb-4">
                  How to Use M-PAiSA
                </h3>
                
                <div className="grid gap-4">
                  {transactionTypes.map((transaction, index) => (
                    <div key={index} className="border border-gray-200 rounded-lg p-4">
                      <h4 className="font-semibold text-gray-900 mb-2">{transaction.type}</h4>
                      <p className="text-gray-600 text-sm mb-3">{transaction.description}</p>
                      
                      <div className="grid md:grid-cols-3 gap-3 text-sm">
                        <div>
                          <p className="font-medium text-gray-700">How To:</p>
                          <p className="text-gray-600">{transaction.howTo}</p>
                        </div>
                        <div>
                          <p className="font-medium text-gray-700">Fees:</p>
                          <p className="text-purple-600">{transaction.fees}</p>
                        </div>
                        <div>
                          <p className="font-medium text-gray-700">Limits:</p>
                          <p className="text-gray-600">{transaction.limits}</p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>

                {/* Rental Payment Guide */}
                <div className="bg-green-50 border border-green-200 rounded-lg p-6">
                  <h4 className="font-semibold text-green-800 mb-4">💡 Paying Rent with M-PAiSA</h4>
                  <div className="space-y-3">
                    {rentalPaymentGuide.map((guide, index) => (
                      <div key={index} className="border-l-4 border-green-400 pl-4">
                        <h5 className="font-medium text-green-800">{guide.step}</h5>
                        <p className="text-green-700 text-sm mb-1">{guide.description}</p>
                        <p className="text-green-600 text-xs italic">{guide.example}</p>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {/* Fees Tab */}
            {selectedTab === 'fees' && (
              <div className="space-y-6">
                <h3 className="text-xl font-bold text-gray-900 mb-4">
                  M-PAiSA Fees & Transaction Limits
                </h3>
                
                <div className="overflow-x-auto">
                  <table className="w-full border border-gray-200 rounded-lg">
                    <thead className="bg-gray-50">
                      <tr>
                        <th className="px-4 py-3 text-left font-semibold text-gray-900">Amount Range</th>
                        <th className="px-4 py-3 text-left font-semibold text-gray-900">Send Money Fee</th>
                        <th className="px-4 py-3 text-left font-semibold text-gray-900">Cash Out Fee</th>
                      </tr>
                    </thead>
                    <tbody>
                      {feesStructure.map((fee, index) => (
                        <tr key={index} className="border-t border-gray-200">
                          <td className="px-4 py-3 text-gray-900">{fee.range}</td>
                          <td className="px-4 py-3 text-purple-600">{fee.sendFee}</td>
                          <td className="px-4 py-3 text-purple-600">{fee.cashOutFee}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>

                <div className="grid md:grid-cols-2 gap-6">
                  <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                    <h4 className="font-semibold text-blue-800 mb-2">Daily Limits</h4>
                    <ul className="text-blue-700 text-sm space-y-1">
                      <li>• Send Money: FJD $500</li>
                      <li>• Cash Out: FJD $500</li>
                      <li>• Account Balance: FJD $1,500</li>
                      <li>• Bill Payments: FJD $1,000</li>
                    </ul>
                  </div>

                  <div className="bg-orange-50 border border-orange-200 rounded-lg p-4">
                    <h4 className="font-semibold text-orange-800 mb-2">Monthly Limits</h4>
                    <ul className="text-orange-700 text-sm space-y-1">
                      <li>• Total Transactions: FJD $1,500</li>
                      <li>• Cash In: FJD $3,000</li>
                      <li>• KYC Required: Above FJD $1,500</li>
                      <li>• Business Accounts: Higher limits available</li>
                    </ul>
                  </div>
                </div>
              </div>
            )}

            {/* Security Tab */}
            {selectedTab === 'security' && (
              <div className="space-y-6">
                <h3 className="text-xl font-bold text-gray-900 mb-4">
                  Security & Safety Tips
                </h3>
                
                <div className="grid gap-4">
                  {securityTips.map((tip, index) => (
                    <div 
                      key={index} 
                      className={`border rounded-lg p-4 ${
                        tip.severity === 'critical' 
                          ? 'border-red-300 bg-red-50' 
                          : tip.severity === 'high'
                          ? 'border-orange-300 bg-orange-50'
                          : 'border-blue-300 bg-blue-50'
                      }`}
                    >
                      <div className="flex items-start gap-3">
                        <div className={`p-2 rounded-lg ${
                          tip.severity === 'critical' 
                            ? 'bg-red-200 text-red-700' 
                            : tip.severity === 'high'
                            ? 'bg-orange-200 text-orange-700'
                            : 'bg-blue-200 text-blue-700'
                        }`}>
                          <tip.icon size={20} />
                        </div>
                        <div>
                          <h4 className={`font-semibold mb-1 ${
                            tip.severity === 'critical' 
                              ? 'text-red-800' 
                              : tip.severity === 'high'
                              ? 'text-orange-800'
                              : 'text-blue-800'
                          }`}>
                            {tip.title}
                          </h4>
                          <p className={`text-sm ${
                            tip.severity === 'critical' 
                              ? 'text-red-700' 
                              : tip.severity === 'high'
                              ? 'text-orange-700'
                              : 'text-blue-700'
                          }`}>
                            {tip.description}
                          </p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>

                <div className="bg-red-50 border border-red-200 rounded-lg p-4">
                  <h4 className="font-semibold text-red-800 mb-2 flex items-center gap-2">
                    <AlertTriangle size={20} />
                    Common Scams to Avoid
                  </h4>
                  <ul className="text-red-700 text-sm space-y-1">
                    <li>• Fake customer service calls asking for your PIN</li>
                    <li>• "Test transaction" requests from unknown numbers</li>
                    <li>• Promises of free money or prizes requiring payment</li>
                    <li>• Pressure to send money quickly without verification</li>
                    <li>• Requests to act as money transfer agent for strangers</li>
                  </ul>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Troubleshooting */}
        <Card className="mb-8">
          <CardContent className="p-6">
            <h3 className="text-xl font-bold text-gray-900 mb-4">
              Common Issues & Solutions
            </h3>
            
            <div className="grid md:grid-cols-2 gap-6">
              {commonIssues.map((issue, index) => (
                <div key={index} className="border border-gray-200 rounded-lg p-4">
                  <h4 className="font-semibold text-gray-900 mb-2">❓ {issue.problem}</h4>
                  <ul className="space-y-1">
                    {issue.solutions.map((solution, sIndex) => (
                      <li key={sIndex} className="text-sm text-gray-600 flex items-start gap-2">
                        <span className="text-green-500 mt-1">•</span>
                        <span>{solution}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Contact Information */}
        <Card className="mb-8">
          <CardContent className="p-6">
            <h3 className="text-xl font-bold text-gray-900 mb-4">
              Get Help & Support
            </h3>
            
            <div className="grid md:grid-cols-3 gap-6">
              <div className="text-center">
                <div className="bg-purple-100 text-purple-600 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-3">
                  <Phone size={24} />
                </div>
                <h4 className="font-semibold text-gray-900 mb-2">Call Center</h4>
                <p className="text-purple-600 font-mono">123</p>
                <p className="text-sm text-gray-600">From Vodafone number</p>
              </div>
              
              <div className="text-center">
                <div className="bg-purple-100 text-purple-600 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-3">
                  <MessageSquare size={24} />
                </div>
                <h4 className="font-semibold text-gray-900 mb-2">SMS Support</h4>
                <p className="text-purple-600 font-mono">*85#</p>
                <p className="text-sm text-gray-600">Self-service menu</p>
              </div>
              
              <div className="text-center">
                <div className="bg-purple-100 text-purple-600 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-3">
                  <CreditCard size={24} />
                </div>
                <h4 className="font-semibold text-gray-900 mb-2">Agent Network</h4>
                <p className="text-purple-600">1,000+ Locations</p>
                <p className="text-sm text-gray-600">Cash in/out services</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Back Navigation */}
        <div className="text-center">
          <Button
            onClick={() => onNavigate('home')}
            variant="outline"
            className="border-purple-500 text-purple-600 hover:bg-purple-50"
          >
            ← Back to BulaRent Home
          </Button>
        </div>
      </div>
    </div>
  );
}