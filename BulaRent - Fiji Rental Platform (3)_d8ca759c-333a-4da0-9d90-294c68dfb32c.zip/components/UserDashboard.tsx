import { useState, useEffect } from 'react';
import { ArrowLeft, Edit3, Shield, Star, MapPin } from 'lucide-react';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { useAuth } from './auth/AuthContext';
import DashboardStats from './dashboard/DashboardStats';
import ProfileEditor from './dashboard/ProfileEditor';
import { 
  UserProfile, 
  loadUserProfile, 
  saveUserProfile, 
  loadFavoriteProperties, 
  calculateStats 
} from './dashboard/helpers';
import { RECENT_ACTIVITY_MOCK, LANDLORD_BENEFITS, TENANT_BENEFITS } from './dashboard/constants';

interface UserDashboardProps {
  onNavigate: (page: string, propertyId?: string) => void;
}

export default function UserDashboard({ onNavigate }: UserDashboardProps) {
  const { user, getAccessToken } = useAuth();
  const [activeTab, setActiveTab] = useState('overview');
  const [loading, setLoading] = useState(true);
  const [editingProfile, setEditingProfile] = useState(false);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [favoriteProperties, setFavoriteProperties] = useState<any[]>([]);

  useEffect(() => {
    if (user) {
      loadUserData();
    }
  }, [user]);

  const loadUserData = async () => {
    if (!user) return;
    
    const token = getAccessToken();
    if (!token) return;

    try {
      setLoading(true);
      
      const profileData = await loadUserProfile(token);
      if (profileData) {
        setProfile(profileData);
        
        // Load favorite properties
        if (profileData.favorites?.length > 0) {
          const favorites = await loadFavoriteProperties(profileData.favorites);
          setFavoriteProperties(favorites);
        }
      }
    } catch (error) {
      console.error('Error loading user data:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSaveProfile = async (updates: Partial<UserProfile>) => {
    if (!user) return;
    
    const token = getAccessToken();
    if (!token) return;

    try {
      setLoading(true);
      const updatedProfile = await saveUserProfile(token, updates);
      if (updatedProfile) {
        setProfile(updatedProfile);
        setEditingProfile(false);
      }
    } catch (error) {
      console.error('Error saving profile:', error);
    } finally {
      setLoading(false);
    }
  };

  if (!user) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-green-50 to-blue-50 flex items-center justify-center p-4">
        <Card className="max-w-md w-full p-8 text-center">
          <div className="text-6xl mb-4">🔒</div>
          <h2 className="text-2xl font-bold mb-4">Access Restricted</h2>
          <p className="text-gray-600 mb-6">Please sign in to access your dashboard.</p>
          <Button onClick={() => onNavigate('home')} className="bg-tropical-green text-white">
            Sign In
          </Button>
        </Card>
      </div>
    );
  }

  if (loading && !profile) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-green-50 to-blue-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-tropical-green mx-auto mb-4"></div>
          <p className="text-gray-600">Loading your dashboard...</p>
        </div>
      </div>
    );
  }

  const stats = calculateStats(profile, favoriteProperties);

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-blue-50">
      {/* Header */}
      <div className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <button
                onClick={() => onNavigate('home')}
                className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
              >
                <ArrowLeft size={20} />
              </button>
              <div>
                <h1 className="text-2xl font-bold text-gray-900">My Dashboard</h1>
                <p className="text-gray-600">Welcome back, {profile?.name}!</p>
              </div>
            </div>
            
            <div className="flex items-center gap-3">
              {profile?.verified ? (
                <Badge className="verified-badge text-sm px-3 py-1">
                  <Shield size={14} className="mr-1" />
                  Verified {profile.userType}
                </Badge>
              ) : (
                <Button
                  onClick={() => onNavigate('verification')}
                  size="sm"
                  className="bg-fiji-orange text-white hover:bg-orange-600"
                >
                  Get Verified
                </Button>
              )}
              
              {!editingProfile && (
                <Button
                  onClick={() => setEditingProfile(true)}
                  variant="outline"
                  size="sm"
                >
                  <Edit3 size={16} className="mr-2" />
                  Edit Profile
                </Button>
              )}
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {editingProfile ? (
          <div>
            <div className="mb-6">
              <h2 className="text-xl font-bold text-gray-900 mb-2">Edit Profile</h2>
              <p className="text-gray-600">Update your personal information and preferences</p>
            </div>
            <ProfileEditor
              profile={profile!}
              onSave={handleSaveProfile}
              onCancel={() => setEditingProfile(false)}
              loading={loading}
            />
          </div>
        ) : (
          <>
            {/* Stats */}
            <DashboardStats 
              stats={stats} 
              onStatClick={(tab) => setActiveTab(tab)} 
            />

            {/* Main Content Tabs */}
            <Tabs value={activeTab} onValueChange={setActiveTab}>
              <TabsList className="grid grid-cols-2 md:grid-cols-5 w-full mb-8">
                <TabsTrigger value="overview">Overview</TabsTrigger>
                <TabsTrigger value="favorites">Favorites</TabsTrigger>
                <TabsTrigger value="searches">Searches</TabsTrigger>
                <TabsTrigger value="messages">Messages</TabsTrigger>
                <TabsTrigger value="settings">Settings</TabsTrigger>
              </TabsList>

              {/* Overview Tab */}
              <TabsContent value="overview" className="space-y-6">
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  {/* Profile Summary */}
                  <Card className="p-6">
                    <h3 className="text-lg font-bold mb-4">Profile Summary</h3>
                    <div className="space-y-3">
                      <div className="flex items-center gap-3">
                        <div className="w-12 h-12 rounded-full bg-tropical-green text-white flex items-center justify-center font-bold">
                          {profile?.name?.charAt(0) || 'U'}
                        </div>
                        <div>
                          <div className="font-medium">{profile?.name}</div>
                          <div className="text-sm text-gray-500">{profile?.userType}</div>
                        </div>
                      </div>
                      <div className="text-sm text-gray-600">{profile?.bio || 'No bio provided'}</div>
                      {profile?.location && (
                        <div className="flex items-center gap-1 text-sm text-gray-500">
                          <MapPin size={14} />
                          {profile.location}
                        </div>
                      )}
                    </div>
                  </Card>

                  {/* Recent Activity */}
                  <Card className="p-6">
                    <h3 className="text-lg font-bold mb-4">Recent Activity</h3>
                    <div className="space-y-3">
                      {RECENT_ACTIVITY_MOCK.map((activity) => (
                        <div key={activity.id} className="flex items-start gap-3 p-3 bg-gray-50 rounded-lg">
                          <div className="w-8 h-8 rounded-full bg-tropical-green text-white flex items-center justify-center text-xs">
                            {activity.icon === 'Heart' && '❤️'}
                            {activity.icon === 'Search' && '🔍'}
                            {activity.icon === 'MessageSquare' && '💬'}
                          </div>
                          <div className="flex-1">
                            <div className="font-medium text-sm">{activity.title}</div>
                            <div className="text-xs text-gray-500">{activity.description}</div>
                            <div className="text-xs text-gray-400 mt-1">{activity.timestamp}</div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </Card>
                </div>

                {/* Benefits Section */}
                <Card className="p-6">
                  <h3 className="text-lg font-bold mb-4">
                    {profile?.userType === 'landlord' ? 'Landlord Benefits' : 'Tenant Benefits'}
                  </h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    {(profile?.userType === 'landlord' ? LANDLORD_BENEFITS : TENANT_BENEFITS).map((benefit, index) => (
                      <div key={index} className="flex items-center gap-2 text-sm">
                        <Star size={14} className="text-fiji-orange" />
                        <span>{benefit}</span>
                      </div>
                    ))}
                  </div>
                </Card>
              </TabsContent>

              {/* Favorites Tab */}
              <TabsContent value="favorites">
                <Card className="p-6">
                  <h3 className="text-lg font-bold mb-4">Favorite Properties</h3>
                  {favoriteProperties.length > 0 ? (
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                      {favoriteProperties.map((property) => (
                        <div
                          key={property.id}
                          className="border rounded-lg overflow-hidden hover:shadow-lg transition-shadow cursor-pointer"
                          onClick={() => onNavigate('property-details', property.id)}
                        >
                          <img
                            src={property.image}
                            alt={property.title}
                            className="w-full h-40 object-cover"
                          />
                          <div className="p-4">
                            <h4 className="font-medium mb-2">{property.title}</h4>
                            <p className="text-sm text-gray-600 mb-2">{property.location}</p>
                            <p className="font-bold text-tropical-green">{property.price}</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-8">
                      <div className="text-4xl mb-4">❤️</div>
                      <h4 className="font-medium mb-2">No Favorites Yet</h4>
                      <p className="text-gray-600 mb-4">Start exploring properties and save your favorites!</p>
                      <Button onClick={() => onNavigate('listings')} className="bg-tropical-green text-white">
                        Browse Properties
                      </Button>
                    </div>
                  )}
                </Card>
              </TabsContent>

              {/* Other tabs with placeholder content */}
              <TabsContent value="searches">
                <Card className="p-6">
                  <h3 className="text-lg font-bold mb-4">Saved Searches</h3>
                  <div className="text-center py-8">
                    <div className="text-4xl mb-4">🔍</div>
                    <h4 className="font-medium mb-2">No Saved Searches</h4>
                    <p className="text-gray-600">Create custom search alerts to get notified about new properties!</p>
                  </div>
                </Card>
              </TabsContent>

              <TabsContent value="messages">
                <Card className="p-6">
                  <h3 className="text-lg font-bold mb-4">Messages</h3>
                  <div className="text-center py-8">
                    <div className="text-4xl mb-4">💬</div>
                    <h4 className="font-medium mb-2">No Messages</h4>
                    <p className="text-gray-600">Your conversations with landlords will appear here.</p>
                  </div>
                </Card>
              </TabsContent>

              <TabsContent value="settings">
                <Card className="p-6">
                  <h3 className="text-lg font-bold mb-4">Account Settings</h3>
                  <div className="space-y-4">
                    <Button
                      onClick={() => setEditingProfile(true)}
                      variant="outline"
                      className="w-full justify-start"
                    >
                      <Edit3 size={16} className="mr-2" />
                      Edit Profile Information
                    </Button>
                    
                    {!profile?.verified && (
                      <Button
                        onClick={() => onNavigate('verification')}
                        className="w-full justify-start bg-fiji-orange text-white hover:bg-orange-600"
                      >
                        <Shield size={16} className="mr-2" />
                        Get Verified Badge
                      </Button>
                    )}
                    
                    <Button
                      onClick={() => onNavigate('home')}
                      variant="outline"
                      className="w-full justify-start text-red-600 border-red-200 hover:bg-red-50"
                    >
                      Sign Out
                    </Button>
                  </div>
                </Card>
              </TabsContent>
            </Tabs>
          </>
        )}
      </div>
    </div>
  );
}