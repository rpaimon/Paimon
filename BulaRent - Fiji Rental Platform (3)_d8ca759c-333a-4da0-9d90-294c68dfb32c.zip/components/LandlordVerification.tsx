import { useState } from 'react';
import { Upload, Camera, Shield, CheckCircle, AlertCircle, X, Phone } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Card, CardContent } from './ui/card';
import { Badge } from './ui/badge';

interface LandlordVerificationProps {
  onVerificationComplete: (verificationData: VerificationData) => void;
  onClose?: () => void;
  isOpen: boolean;
}

interface VerificationData {
  fijiId: File | null;
  selfieVideo: File | null;
  phoneNumber: string;
  fullName: string;
  address: string;
  status: 'pending' | 'verified' | 'rejected';
}

export default function LandlordVerification({ 
  onVerificationComplete, 
  onClose, 
  isOpen 
}: LandlordVerificationProps) {
  const [currentStep, setCurrentStep] = useState(1);
  const [verificationData, setVerificationData] = useState<VerificationData>({
    fijiId: null,
    selfieVideo: null,
    phoneNumber: '',
    fullName: '',
    address: '',
    status: 'pending'
  });

  const [isRecording, setIsRecording] = useState(false);
  const [videoPreview, setVideoPreview] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleFileUpload = (field: 'fijiId' | 'selfieVideo', file: File) => {
    setVerificationData(prev => ({
      ...prev,
      [field]: file
    }));

    if (field === 'selfieVideo') {
      const url = URL.createObjectURL(file);
      setVideoPreview(url);
    }
  };

  const handleInputChange = (field: string, value: string) => {
    setVerificationData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const isStepValid = () => {
    switch (currentStep) {
      case 1:
        return verificationData.fullName && verificationData.phoneNumber && verificationData.address;
      case 2:
        return verificationData.fijiId !== null;
      case 3:
        return verificationData.selfieVideo !== null;
      default:
        return false;
    }
  };

  const handleNext = () => {
    if (currentStep < 3) {
      setCurrentStep(currentStep + 1);
    } else {
      // Submit verification
      onVerificationComplete(verificationData);
    }
  };

  const startVideoRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ 
        video: { facingMode: 'user' }, 
        audio: true 
      });
      setIsRecording(true);
      
      // In a real implementation, you would set up MediaRecorder here
      // For demo, we'll simulate a 5-second recording
      setTimeout(() => {
        setIsRecording(false);
        // Create a dummy video file for demo
        const dummyVideo = new File([''], 'verification-video.mp4', { type: 'video/mp4' });
        handleFileUpload('selfieVideo', dummyVideo);
      }, 5000);
    } catch (error) {
      console.error('Error accessing camera:', error);
      alert('Camera access required for verification. Please allow camera permissions.');
    }
  };

  const VerificationSteps = () => (
    <div className="flex justify-between mb-6">
      {[1, 2, 3].map((step) => (
        <div key={step} className="flex flex-col items-center flex-1">
          <div className={`w-8 h-8 md:w-10 md:h-10 rounded-full flex items-center justify-center text-sm font-semibold ${
            step <= currentStep 
              ? 'bg-fiji-blue text-white' 
              : 'bg-gray-200 text-gray-500'
          }`}>
            {step}
          </div>
          <div className="text-xs mt-2 text-center font-medium">
            {step === 1 && 'Personal Info'}
            {step === 2 && 'ID Upload'}
            {step === 3 && 'Video Selfie'}
          </div>
        </div>
      ))}
    </div>
  );

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <Card className="w-full max-w-md max-h-[90vh] overflow-y-auto">
        <CardContent className="p-6">
          {/* Header */}
          <div className="flex justify-between items-center mb-6">
            <div className="flex items-center gap-2">
              <Shield className="text-fiji-green" size={24} />
              <h2 className="text-xl font-bold text-gray-900">
                Landlord Verification
              </h2>
            </div>
            {onClose && (
              <button onClick={onClose} className="text-gray-400 hover:text-gray-600">
                <X size={24} />
              </button>
            )}
          </div>

          {/* Benefits Banner */}
          <div className="bg-fiji-light-blue p-4 rounded-lg mb-6">
            <h3 className="font-semibold text-fiji-dark-blue mb-2">
              🏆 Verification Benefits:
            </h3>
            <ul className="text-sm text-fiji-dark-blue space-y-1">
              <li>• Priority listing display</li>
              <li>• Verified landlord badge</li>
              <li>• Higher tenant trust</li>
              <li>• Access to premium features</li>
            </ul>
          </div>

          <VerificationSteps />

          {/* Step 1: Personal Information */}
          {currentStep === 1 && (
            <div className="space-y-4">
              <h3 className="font-semibold text-gray-900 mb-4">Personal Information</h3>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Full Name (as on ID) *
                </label>
                <Input
                  type="text"
                  placeholder="John Smith"
                  value={verificationData.fullName}
                  onChange={(e) => handleInputChange('fullName', e.target.value)}
                  className="w-full"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Fijian Phone Number *
                </label>
                <div className="flex">
                  <span className="inline-flex items-center px-3 rounded-l-lg border border-r-0 border-gray-300 bg-gray-50 text-gray-500 text-sm">
                    +679
                  </span>
                  <Input
                    type="tel"
                    placeholder="123 4567"
                    value={verificationData.phoneNumber}
                    onChange={(e) => handleInputChange('phoneNumber', e.target.value)}
                    className="flex-1 rounded-l-none"
                  />
                </div>
                <p className="text-xs text-gray-500 mt-1">
                  Must be a valid Fiji number for SMS verification
                </p>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Residential Address *
                </label>
                <Input
                  type="text"
                  placeholder="123 Main Street, Suva"
                  value={verificationData.address}
                  onChange={(e) => handleInputChange('address', e.target.value)}
                  className="w-full"
                />
              </div>

              <div className="bg-yellow-50 border-l-4 border-yellow-400 p-3 mt-4">
                <div className="flex items-center">
                  <AlertCircle className="text-yellow-400 mr-2" size={16} />
                  <p className="text-sm text-yellow-700">
                    All information must match your official Fiji ID
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* Step 2: ID Upload */}
          {currentStep === 2 && (
            <div className="space-y-4">
              <h3 className="font-semibold text-gray-900 mb-4">Upload Fiji ID</h3>
              
              <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center">
                <input
                  type="file"
                  accept="image/*"
                  onChange={(e) => {
                    const file = e.target.files?.[0];
                    if (file) handleFileUpload('fijiId', file);
                  }}
                  className="hidden"
                  id="id-upload"
                />
                <label htmlFor="id-upload" className="cursor-pointer">
                  {verificationData.fijiId ? (
                    <div className="text-green-600">
                      <CheckCircle className="mx-auto mb-2" size={32} />
                      <p className="font-medium">ID Uploaded Successfully</p>
                      <p className="text-sm text-gray-500 mt-1">
                        {verificationData.fijiId.name}
                      </p>
                    </div>
                  ) : (
                    <div>
                      <Upload className="mx-auto mb-2 text-gray-400" size={32} />
                      <p className="font-medium text-gray-700">Upload Fiji ID</p>
                      <p className="text-sm text-gray-500 mt-1">
                        Birth Certificate, Passport, or Driver's License
                      </p>
                    </div>
                  )}
                </label>
              </div>

              <div className="bg-blue-50 border-l-4 border-blue-400 p-3">
                <h4 className="font-medium text-blue-800 mb-2">ID Requirements:</h4>
                <ul className="text-sm text-blue-700 space-y-1">
                  <li>• Clear, high-quality photo</li>
                  <li>• All text must be readable</li>
                  <li>• No blurry or cut-off edges</li>
                  <li>• Government-issued ID only</li>
                </ul>
              </div>
            </div>
          )}

          {/* Step 3: Video Selfie */}
          {currentStep === 3 && (
            <div className="space-y-4">
              <h3 className="font-semibold text-gray-900 mb-4">Video Selfie Verification</h3>
              
              <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center">
                {verificationData.selfieVideo ? (
                  <div className="text-green-600">
                    <CheckCircle className="mx-auto mb-2" size={32} />
                    <p className="font-medium">Video Recorded Successfully</p>
                    <p className="text-sm text-gray-500 mt-1">
                      Ready for verification review
                    </p>
                  </div>
                ) : (
                  <div>
                    <Camera className="mx-auto mb-2 text-gray-400" size={32} />
                    <p className="font-medium text-gray-700 mb-2">Record Video Selfie</p>
                    <Button
                      onClick={startVideoRecording}
                      disabled={isRecording}
                      className="bg-fiji-blue text-white hover:bg-fiji-dark-blue"
                    >
                      {isRecording ? (
                        <span className="flex items-center gap-2">
                          <div className="w-3 h-3 bg-red-500 rounded-full animate-pulse"></div>
                          Recording... (5s)
                        </span>
                      ) : (
                        'Start Recording'
                      )}
                    </Button>
                  </div>
                )}
              </div>

              <div className="bg-green-50 border-l-4 border-green-400 p-3">
                <h4 className="font-medium text-green-800 mb-2">Video Instructions:</h4>
                <ul className="text-sm text-green-700 space-y-1">
                  <li>• Look directly at camera</li>
                  <li>• Say: "I am [Your Name], verifying for BulaRent"</li>
                  <li>• Hold your ID next to your face</li>
                  <li>• Keep recording for 5 seconds</li>
                </ul>
              </div>
            </div>
          )}

          {/* Navigation Buttons */}
          <div className="flex gap-3 mt-6">
            {currentStep > 1 && (
              <Button
                variant="outline"
                onClick={() => setCurrentStep(currentStep - 1)}
                className="flex-1"
              >
                Back
              </Button>
            )}
            
            <Button
              onClick={handleNext}
              disabled={!isStepValid() || isRecording}
              className="flex-1 bg-fiji-blue text-white hover:bg-fiji-dark-blue"
            >
              {currentStep === 3 ? 'Submit for Review' : 'Next'}
            </Button>
          </div>

          {/* Review Time Notice */}
          {currentStep === 3 && (
            <div className="mt-4 text-center">
              <p className="text-xs text-gray-600">
                ⏱️ Verification usually takes 24-48 hours
              </p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}