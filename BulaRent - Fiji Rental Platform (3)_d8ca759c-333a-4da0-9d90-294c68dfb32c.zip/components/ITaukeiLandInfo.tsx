import { useState } from 'react';
import { MapPin, AlertTriangle, Phone, ExternalLink, FileText, Clock, DollarSign } from 'lucide-react';
import { Button } from './ui/button';
import { Card, CardContent } from './ui/card';
import { Badge } from './ui/badge';

interface ITaukeiLandInfoProps {
  onNavigate: (page: string) => void;
}

export default function ITaukeiLandInfo({ onNavigate }: ITaukeiLandInfoProps) {
  const [selectedRegion, setSelectedRegion] = useState<string>('suva');

  const landCategories = [
    {
      type: "Native Reserve",
      description: "Land set aside for the exclusive use of iTaukei communities",
      leaseability: "Generally not available for lease to non-iTaukei",
      color: "red"
    },
    {
      type: "Schedule A",
      description: "iTaukei land available for agricultural leasing",
      leaseability: "Available for 30-year agricultural leases",
      color: "green"
    },
    {
      type: "Schedule B", 
      description: "iTaukei land available for residential/commercial development",
      leaseability: "Available for 99-year leases (renewable)",
      color: "blue"
    },
    {
      type: "Communal Land",
      description: "Land owned collectively by iTaukei clans/villages",
      leaseability: "Requires clan consent and TLTB approval",
      color: "orange"
    }
  ];

  const leaseProcess = [
    {
      step: 1,
      title: "Land Identification",
      description: "Identify specific plot through TLTB registry",
      duration: "1-2 weeks",
      cost: "FJD $50-100"
    },
    {
      step: 2,
      title: "Landowning Unit Consent",
      description: "Obtain consent from iTaukei landowners",
      duration: "2-6 months",
      cost: "Variable"
    },
    {
      step: 3,
      title: "TLTB Application",
      description: "Submit formal lease application to TLTB",
      duration: "3-12 months",
      cost: "FJD $500-2000"
    },
    {
      step: 4,
      title: "Ministry Approval",
      description: "Final approval from Ministry of Lands",
      duration: "1-3 months",
      cost: "FJD $200-500"
    },
    {
      step: 5,
      title: "Lease Registration",
      description: "Register lease with Registrar of Titles",
      duration: "2-4 weeks",
      cost: "FJD $300-800"
    }
  ];

  const importantConsiderations = [
    {
      title: "Rental Premiums",
      description: "Annual ground rent paid to iTaukei landowners (typically 6% of unimproved land value)",
      icon: DollarSign
    },
    {
      title: "Lease Renewal",
      description: "Most iTaukei leases are renewable, but terms may change upon renewal",
      icon: Clock
    },
    {
      title: "Development Restrictions",
      description: "Some land may have restrictions on type of development allowed",
      icon: AlertTriangle
    },
    {
      title: "Cultural Sensitivity",
      description: "Respect for iTaukei customs and consultation with local communities",
      icon: MapPin
    }
  ];

  const suvaSpecificInfo = {
    totalLand: "Approximately 70% of Suva metropolitan area is on iTaukei land",
    majorAreas: [
      "Samabula - Mix of iTaukei and Crown land",
      "Nabua - Primarily iTaukei land (Schedule B)",
      "Raiwaqa - Mixed ownership with significant iTaukei holdings",
      "Tamavua - Predominantly iTaukei land",
      "Laucala Bay - Mix including USP lease areas"
    ],
    averageGroundRent: "FJD $2,000 - $8,000 per year for residential plots",
    currentIssues: [
      "Lease renewals coming due for properties leased in 1970s-1980s",
      "Increased ground rent demands",
      "Development pressure on traditional villages"
    ]
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            iTaukei Land Information
          </h1>
          <p className="text-lg text-gray-600 mb-6">
            Essential guide to leasing and understanding native land rights in Fiji
          </p>
          
          <div className="flex justify-center gap-2">
            <Badge className="bg-fiji-blue text-white">
              🏝️ 87% of Fiji Land
            </Badge>
            <Badge className="bg-fiji-green text-white">
              📋 Official Guidelines
            </Badge>
          </div>
        </div>

        {/* Critical Warning */}
        <div className="bg-red-50 border-l-4 border-red-500 p-6 mb-8">
          <div className="flex items-start gap-3">
            <AlertTriangle className="text-red-600 mt-1" size={24} />
            <div>
              <h3 className="font-bold text-red-800 mb-2">⚠️ IMPORTANT: Always Verify Land Status</h3>
              <p className="text-red-700 mb-3">
                Before entering any rental agreement or property transaction, always verify the land tenure through the 
                Native Land Trust Board (TLTB) or Ministry of Lands. Unauthorized occupation of iTaukei land can result in legal action.
              </p>
              <div className="flex flex-wrap gap-2">
                <Button size="sm" className="bg-red-600 text-white hover:bg-red-700">
                  <Phone size={14} className="mr-1" />
                  TLTB: +679 331 3433
                </Button>
                <Button size="sm" variant="outline" className="border-red-500 text-red-600">
                  <ExternalLink size={14} className="mr-1" />
                  tltb.com.fj
                </Button>
              </div>
            </div>
          </div>
        </div>

        {/* Land Categories */}
        <Card className="mb-8">
          <CardContent className="p-6">
            <h3 className="text-xl font-bold text-gray-900 mb-4">
              Types of iTaukei Land
            </h3>
            
            <div className="grid gap-4">
              {landCategories.map((category, index) => (
                <div 
                  key={index} 
                  className={`border-l-4 p-4 rounded-r-lg ${{
                    red: 'border-red-500 bg-red-50',
                    green: 'border-green-500 bg-green-50',
                    blue: 'border-blue-500 bg-blue-50',
                    orange: 'border-orange-500 bg-orange-50'
                  }[category.color]}`}
                >
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <h4 className="font-semibold text-gray-900 mb-1">{category.type}</h4>
                      <p className="text-gray-700 text-sm mb-2">{category.description}</p>
                      <p className={`text-sm font-medium ${{
                        red: 'text-red-700',
                        green: 'text-green-700',
                        blue: 'text-blue-700',
                        orange: 'text-orange-700'
                      }[category.color]}`}>
                        {category.leaseability}
                      </p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Suva-Specific Information */}
        <Card className="mb-8">
          <CardContent className="p-6">
            <h3 className="text-xl font-bold text-gray-900 mb-4 flex items-center gap-2">
              <MapPin className="text-fiji-blue" size={24} />
              iTaukei Land in Greater Suva
            </h3>
            
            <div className="grid md:grid-cols-2 gap-6">
              <div>
                <h4 className="font-semibold text-gray-900 mb-3">Key Statistics</h4>
                <div className="space-y-3">
                  <div className="bg-fiji-light-blue p-3 rounded-lg">
                    <p className="font-medium text-fiji-dark-blue">Total Coverage</p>
                    <p className="text-sm text-fiji-dark-blue">{suvaSpecificInfo.totalLand}</p>
                  </div>
                  
                  <div className="bg-green-50 p-3 rounded-lg">
                    <p className="font-medium text-green-800">Average Ground Rent</p>
                    <p className="text-sm text-green-700">{suvaSpecificInfo.averageGroundRent}</p>
                  </div>
                </div>
              </div>
              
              <div>
                <h4 className="font-semibold text-gray-900 mb-3">Major Areas</h4>
                <ul className="space-y-2">
                  {suvaSpecificInfo.majorAreas.map((area, index) => (
                    <li key={index} className="text-sm text-gray-700 flex items-start gap-2">
                      <span className="text-fiji-blue mt-1">•</span>
                      <span>{area}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
            
            <div className="mt-6 pt-6 border-t border-gray-200">
              <h4 className="font-semibold text-gray-900 mb-3">Current Issues in Suva</h4>
              <div className="grid gap-3">
                {suvaSpecificInfo.currentIssues.map((issue, index) => (
                  <div key={index} className="bg-yellow-50 border-l-4 border-yellow-400 p-3">
                    <p className="text-sm text-yellow-800">{issue}</p>
                  </div>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Lease Process */}
        <Card className="mb-8">
          <CardContent className="p-6">
            <h3 className="text-xl font-bold text-gray-900 mb-4">
              iTaukei Land Lease Process
            </h3>
            
            <div className="space-y-4">
              {leaseProcess.map((step, index) => (
                <div key={index} className="flex items-start gap-4">
                  <div className="bg-fiji-blue text-white rounded-full w-8 h-8 flex items-center justify-center text-sm font-semibold flex-shrink-0 mt-1">
                    {step.step}
                  </div>
                  
                  <div className="flex-1 border border-gray-200 rounded-lg p-4">
                    <div className="flex items-start justify-between mb-2">
                      <h4 className="font-semibold text-gray-900">{step.title}</h4>
                      <div className="flex gap-2">
                        <Badge variant="outline" className="text-xs">
                          <Clock size={10} className="mr-1" />
                          {step.duration}
                        </Badge>
                        <Badge variant="outline" className="text-xs">
                          <DollarSign size={10} className="mr-1" />
                          {step.cost}
                        </Badge>
                      </div>
                    </div>
                    <p className="text-gray-600 text-sm">{step.description}</p>
                  </div>
                </div>
              ))}
            </div>
            
            <div className="mt-6 bg-blue-50 border border-blue-200 rounded-lg p-4">
              <p className="text-blue-800 text-sm">
                <strong>Total Process Time:</strong> 6-24 months typically<br />
                <strong>Total Estimated Costs:</strong> FJD $1,050 - $3,400 (excluding ground rent)
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Important Considerations */}
        <Card className="mb-8">
          <CardContent className="p-6">
            <h3 className="text-xl font-bold text-gray-900 mb-4">
              Key Considerations for Tenants
            </h3>
            
            <div className="grid md:grid-cols-2 gap-4">
              {importantConsiderations.map((consideration, index) => (
                <div key={index} className="border border-gray-200 rounded-lg p-4">
                  <div className="flex items-start gap-3">
                    <div className="bg-fiji-light-blue text-fiji-dark-blue p-2 rounded-lg">
                      <consideration.icon size={20} />
                    </div>
                    <div>
                      <h4 className="font-semibold text-gray-900 mb-1">{consideration.title}</h4>
                      <p className="text-gray-600 text-sm">{consideration.description}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Resources & Contacts */}
        <Card className="mb-8">
          <CardContent className="p-6">
            <h3 className="text-xl font-bold text-gray-900 mb-4">
              Official Resources & Contacts
            </h3>
            
            <div className="grid md:grid-cols-2 gap-6">
              <div>
                <h4 className="font-semibold text-gray-900 mb-3">Government Agencies</h4>
                <div className="space-y-4">
                  <div className="border border-gray-200 rounded-lg p-3">
                    <h5 className="font-medium text-gray-900">Native Land Trust Board (TLTB)</h5>
                    <div className="text-sm text-gray-600 space-y-1">
                      <p>📞 +679 331 3433</p>
                      <p>🌐 tltb.com.fj</p>
                      <p>📧 info@tltb.com.fj</p>
                      <p>📍 Civic Tower, Suva</p>
                    </div>
                  </div>
                  
                  <div className="border border-gray-200 rounded-lg p-3">
                    <h5 className="font-medium text-gray-900">Ministry of Lands</h5>
                    <div className="text-sm text-gray-600 space-y-1">
                      <p>📞 +679 321 1355</p>
                      <p>📧 lands@govnet.gov.fj</p>
                      <p>📍 Ro Lalabalavu House, Suva</p>
                    </div>
                  </div>
                </div>
              </div>
              
              <div>
                <h4 className="font-semibold text-gray-900 mb-3">Legal Resources</h4>
                <div className="space-y-2">
                  <a href="#" className="block text-fiji-blue hover:text-fiji-dark-blue transition-colors text-sm">
                    → iTaukei Land Act (Download PDF)
                  </a>
                  <a href="#" className="block text-fiji-blue hover:text-fiji-dark-blue transition-colors text-sm">
                    → Native Land Trust Act
                  </a>
                  <a href="#" className="block text-fiji-blue hover:text-fiji-dark-blue transition-colors text-sm">
                    → Standard Lease Conditions
                  </a>
                  <a href="#" className="block text-fiji-blue hover:text-fiji-dark-blue transition-colors text-sm">
                    → Ground Rent Guidelines
                  </a>
                  <a href="#" className="block text-fiji-blue hover:text-fiji-dark-blue transition-colors text-sm">
                    → Land Court Procedures
                  </a>
                </div>
                
                <div className="mt-4 bg-gray-50 p-3 rounded-lg">
                  <p className="text-sm text-gray-700">
                    <strong>Legal Advice:</strong> For complex land issues, consult with lawyers experienced in Fiji land law. 
                    The Fiji Law Society can provide referrals.
                  </p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Back Navigation */}
        <div className="text-center">
          <Button
            onClick={() => onNavigate('home')}
            variant="outline"
            className="border-fiji-blue text-fiji-blue hover:bg-fiji-light-blue"
          >
            ← Back to BulaRent Home
          </Button>
        </div>
      </div>
    </div>
  );
}