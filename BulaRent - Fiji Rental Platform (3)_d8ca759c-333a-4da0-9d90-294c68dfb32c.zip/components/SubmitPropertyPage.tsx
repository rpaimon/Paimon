import { useState } from 'react';
import { ArrowLeft, Upload, MapPin, DollarSign, Home, Plus, X, CheckCircle } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { useAuth } from './auth/AuthContext';
import { projectId, publicAnonKey } from '../utils/supabase/info';

interface SubmitPropertyPageProps {
  onNavigate: (page: string) => void;
}

interface PropertyFormData {
  title: string;
  description: string;
  location: string;
  nearLandmark: string;
  price: string;
  period: 'per week' | 'per month';
  propertyType: string;
  bedrooms: number;
  bathrooms: number;
  parking: number;
  size: string;
  features: string[];
  images: File[];
  landlordName: string;
  landlordPhone: string;
  landlordEmail: string;
  availableFrom: string;
  leaseTerm: string;
  mpaisaAccepted: boolean;
  wifiIncluded: boolean;
  furnished: boolean;
}

const SUVA_LOCATIONS = [
  'Suva CBD', 'Samabula', 'Nabua', 'Raiwaqa', 'Tamavua', 'Laucala Bay',
  'Nasinu', 'Tacirua', 'Caubati', 'Cunningham', 'Toorak', 'Domain'
];

const LANDMARKS = [
  'USP Main Campus', 'FNU Samabula Campus', 'MHCC Shopping Center', 'Suva Market',
  'FNPF Tower', 'Colonial War Memorial Hospital', 'Fiji Museum', 'Albert Park',
  'Suva Grammar School', 'Marist Brothers High School', 'Vodafone Arena'
];

const PROPERTY_TYPES = [
  'Flat', 'Bure', 'Shared Room', 'Single Room', 'Executive Flat', 'Family Flat',
  'Studio', 'Apartment', 'House', 'Townhouse'
];

const COMMON_FEATURES = [
  'WiFi Included', 'Furnished', 'M-PAiSA Accepted', 'Parking', 'Garden Space',
  'Security', 'Air Conditioning', 'Kitchen', 'Laundry', 'Student Friendly',
  'Family Friendly', 'Pet Friendly', 'Utilities Included', 'City Views'
];

export default function SubmitPropertyPage({ onNavigate }: SubmitPropertyPageProps) {
  const { user, getAccessToken } = useAuth();
  const [currentStep, setCurrentStep] = useState(1);
  const [loading, setLoading] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});
  
  const [formData, setFormData] = useState<PropertyFormData>({
    title: '',
    description: '',
    location: '',
    nearLandmark: '',
    price: '',
    period: 'per week',
    propertyType: '',
    bedrooms: 1,
    bathrooms: 1,
    parking: 0,
    size: '',
    features: [],
    images: [],
    landlordName: '',
    landlordPhone: '',
    landlordEmail: user?.email || '',
    availableFrom: '',
    leaseTerm: '',
    mpaisaAccepted: false,
    wifiIncluded: false,
    furnished: false
  });

  const totalSteps = 4;

  const validateStep = (step: number): boolean => {
    const newErrors: Record<string, string> = {};

    switch (step) {
      case 1: // Basic Information
        if (!formData.title.trim()) newErrors.title = 'Property title is required';
        if (!formData.location) newErrors.location = 'Location is required';
        if (!formData.propertyType) newErrors.propertyType = 'Property type is required';
        if (!formData.price.trim()) newErrors.price = 'Price is required';
        break;
      
      case 2: // Property Details
        if (!formData.description.trim()) newErrors.description = 'Description is required';
        if (formData.bedrooms < 0) newErrors.bedrooms = 'Invalid number of bedrooms';
        if (formData.bathrooms < 0) newErrors.bathrooms = 'Invalid number of bathrooms';
        break;
      
      case 3: // Images
        if (formData.images.length === 0) {
          newErrors.images = 'At least one image is required';
        }
        break;
      
      case 4: // Contact Information
        if (!formData.landlordName.trim()) newErrors.landlordName = 'Your name is required';
        if (!formData.landlordPhone.trim()) newErrors.landlordPhone = 'Phone number is required';
        if (!formData.landlordEmail.trim()) newErrors.landlordEmail = 'Email is required';
        break;
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    setFormData(prev => ({
      ...prev,
      images: [...prev.images, ...files].slice(0, 10) // Max 10 images
    }));
  };

  const removeImage = (index: number) => {
    setFormData(prev => ({
      ...prev,
      images: prev.images.filter((_, i) => i !== index)
    }));
  };

  const toggleFeature = (feature: string) => {
    setFormData(prev => ({
      ...prev,
      features: prev.features.includes(feature)
        ? prev.features.filter(f => f !== feature)
        : [...prev.features, feature]
    }));
  };

  const submitProperty = async () => {
    if (!user) {
      alert('Please sign in to submit a property');
      return;
    }

    setLoading(true);
    try {
      const token = getAccessToken();
      
      const propertyData = {
        ...formData,
        id: `prop_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
        submittedBy: user.id,
        submittedAt: new Date().toISOString(),
        status: 'pending',
        // Convert File objects to URLs for demo
        imageUrls: formData.images.map((_, index) => 
          `https://images.unsplash.com/photo-${1580000000000 + index}?w=800&h=600&fit=crop&auto=format`
        )
      };

      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-304c8b39/properties`,
        {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json'
          },
          body: JSON.stringify(propertyData)
        }
      );

      if (response.ok) {
        setSubmitted(true);
      } else {
        const errorData = await response.json().catch(() => ({ error: 'Unknown error' }));
        throw new Error(errorData.error || 'Failed to submit property');
      }
    } catch (error) {
      console.error('Submission error:', error);
      setErrors({ general: `Submission failed: ${error.message}` });
    } finally {
      setLoading(false);
    }
  };

  if (!user) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-green-50 to-blue-50 flex items-center justify-center p-4">
        <Card className="max-w-md w-full p-8 text-center">
          <div className="text-6xl mb-4">🏠</div>
          <h2 className="text-2xl font-bold mb-4">List Your Property</h2>
          <p className="text-gray-600 mb-6">
            Please sign in to submit your property listing.
          </p>
          <Button 
            onClick={() => onNavigate('home')}
            className="bg-tropical-green text-white"
          >
            Sign In
          </Button>
        </Card>
      </div>
    );
  }

  if (submitted) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-green-50 to-blue-50 flex items-center justify-center p-4">
        <Card className="max-w-2xl w-full p-8 text-center">
          <div className="text-6xl mb-6">🎉</div>
          <h2 className="text-3xl font-bold text-green-800 mb-4">Property Submitted!</h2>
          <p className="text-lg text-gray-600 mb-6">
            Your property listing has been submitted for review. We'll review it within 24 hours 
            and notify you once it's approved and live on BulaRent.
          </p>
          
          <div className="bg-blue-50 border border-blue-200 rounded-xl p-6 mb-6">
            <h3 className="font-bold text-blue-800 mb-3">What happens next?</h3>
            <ul className="text-left text-blue-700 space-y-2">
              <li>• Our team will review your listing for accuracy</li>
              <li>• We'll verify property details and images</li>
              <li>• You'll receive an email notification about approval status</li>
              <li>• Once approved, your listing will be visible to tenants</li>
              <li>• You can manage your listings from your dashboard</li>
            </ul>
          </div>

          <div className="flex gap-4 justify-center">
            <Button 
              onClick={() => onNavigate('dashboard')}
              className="bg-tropical-green text-white"
            >
              Go to Dashboard
            </Button>
            <Button 
              onClick={() => onNavigate('listings')}
              variant="outline"
            >
              Browse Properties
            </Button>
          </div>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-blue-50">
      {/* Header */}
      <div className="bg-white shadow-sm">
        <div className="max-w-4xl mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <button
                onClick={() => onNavigate('home')}
                className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
              >
                <ArrowLeft size={20} />
              </button>
              <div>
                <h1 className="text-2xl font-bold text-gray-900">List Your Property</h1>
                <p className="text-gray-600">Share your property with trusted tenants</p>
              </div>
            </div>
            <Badge className="bg-tropical-green text-white px-4 py-2">
              <Home size={16} className="mr-2" />
              Free Listing
            </Badge>
          </div>
        </div>
      </div>

      {/* Progress Indicator */}
      <div className="max-w-4xl mx-auto px-4 py-8">
        <div className="flex items-center justify-between mb-8">
          {[1, 2, 3, 4].map((step) => (
            <div key={step} className="flex items-center">
              <div className={`w-10 h-10 rounded-full flex items-center justify-center font-bold ${
                step <= currentStep 
                  ? 'bg-tropical-green text-white' 
                  : 'bg-gray-200 text-gray-500'
              }`}>
                {step < currentStep ? <CheckCircle size={20} /> : step}
              </div>
              {step < totalSteps && (
                <div className={`w-20 h-1 ${
                  step < currentStep ? 'bg-tropical-green' : 'bg-gray-200'
                }`} />
              )}
            </div>
          ))}
        </div>

        <Card className="p-8">
          {errors.general && (
            <div className="bg-red-50 border border-red-200 text-red-700 p-4 rounded-xl mb-6">
              {errors.general}
            </div>
          )}

          {/* Step 1: Basic Information */}
          {currentStep === 1 && (
            <div className="space-y-6">
              <div className="text-center mb-8">
                <div className="text-4xl mb-4">🏠</div>
                <h2 className="text-2xl font-bold mb-2">Basic Information</h2>
                <p className="text-gray-600">Tell us about your property</p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="md:col-span-2">
                  <Label htmlFor="title">Property Title *</Label>
                  <Input
                    id="title"
                    placeholder="e.g. Modern Flat near USP Campus"
                    value={formData.title}
                    onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                    className={errors.title ? 'border-red-300' : ''}
                  />
                  {errors.title && <p className="text-red-500 text-sm mt-1">{errors.title}</p>}
                </div>

                <div>
                  <Label htmlFor="location">Location *</Label>
                  <Select value={formData.location} onValueChange={(value) => setFormData({ ...formData, location: value })}>
                    <SelectTrigger className={errors.location ? 'border-red-300' : ''}>
                      <SelectValue placeholder="Select location" />
                    </SelectTrigger>
                    <SelectContent>
                      {SUVA_LOCATIONS.map((location) => (
                        <SelectItem key={location} value={location}>
                          {location}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  {errors.location && <p className="text-red-500 text-sm mt-1">{errors.location}</p>}
                </div>

                <div>
                  <Label htmlFor="landmark">Near Landmark</Label>
                  <Select value={formData.nearLandmark} onValueChange={(value) => setFormData({ ...formData, nearLandmark: value })}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select nearby landmark" />
                    </SelectTrigger>
                    <SelectContent>
                      {LANDMARKS.map((landmark) => (
                        <SelectItem key={landmark} value={landmark}>
                          {landmark}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="propertyType">Property Type *</Label>
                  <Select value={formData.propertyType} onValueChange={(value) => setFormData({ ...formData, propertyType: value })}>
                    <SelectTrigger className={errors.propertyType ? 'border-red-300' : ''}>
                      <SelectValue placeholder="Select property type" />
                    </SelectTrigger>
                    <SelectContent>
                      {PROPERTY_TYPES.map((type) => (
                        <SelectItem key={type} value={type}>
                          {type}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  {errors.propertyType && <p className="text-red-500 text-sm mt-1">{errors.propertyType}</p>}
                </div>

                <div>
                  <Label htmlFor="price">Price *</Label>
                  <div className="flex gap-2">
                    <Input
                      id="price"
                      placeholder="280"
                      value={formData.price}
                      onChange={(e) => setFormData({ ...formData, price: e.target.value })}
                      className={errors.price ? 'border-red-300' : ''}
                    />
                    <Select value={formData.period} onValueChange={(value: 'per week' | 'per month') => setFormData({ ...formData, period: value })}>
                      <SelectTrigger className="w-32">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="per week">per week</SelectItem>
                        <SelectItem value="per month">per month</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  {errors.price && <p className="text-red-500 text-sm mt-1">{errors.price}</p>}
                </div>
              </div>
            </div>
          )}

          {/* Step 2: Property Details */}
          {currentStep === 2 && (
            <div className="space-y-6">
              <div className="text-center mb-8">
                <div className="text-4xl mb-4">📋</div>
                <h2 className="text-2xl font-bold mb-2">Property Details</h2>
                <p className="text-gray-600">Provide detailed information about your property</p>
              </div>

              <div>
                <Label htmlFor="description">Description *</Label>
                <Textarea
                  id="description"
                  placeholder="Describe your property, its features, and what makes it special..."
                  rows={4}
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  className={errors.description ? 'border-red-300' : ''}
                />
                {errors.description && <p className="text-red-500 text-sm mt-1">{errors.description}</p>}
              </div>

              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div>
                  <Label htmlFor="bedrooms">Bedrooms</Label>
                  <Input
                    id="bedrooms"
                    type="number"
                    min="0"
                    value={formData.bedrooms}
                    onChange={(e) => setFormData({ ...formData, bedrooms: parseInt(e.target.value) || 0 })}
                  />
                </div>
                <div>
                  <Label htmlFor="bathrooms">Bathrooms</Label>
                  <Input
                    id="bathrooms"
                    type="number"
                    min="0"
                    value={formData.bathrooms}
                    onChange={(e) => setFormData({ ...formData, bathrooms: parseInt(e.target.value) || 0 })}
                  />
                </div>
                <div>
                  <Label htmlFor="parking">Parking Spaces</Label>
                  <Input
                    id="parking"
                    type="number"
                    min="0"
                    value={formData.parking}
                    onChange={(e) => setFormData({ ...formData, parking: parseInt(e.target.value) || 0 })}
                  />
                </div>
                <div>
                  <Label htmlFor="size">Size (sq ft)</Label>
                  <Input
                    id="size"
                    placeholder="800"
                    value={formData.size}
                    onChange={(e) => setFormData({ ...formData, size: e.target.value })}
                  />
                </div>
              </div>

              <div>
                <Label>Property Features</Label>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-3 mt-3">
                  {COMMON_FEATURES.map((feature) => (
                    <button
                      key={feature}
                      type="button"
                      onClick={() => toggleFeature(feature)}
                      className={`p-3 rounded-lg border text-sm text-left transition-colors ${
                        formData.features.includes(feature)
                          ? 'border-tropical-green bg-green-50 text-tropical-green'
                          : 'border-gray-200 hover:border-gray-300'
                      }`}
                    >
                      {feature}
                    </button>
                  ))}
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <Label htmlFor="availableFrom">Available From</Label>
                  <Input
                    id="availableFrom"
                    type="date"
                    value={formData.availableFrom}
                    onChange={(e) => setFormData({ ...formData, availableFrom: e.target.value })}
                  />
                </div>
                <div>
                  <Label htmlFor="leaseTerm">Minimum Lease Term</Label>
                  <Select value={formData.leaseTerm} onValueChange={(value) => setFormData({ ...formData, leaseTerm: value })}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select lease term" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="1 month">1 month</SelectItem>
                      <SelectItem value="3 months">3 months</SelectItem>
                      <SelectItem value="6 months">6 months</SelectItem>
                      <SelectItem value="12 months">12 months</SelectItem>
                      <SelectItem value="24 months">24 months</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </div>
          )}

          {/* Step 3: Images */}
          {currentStep === 3 && (
            <div className="space-y-6">
              <div className="text-center mb-8">
                <div className="text-4xl mb-4">📸</div>
                <h2 className="text-2xl font-bold mb-2">Property Images</h2>
                <p className="text-gray-600">Upload clear, high-quality photos of your property</p>
              </div>

              <div className="border-2 border-dashed border-gray-300 rounded-xl p-8 text-center">
                <Upload className="mx-auto mb-4 text-gray-400" size={48} />
                <input
                  type="file"
                  accept="image/*"
                  multiple
                  onChange={handleImageUpload}
                  className="hidden"
                  id="image-upload"
                />
                <label htmlFor="image-upload" className="cursor-pointer">
                  <div className="text-lg font-medium text-gray-700 mb-2">
                    Click to upload images
                  </div>
                  <div className="text-sm text-gray-500">
                    PNG, JPG up to 10MB each • Maximum 10 images
                  </div>
                </label>
              </div>

              {formData.images.length > 0 && (
                <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                  {formData.images.map((image, index) => (
                    <div key={index} className="relative">
                      <img
                        src={URL.createObjectURL(image)}
                        alt={`Property ${index + 1}`}
                        className="w-full h-32 object-cover rounded-lg"
                      />
                      <button
                        onClick={() => removeImage(index)}
                        className="absolute top-2 right-2 bg-red-500 text-white p-1 rounded-full hover:bg-red-600"
                      >
                        <X size={14} />
                      </button>
                    </div>
                  ))}
                </div>
              )}
              
              {errors.images && <p className="text-red-500 text-sm">{errors.images}</p>}
            </div>
          )}

          {/* Step 4: Contact Information */}
          {currentStep === 4 && (
            <div className="space-y-6">
              <div className="text-center mb-8">
                <div className="text-4xl mb-4">📞</div>
                <h2 className="text-2xl font-bold mb-2">Contact Information</h2>
                <p className="text-gray-600">How can tenants reach you?</p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <Label htmlFor="landlordName">Your Name *</Label>
                  <Input
                    id="landlordName"
                    placeholder="Enter your full name"
                    value={formData.landlordName}
                    onChange={(e) => setFormData({ ...formData, landlordName: e.target.value })}
                    className={errors.landlordName ? 'border-red-300' : ''}
                  />
                  {errors.landlordName && <p className="text-red-500 text-sm mt-1">{errors.landlordName}</p>}
                </div>

                <div>
                  <Label htmlFor="landlordPhone">Phone Number *</Label>
                  <Input
                    id="landlordPhone"
                    placeholder="+679 123 4567"
                    value={formData.landlordPhone}
                    onChange={(e) => setFormData({ ...formData, landlordPhone: e.target.value })}
                    className={errors.landlordPhone ? 'border-red-300' : ''}
                  />
                  {errors.landlordPhone && <p className="text-red-500 text-sm mt-1">{errors.landlordPhone}</p>}
                </div>

                <div className="md:col-span-2">
                  <Label htmlFor="landlordEmail">Email Address *</Label>
                  <Input
                    id="landlordEmail"
                    type="email"
                    placeholder="your.email@example.com"
                    value={formData.landlordEmail}
                    onChange={(e) => setFormData({ ...formData, landlordEmail: e.target.value })}
                    className={errors.landlordEmail ? 'border-red-300' : ''}
                  />
                  {errors.landlordEmail && <p className="text-red-500 text-sm mt-1">{errors.landlordEmail}</p>}
                </div>
              </div>

              <div className="bg-green-50 border border-green-200 rounded-xl p-6">
                <h4 className="font-medium text-green-800 mb-3">🔒 Privacy & Safety</h4>
                <ul className="text-sm text-green-700 space-y-1">
                  <li>• Your contact information is only shown to signed-in users</li>
                  <li>• We verify all user accounts to prevent spam</li>
                  <li>• You can update your contact details anytime</li>
                  <li>• Report any suspicious inquiries to our support team</li>
                </ul>
              </div>
            </div>
          )}

          {/* Navigation Buttons */}
          <div className="flex justify-between mt-8 pt-6 border-t">
            <Button
              onClick={() => setCurrentStep(Math.max(1, currentStep - 1))}
              variant="outline"
              disabled={currentStep === 1}
            >
              <ArrowLeft className="mr-2" size={18} />
              Previous
            </Button>

            {currentStep < totalSteps ? (
              <Button
                onClick={() => {
                  if (validateStep(currentStep)) {
                    setCurrentStep(currentStep + 1);
                  }
                }}
                className="bg-tropical-green text-white"
              >
                Continue
                <ArrowLeft className="ml-2 rotate-180" size={18} />
              </Button>
            ) : (
              <Button
                onClick={submitProperty}
                disabled={loading}
                className="bg-gradient-to-r from-tropical-green to-green-600 text-white px-8"
              >
                {loading ? (
                  <div className="flex items-center gap-2">
                    <div className="animate-spin h-4 w-4 border-2 border-white border-t-transparent rounded-full" />
                    Submitting...
                  </div>
                ) : (
                  <>
                    <Home className="mr-2" size={18} />
                    Submit Property
                  </>
                )}
              </Button>
            )}
          </div>
        </Card>
      </div>
    </div>
  );
}