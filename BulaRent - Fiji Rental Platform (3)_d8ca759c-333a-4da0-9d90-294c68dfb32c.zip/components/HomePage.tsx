import { useState } from 'react';
import { Search, MapPin, Shield, Star, Phone, MessageSquare, ChevronRight, AlertTriangle, Play, ArrowRight } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';
import SuvaLocalSearch from './SuvaLocalSearch';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import tropicalBeachBg from 'figma:asset/e0825557a44aaa6a6fdec5e79d5f816f3ada36b6.png';

interface HomePageProps {
  onNavigate: (page: string, propertyId?: string) => void;
}

export default function HomePage({ onNavigate }: HomePageProps) {
  const [searchResults, setSearchResults] = useState<any[]>([]);
  const [playingVideo, setPlayingVideo] = useState(false);

  // Suva-focused sample properties with local terminology and landmarks
  const featuredListings = [
    {
      id: 'sample-1',
      title: 'Modern Flat near USP Campus',
      location: 'Laucala Bay',
      nearLandmark: '500m from USP Main Entrance',
      price: 'FJD $280',
      period: 'per week',
      bedrooms: 2,
      bathrooms: 1,
      parking: 1,
      type: 'Flat',
      image: 'https://images.unsplash.com/photo-1522708323590-d24dbb6b0267?w=500&h=300&fit=crop',
      description: 'Perfect for students! Walking distance to USP, furnished flat with WiFi included.',
      features: ['WiFi Included', 'Furnished', 'M-PAiSA Accepted', 'Student Friendly'],
      verified: true,
      landlordVerified: true,
      views: 45,
      favorites: 12,
      ownerId: 'verified-landlord-1',
      weeklyRent: 280,
      mpaisaAccepted: true,
      wifiIncluded: true
    },
    {
      id: 'sample-2',
      title: 'Traditional Bure in Tamavua Heights',
      location: 'Tamavua',
      nearLandmark: '1km from MHCC Shopping Center',
      price: 'FJD $220',
      period: 'per week',
      bedrooms: 3,
      bathrooms: 2,
      parking: 2,
      type: 'Bure',
      image: 'https://images.unsplash.com/photo-1571003123894-1f0594d2b5d9?w=500&h=300&fit=crop',
      description: 'Authentic Fijian bure with modern amenities. Great for families, garden space included.',
      features: ['Garden Space', 'Traditional Design', 'Family Friendly', 'Parking'],
      verified: true,
      landlordVerified: true,
      views: 32,
      favorites: 18,
      ownerId: 'verified-landlord-2',
      weeklyRent: 220,
      mpaisaAccepted: true,
      wifiIncluded: false
    },
    {
      id: 'sample-3',
      title: 'Shared Room near FNU Samabula',
      location: 'Samabula',
      nearLandmark: '300m from FNU Campus',
      price: 'FJD $120',
      period: 'per week',
      bedrooms: 1,
      bathrooms: 1,
      parking: 0,
      type: 'Shared Room',
      image: 'https://images.unsplash.com/photo-1584132915807-fd1f5fbc078f?w=500&h=300&fit=crop',
      description: 'Budget-friendly shared accommodation for students. All utilities included.',
      features: ['Utilities Included', 'Student Housing', 'Shared Kitchen', 'WiFi Included'],
      verified: false,
      landlordVerified: false,
      views: 28,
      favorites: 8,
      ownerId: 'unverified-landlord-1',
      weeklyRent: 120,
      mpaisaAccepted: false,
      wifiIncluded: true
    },
    {
      id: 'sample-4',
      title: 'Executive Flat in Suva CBD',
      location: 'Suva CBD',
      nearLandmark: '200m from FNPF Tower',
      price: 'FJD $450',
      period: 'per week',
      bedrooms: 2,
      bathrooms: 2,
      parking: 1,
      type: 'Executive Flat',
      image: 'https://images.unsplash.com/photo-1545324418-cc1a3fa10c00?w=500&h=300&fit=crop',
      description: 'Premium executive flat in CBD. Perfect for professionals, city views.',
      features: ['City Views', 'Executive', 'Furnished', 'Security', 'M-PAiSA Accepted'],
      verified: true,
      landlordVerified: true,
      views: 67,
      favorites: 23,
      ownerId: 'premium-landlord-1',
      weeklyRent: 450,
      mpaisaAccepted: true,
      wifiIncluded: true
    },
    {
      id: 'sample-5',
      title: 'Single Room in Nabua',
      location: 'Nabua',
      nearLandmark: '800m from Suva Market',
      price: 'FJD $150',
      period: 'per week',
      bedrooms: 1,
      bathrooms: 1,
      parking: 0,
      type: 'Single Room',
      image: 'https://images.unsplash.com/photo-1586023492125-27b2c045efd7?w=500&h=300&fit=crop',
      description: 'Affordable single room with own bathroom. Good transport links to CBD.',
      features: ['Own Bathroom', 'Transport Links', 'Affordable', 'Local Area'],
      verified: true,
      landlordVerified: true,
      views: 34,
      favorites: 9,
      ownerId: 'verified-landlord-3',
      weeklyRent: 150,
      mpaisaAccepted: true,
      wifiIncluded: false
    },
    {
      id: 'sample-6',
      title: 'Family Flat in Raiwaqa',
      location: 'Raiwaqa',
      nearLandmark: '600m from Colonial War Memorial Hospital',
      price: 'FJD $320',
      period: 'per week',
      bedrooms: 3,
      bathrooms: 2,
      parking: 2,
      type: 'Family Flat',
      image: 'https://images.unsplash.com/photo-1598300042247-d088f8ab3a91?w=500&h=300&fit=crop',
      description: 'Spacious family flat with garden. Close to hospital and schools.',
      features: ['Garden', 'Family Friendly', 'Near Hospital', 'School Zone', 'Parking'],
      verified: true,
      landlordVerified: true,
      views: 41,
      favorites: 16,
      ownerId: 'verified-landlord-4',
      weeklyRent: 320,
      mpaisaAccepted: true,
      wifiIncluded: true
    }
  ];

  const suvaStats = [
    { number: '200+', label: 'Verified Properties', icon: '🏠' },
    { number: '150+', label: 'Verified Landlords', icon: '✅' },
    { number: '98%', label: 'Tenant Satisfaction', icon: '⭐' },
    { number: '24/7', label: 'Support', icon: '📞' }
  ];

  const handleSearch = (filters: any) => {
    console.log('Search filters:', filters);
    // Apply filters and navigate to listings
    onNavigate('listings');
  };

  const handlePropertyClick = (propertyId: string) => {
    // Navigate to property details page
    onNavigate('property-details', propertyId);
  };

  return (
    <div className="min-h-screen">
      {/* Custom CSS Styles */}
      <style>
        {`
          @keyframes fade-in-up {
            from {
              opacity: 0;
              transform: translateY(30px);
            }
            to {
              opacity: 1;
              transform: translateY(0);
            }
          }

          @keyframes parallax-float {
            0%, 100% { 
              transform: scale(1.1) translateY(0px); 
            }
            50% { 
              transform: scale(1.15) translateY(-10px); 
            }
          }

          .animate-fade-in-up {
            animation: fade-in-up 0.8s ease-out forwards;
            opacity: 0;
          }

          .parallax-bg {
            animation: parallax-float 20s ease-in-out infinite;
          }
        `}
      </style>

      {/* ADVANCED HERO SECTION - Modern Glass Morphism */}
      <div className="relative overflow-hidden">
        {/* Background with Parallax Effect */}
        <div 
          className="absolute inset-0 bg-cover bg-center transform scale-110 transition-transform duration-1000 ease-out parallax-bg"
          style={{
            backgroundImage: `url(${tropicalBeachBg})`,
            backgroundSize: 'cover',
            backgroundPosition: 'center'
          }}
        />
        
        {/* Advanced Overlay System */}
        <div className="absolute inset-0 bg-gradient-to-br from-fiji-blue/10 via-tropical-green/15 to-fiji-dark-blue/20" />
        <div className="absolute inset-0 bg-gradient-to-t from-black/30 via-transparent to-black/10" />
        <div className="absolute inset-0 backdrop-blur-[0.5px]" />

        {/* Hero Content */}
        <div className="relative min-h-[80vh] md:min-h-[90vh] flex items-center justify-center">
          <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            {/* Animated Logo/Brand */}
            <div className="mb-8 animate-fade-in-up">
              <div className="inline-flex items-center gap-4 bg-white/10 backdrop-blur-md rounded-2xl px-6 py-3 border border-white/20">
                <div className="bg-tropical-green text-white px-4 py-2 rounded-xl font-bold text-xl">BR</div>
                <span className="text-white font-bold text-2xl">BulaRent</span>
                <Badge className="bg-fiji-orange text-white">Suva MVP</Badge>
              </div>
            </div>

            {/* Main Hero Text with Typewriter Effect */}
            <h1 className="text-4xl md:text-6xl lg:text-7xl font-bold mb-6 text-white drop-shadow-2xl animate-fade-in-up" style={{ animationDelay: '0.2s' }}>
              Bula! Find Your Perfect
              <br />
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-yellow-200 via-yellow-300 to-orange-200 animate-pulse">
                Fiji Paradise
              </span>
            </h1>

            <p className="text-xl md:text-2xl lg:text-3xl mb-8 text-white/90 drop-shadow-lg animate-fade-in-up" style={{ animationDelay: '0.4s' }}>
              🌺 Ultra-local search • Verified landlords • M-PAiSA ready 🌺
            </p>

            {/* Interactive Stats with Glass Morphism */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-12 animate-fade-in-up" style={{ animationDelay: '0.6s' }}>
              {suvaStats.map((stat, index) => (
                <div 
                  key={index} 
                  className="bg-white/10 backdrop-blur-xl rounded-2xl p-4 border border-white/20 shadow-2xl hover:bg-white/15 transition-all duration-300 transform hover:scale-105 hover:-translate-y-1"
                >
                  <div className="text-3xl mb-2">{stat.icon}</div>
                  <div className="font-bold text-2xl md:text-3xl text-white">{stat.number}</div>
                  <div className="text-sm md:text-base text-white/80">{stat.label}</div>
                </div>
              ))}
            </div>

            {/* CTA Buttons with Advanced Effects */}
            <div className="flex flex-col sm:flex-row gap-4 justify-center items-center mb-12 animate-fade-in-up" style={{ animationDelay: '0.8s' }}>
              <Button
                onClick={() => onNavigate('listings')}
                className="group bg-gradient-to-r from-tropical-green to-green-600 text-white px-8 py-4 text-lg rounded-2xl font-bold shadow-2xl hover:shadow-tropical-green/50 transition-all duration-300 transform hover:scale-105 hover:-translate-y-1"
              >
                <Search className="mr-2 group-hover:rotate-12 transition-transform" size={20} />
                Browse Suva Properties
                <ArrowRight className="ml-2 group-hover:translate-x-1 transition-transform" size={20} />
              </Button>

              <Button
                onClick={() => onNavigate('submit')}
                className="group bg-gradient-to-r from-fiji-orange to-orange-600 text-white px-8 py-4 text-lg rounded-2xl font-bold shadow-2xl hover:shadow-fiji-orange/50 transition-all duration-300 transform hover:scale-105 hover:-translate-y-1"
              >
                <span className="mr-2">🏠</span>
                List Your Property
                <ArrowRight className="ml-2 group-hover:translate-x-1 transition-transform" size={20} />
              </Button>

              <Button
                onClick={() => setPlayingVideo(true)}
                variant="outline"
                className="group bg-white/10 backdrop-blur-md border-white/30 text-white px-6 py-4 text-lg rounded-2xl font-bold hover:bg-white/20 transition-all duration-300"
              >
                <Play className="mr-2 group-hover:scale-110 transition-transform" size={20} />
                Watch Demo
              </Button>
            </div>

            {/* Trust Indicators with Animation */}
            <div className="flex flex-wrap justify-center gap-4 animate-fade-in-up" style={{ animationDelay: '1s' }}>
              <Badge className="bg-white/10 backdrop-blur-md border-white/30 text-white px-4 py-2 text-sm hover:bg-white/20 transition-all duration-300">
                <Shield className="mr-2" size={16} />
                🇫🇯 Fiji Landlord Verification
              </Badge>
              <Badge className="bg-white/10 backdrop-blur-md border-white/30 text-white px-4 py-2 text-sm hover:bg-white/20 transition-all duration-300">
                <span className="mr-2">💳</span>
                M-PAiSA Integration
              </Badge>
              <Badge className="bg-white/10 backdrop-blur-md border-white/30 text-white px-4 py-2 text-sm hover:bg-white/20 transition-all duration-300">
                <span className="mr-2">🏛️</span>
                Fiji Police Partnership
              </Badge>
            </div>
          </div>
        </div>

        {/* Floating Elements */}
        <div className="absolute top-20 left-10 w-20 h-20 bg-white/10 rounded-full backdrop-blur-sm animate-bounce" style={{ animationDelay: '0s', animationDuration: '3s' }} />
        <div className="absolute top-40 right-20 w-12 h-12 bg-tropical-green/20 rounded-full backdrop-blur-sm animate-bounce" style={{ animationDelay: '1s', animationDuration: '4s' }} />
        <div className="absolute bottom-40 left-20 w-16 h-16 bg-fiji-orange/20 rounded-full backdrop-blur-sm animate-bounce" style={{ animationDelay: '2s', animationDuration: '5s' }} />
      </div>

      {/* Ultra-Local Search Section */}
      <div className="py-12 md:py-16 bg-gradient-to-b from-white to-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <SuvaLocalSearch onSearch={handleSearch} />
        </div>
      </div>

      {/* Featured Properties Section */}
      <div className="py-12 md:py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              🏡 Verified Properties in Suva 🏡
            </h2>
            <p className="text-xl text-gray-600 mb-6">
              Trusted landlords • Local terminology • M-PAiSA ready
            </p>
            <Badge className="bg-tropical-green text-white text-lg px-6 py-2">
              🔍 Showing verified listings first
            </Badge>
          </div>

          {/* Properties Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {featuredListings.map((listing) => (
              <div
                key={listing.id}
                className="group bg-white rounded-2xl shadow-xl overflow-hidden hover:shadow-2xl transition-all duration-500 cursor-pointer border border-gray-100 hover:border-tropical-green/30 transform hover:-translate-y-2"
                onClick={() => handlePropertyClick(listing.id)}
              >
                <div className="relative">
                  <ImageWithFallback
                    src={listing.image}
                    alt={listing.title}
                    className="w-full h-56 object-cover group-hover:scale-110 transition-transform duration-500"
                  />
                  
                  {/* Enhanced Overlay */}
                  <div className="absolute inset-0 bg-gradient-to-t from-black/50 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                  
                  {/* Price Badge */}
                  <div className="absolute top-4 right-4 bg-tropical-green text-white px-4 py-2 rounded-xl font-bold shadow-lg">
                    {listing.price}
                  </div>
                  
                  {/* Verification Badge */}
                  <div className="absolute top-4 left-4">
                    {listing.landlordVerified ? (
                      <Badge className="verified-badge">
                        <Shield size={12} className="mr-1" />
                        VERIFIED
                      </Badge>
                    ) : (
                      <Badge className="unverified-badge">
                        🚨 UNVERIFIED
                      </Badge>
                    )}
                  </div>

                  {/* Property Type */}
                  <div className="absolute bottom-4 left-4">
                    <Badge className="bg-white/95 text-gray-800 px-3 py-1">
                      {listing.type}
                    </Badge>
                  </div>

                  {/* M-PAiSA Badge */}
                  {listing.mpaisaAccepted && (
                    <div className="absolute bottom-4 right-4">
                      <Badge className="bg-purple-600 text-white px-3 py-1">
                        💳 M-PAiSA
                      </Badge>
                    </div>
                  )}
                </div>
                
                <div className="p-6">
                  <h3 className="font-bold text-xl text-gray-900 mb-3 group-hover:text-tropical-green transition-colors">
                    {listing.title}
                  </h3>
                  
                  {/* Location with Landmark */}
                  <div className="space-y-2 mb-4">
                    <div className="flex items-center text-gray-600">
                      <MapPin size={16} className="mr-2" />
                      <span>{listing.location}</span>
                    </div>
                    <div className="landmark-tag">
                      📍 {listing.nearLandmark}
                    </div>
                  </div>
                  
                  {/* Features */}
                  <div className="flex flex-wrap gap-2 mb-4">
                    {listing.features.slice(0, 3).map((feature, index) => (
                      <span 
                        key={index}
                        className="bg-gray-100 text-gray-600 px-3 py-1 rounded-full text-sm"
                      >
                        {feature}
                      </span>
                    ))}
                    {listing.features.length > 3 && (
                      <span className="text-sm text-gray-500">
                        +{listing.features.length - 3} more
                      </span>
                    )}
                  </div>
                  
                  {/* Property Details */}
                  <div className="flex items-center justify-between text-gray-500 mb-6">
                    <div className="flex items-center gap-4">
                      <span>{listing.bedrooms} bed</span>
                      <span>{listing.bathrooms} bath</span>
                      {listing.parking > 0 && <span>{listing.parking} park</span>}
                    </div>
                    <div className="flex items-center gap-1">
                      <Star size={16} className="text-yellow-400 fill-current" />
                      <span>4.{Math.floor(Math.random() * 9) + 1}</span>
                    </div>
                  </div>

                  {/* Action Buttons */}
                  <div className="flex gap-2">
                    <Button 
                      className="flex-1 bg-tropical-green hover:bg-green-600 text-white rounded-xl"
                      onClick={(e) => {
                        e.stopPropagation();
                        handlePropertyClick(listing.id);
                      }}
                    >
                      View Details
                    </Button>
                    <Button 
                      variant="outline" 
                      className="p-3 border-tropical-green text-tropical-green hover:bg-green-50"
                      onClick={(e) => {
                        e.stopPropagation();
                        alert('🔒 Please sign in to view contact information');
                      }}
                    >
                      <Phone size={16} />
                    </Button>
                    <Button 
                      variant="outline" 
                      className="p-3 border-fiji-blue text-fiji-blue hover:bg-blue-50"
                      onClick={(e) => {
                        e.stopPropagation();
                        alert('🔒 Please sign in to start a conversation');
                      }}
                    >
                      <MessageSquare size={16} />
                    </Button>
                  </div>
                </div>
              </div>
            ))}
          </div>

          <div className="text-center mt-12">
            <Button
              onClick={() => onNavigate('listings')}
              className="bg-tropical-green hover:bg-green-600 text-white px-8 py-4 text-lg rounded-2xl font-bold shadow-xl hover:shadow-2xl transition-all duration-300 transform hover:scale-105"
            >
              🔍 Browse All Suva Properties
              <ChevronRight className="ml-2" size={20} />
            </Button>
          </div>
        </div>
      </div>

      {/* Trust & Safety Section */}
      <div className="py-16 bg-gradient-to-br from-green-50 to-blue-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-green-800 mb-4">
              🌺 Why Choose BulaRent Suva? 🌺
            </h2>
            <p className="text-xl text-green-700">
              Fiji's first verified rental platform with authentic local vibe
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
            <div className="group text-center p-8 bg-white rounded-2xl shadow-xl border border-green-100 hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-2">
              <div className="bg-tropical-green rounded-full w-20 h-20 flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-transform duration-300">
                <Shield className="text-white" size={32} />
              </div>
              <h3 className="font-bold text-2xl mb-4 text-green-800">
                🇫🇯 Verified Landlords
              </h3>
              <p className="text-gray-700 mb-4">
                Fiji ID + video verification ensures legitimate property owners only.
              </p>
              <Badge className="premium-badge">
                98% Verified Success Rate
              </Badge>
            </div>
            
            <div className="group text-center p-8 bg-white rounded-2xl shadow-xl border border-blue-100 hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-2">
              <div className="bg-fiji-blue rounded-full w-20 h-20 flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-transform duration-300">
                <MapPin className="text-white" size={32} />
              </div>
              <h3 className="font-bold text-2xl mb-4 text-green-800">
                🗺️ Ultra-Local Search
              </h3>
              <p className="text-gray-700 mb-4">
                Find rentals by landmark proximity: USP, MHCC, Suva Market, FNPF Tower.
              </p>
              <Badge className="landmark-tag">
                10+ Major Landmarks
              </Badge>
            </div>
            
            <div className="group text-center p-8 bg-white rounded-2xl shadow-xl border border-purple-100 hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-2">
              <div className="bg-purple-600 rounded-full w-20 h-20 flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-transform duration-300">
                <span className="text-white font-bold text-2xl">M₽</span>
              </div>
              <h3 className="font-bold text-2xl mb-4 text-green-800">
                💳 M-PAiSA Integration
              </h3>
              <p className="text-gray-700 mb-4">
                Secure deposits via M-PAiSA with automatic receipts and tracking.
              </p>
              <Badge className="mpaisa-button">
                100% Secure
              </Badge>
            </div>
          </div>

          {/* Scam Prevention */}
          <div className="bg-red-50 border-2 border-red-200 rounded-2xl p-8 text-center shadow-lg">
            <div className="flex items-center justify-center gap-3 mb-4">
              <AlertTriangle className="text-red-600" size={32} />
              <h3 className="font-bold text-2xl text-red-800">🚨 Scam Prevention</h3>
            </div>
            <p className="text-red-700 text-lg mb-6">
              We automatically flag suspicious listings and provide direct reporting to Fiji Police Cyber Unit.
            </p>
            <div className="flex flex-wrap justify-center gap-4">
              <span className="bg-red-100 text-red-700 px-4 py-2 rounded-full font-medium">
                🚫 No non-Fiji numbers
              </span>
              <span className="bg-red-100 text-red-700 px-4 py-2 rounded-full font-medium">
                💰 Market rate validation
              </span>
              <span className="bg-red-100 text-red-700 px-4 py-2 rounded-full font-medium">
                📸 Real photo verification
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* CTA Section */}
      <div className="py-16 bg-gradient-to-r from-tropical-green via-green-600 to-tropical-green text-white relative overflow-hidden">
        <div className="absolute inset-0 bg-black/10" />
        <div className="relative max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">
            🏡 Ready to Find Your Fiji Paradise? 🏡
          </h2>
          <p className="text-xl mb-8 opacity-90">
            Join hundreds of verified tenants and landlords in Suva's most trusted rental community
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button
              onClick={() => onNavigate('listings')}
              className="bg-white text-tropical-green px-8 py-4 text-lg rounded-2xl font-bold hover:bg-gray-100 transition-all duration-300 transform hover:scale-105 shadow-2xl"
            >
              🔍 Browse Suva Rentals
            </Button>
            
            <Button
              onClick={() => onNavigate('submit')}
              className="bg-fiji-orange text-white px-8 py-4 text-lg rounded-2xl font-bold hover:bg-orange-600 transition-all duration-300 transform hover:scale-105 shadow-2xl"
            >
              📝 List Your Property
            </Button>
          </div>

          <p className="text-sm mt-6 opacity-75">
            First 50 landlords get FREE verification badge • Limited time offer 🎁
          </p>
        </div>
      </div>

      {/* Video Modal */}
      {playingVideo && (
        <div className="fixed inset-0 bg-black/90 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl p-6 max-w-4xl w-full">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-2xl font-bold">BulaRent Suva Demo</h3>
              <button
                onClick={() => setPlayingVideo(false)}
                className="text-gray-500 hover:text-gray-700 text-2xl"
              >
                ×
              </button>
            </div>
            <div className="aspect-video bg-gray-200 rounded-xl flex items-center justify-center">
              <p className="text-gray-600">Demo video would play here</p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}