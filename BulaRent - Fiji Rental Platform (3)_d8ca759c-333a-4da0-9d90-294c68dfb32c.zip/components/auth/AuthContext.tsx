import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';

// Mock user interface for demo purposes
interface User {
  id: string;
  email: string;
  name?: string;
  userType?: 'tenant' | 'landlord';
  verified?: boolean;
}

interface AuthContextType {
  user: User | null;
  loading: boolean;
  signIn: (email: string, password: string) => Promise<void>;
  signUp: (email: string, password: string, metadata?: any) => Promise<void>;
  signOut: () => Promise<void>;
  getAccessToken: () => string | null;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

interface AuthProviderProps {
  children: ReactNode;
}

export const AuthProvider: React.FC<AuthProviderProps> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  // Mock access token
  const [accessToken, setAccessToken] = useState<string | null>(null);

  useEffect(() => {
    // Check for existing session on mount
    const checkExistingSession = () => {
      const savedUser = localStorage.getItem('bularent_user');
      const savedToken = localStorage.getItem('bularent_token');
      
      if (savedUser && savedToken) {
        try {
          setUser(JSON.parse(savedUser));
          setAccessToken(savedToken);
        } catch (error) {
          console.error('Error parsing saved user data:', error);
          localStorage.removeItem('bularent_user');
          localStorage.removeItem('bularent_token');
        }
      }
      setLoading(false);
    };

    checkExistingSession();
  }, []);

  const signIn = async (email: string, password: string): Promise<void> => {
    try {
      setLoading(true);
      
      // Mock authentication - in real app, this would call Supabase
      const mockUser: User = {
        id: `user_${Date.now()}`,
        email,
        name: email.split('@')[0],
        userType: email.includes('landlord') ? 'landlord' : 'tenant',
        verified: Math.random() > 0.5 // Random verification status for demo
      };

      const mockToken = `mock_token_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;

      // Save to localStorage for persistence
      localStorage.setItem('bularent_user', JSON.stringify(mockUser));
      localStorage.setItem('bularent_token', mockToken);

      setUser(mockUser);
      setAccessToken(mockToken);
    } catch (error) {
      console.error('Sign in error:', error);
      throw new Error('Failed to sign in. Please check your credentials.');
    } finally {
      setLoading(false);
    }
  };

  const signUp = async (email: string, password: string, metadata?: any): Promise<void> => {
    try {
      setLoading(true);
      
      // Mock user creation - in real app, this would call Supabase
      const mockUser: User = {
        id: `user_${Date.now()}`,
        email,
        name: metadata?.name || email.split('@')[0],
        userType: metadata?.userType || 'tenant',
        verified: false // New users start unverified
      };

      const mockToken = `mock_token_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;

      // Save to localStorage for persistence
      localStorage.setItem('bularent_user', JSON.stringify(mockUser));
      localStorage.setItem('bularent_token', mockToken);

      setUser(mockUser);
      setAccessToken(mockToken);
    } catch (error) {
      console.error('Sign up error:', error);
      throw new Error('Failed to create account. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const signOut = async (): Promise<void> => {
    try {
      setLoading(true);
      
      // Clear localStorage
      localStorage.removeItem('bularent_user');
      localStorage.removeItem('bularent_token');
      
      setUser(null);
      setAccessToken(null);
    } catch (error) {
      console.error('Sign out error:', error);
      throw new Error('Failed to sign out.');
    } finally {
      setLoading(false);
    }
  };

  const getAccessToken = (): string | null => {
    return accessToken;
  };

  const value: AuthContextType = {
    user,
    loading,
    signIn,
    signUp,
    signOut,
    getAccessToken
  };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
};

export default AuthContext;