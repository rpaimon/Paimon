import { useState } from 'react';
import { X, Mail, Lock, User, Phone, Eye, EyeOff, Github, Facebook, Chrome } from 'lucide-react';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { Badge } from '../ui/badge';
import { Separator } from '../ui/separator';
import { useAuth } from './AuthContext';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialMode?: 'signin' | 'signup';
}

export default function AuthModal({ isOpen, onClose, initialMode = 'signin' }: AuthModalProps) {
  const [mode, setMode] = useState(initialMode);
  const [showPassword, setShowPassword] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    password: '',
    confirmPassword: '',
    phone: '',
    userType: 'tenant' as 'tenant' | 'landlord'
  });
  const [loading, setLoading] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});

  const { signIn, signUp } = useAuth();

  if (!isOpen) return null;

  const validateForm = () => {
    const newErrors: Record<string, string> = {};

    if (mode === 'signup') {
      if (!formData.name.trim()) newErrors.name = 'Name is required';
      if (!formData.phone.trim()) newErrors.phone = 'Phone number is required';
      if (formData.password !== formData.confirmPassword) {
        newErrors.confirmPassword = 'Passwords do not match';
      }
    }

    if (!formData.email.trim()) {
      newErrors.email = 'Email is required';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      newErrors.email = 'Please enter a valid email';
    }

    if (!formData.password.trim()) {
      newErrors.password = 'Password is required';
    } else if (formData.password.length < 6) {
      newErrors.password = 'Password must be at least 6 characters';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validateForm()) return;

    setLoading(true);
    try {
      if (mode === 'signin') {
        await signIn(formData.email, formData.password);
      } else {
        await signUp(formData.email, formData.password, {
          name: formData.name,
          phone: formData.phone,
          userType: formData.userType
        });
      }
      onClose();
    } catch (error) {
      console.error('Auth error:', error);
      setErrors({ general: 'Authentication failed. Please try again.' });
    } finally {
      setLoading(false);
    }
  };

  const handleSocialLogin = async (provider: 'google' | 'facebook' | 'github') => {
    setLoading(true);
    try {
      // In a real implementation, this would trigger OAuth flow
      console.log(`Social login with ${provider}`);
      alert(`${provider} login would open here. Please complete setup at Supabase dashboard.`);
    } catch (error) {
      console.error('Social login error:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-3xl shadow-2xl max-w-lg w-full max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="relative bg-gradient-to-r from-tropical-green to-green-600 text-white p-6 rounded-t-3xl">
          <button
            onClick={onClose}
            className="absolute top-4 right-4 text-white/80 hover:text-white transition-colors p-1"
          >
            <X size={24} />
          </button>
          
          <div className="text-center">
            <div className="inline-flex items-center gap-3 mb-4">
              <div className="bg-white text-tropical-green px-3 py-2 rounded-xl font-bold text-lg">BR</div>
              <span className="font-bold text-2xl">BulaRent</span>
            </div>
            <h2 className="text-2xl font-bold mb-2">
              {mode === 'signin' ? 'Welcome Back!' : 'Join BulaRent'}
            </h2>
            <p className="text-white/90 text-sm">
              {mode === 'signin' 
                ? 'Sign in to access your account' 
                : 'Create your account to get started'
              }
            </p>
          </div>
        </div>

        <div className="p-6">
          {/* Mode Toggle */}
          <div className="flex bg-gray-100 rounded-2xl p-1 mb-6">
            <button
              onClick={() => setMode('signin')}
              className={`flex-1 py-3 rounded-xl font-medium transition-all ${
                mode === 'signin' 
                  ? 'bg-white text-tropical-green shadow-sm' 
                  : 'text-gray-600 hover:text-gray-800'
              }`}
            >
              Sign In
            </button>
            <button
              onClick={() => setMode('signup')}
              className={`flex-1 py-3 rounded-xl font-medium transition-all ${
                mode === 'signup' 
                  ? 'bg-white text-tropical-green shadow-sm' 
                  : 'text-gray-600 hover:text-gray-800'
              }`}
            >
              Sign Up
            </button>
          </div>

          {/* Social Login Options */}
          <div className="space-y-3 mb-6">
            <Button
              onClick={() => handleSocialLogin('google')}
              variant="outline"
              className="w-full py-3 border-2 hover:bg-gray-50 transition-all"
              disabled={loading}
            >
              <Chrome className="mr-3 text-blue-500" size={20} />
              Continue with Google
            </Button>
            
            <div className="grid grid-cols-2 gap-3">
              <Button
                onClick={() => handleSocialLogin('facebook')}
                variant="outline"
                className="py-3 border-2 hover:bg-gray-50 transition-all"
                disabled={loading}
              >
                <Facebook className="mr-2 text-blue-600" size={18} />
                Facebook
              </Button>
              <Button
                onClick={() => handleSocialLogin('github')}
                variant="outline"
                className="py-3 border-2 hover:bg-gray-50 transition-all"
                disabled={loading}
              >
                <Github className="mr-2 text-gray-800" size={18} />
                GitHub
              </Button>
            </div>
          </div>

          {/* Divider */}
          <div className="relative mb-6">
            <Separator />
            <span className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 bg-white px-3 text-sm text-gray-500">
              or continue with email
            </span>
          </div>

          {/* Form */}
          <form onSubmit={handleSubmit} className="space-y-4">
            {/* General Error */}
            {errors.general && (
              <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-xl text-sm">
                {errors.general}
              </div>
            )}

            {/* Sign Up Fields */}
            {mode === 'signup' && (
              <>
                {/* User Type Selection */}
                <div>
                  <Label className="text-sm font-medium text-gray-700 mb-3 block">
                    I am a:
                  </Label>
                  <div className="grid grid-cols-2 gap-3">
                    <button
                      type="button"
                      onClick={() => setFormData({ ...formData, userType: 'tenant' })}
                      className={`p-4 rounded-xl border-2 text-center transition-all ${
                        formData.userType === 'tenant'
                          ? 'border-tropical-green bg-green-50 text-tropical-green'
                          : 'border-gray-200 hover:border-gray-300'
                      }`}
                    >
                      <div className="text-2xl mb-2">🏠</div>
                      <div className="font-medium">Tenant</div>
                      <div className="text-xs text-gray-500">Looking for a place</div>
                    </button>
                    <button
                      type="button"
                      onClick={() => setFormData({ ...formData, userType: 'landlord' })}
                      className={`p-4 rounded-xl border-2 text-center transition-all ${
                        formData.userType === 'landlord'
                          ? 'border-fiji-orange bg-orange-50 text-fiji-orange'
                          : 'border-gray-200 hover:border-gray-300'
                      }`}
                    >
                      <div className="text-2xl mb-2">🏗️</div>
                      <div className="font-medium">Landlord</div>
                      <div className="text-xs text-gray-500">Renting out properties</div>
                    </button>
                  </div>
                </div>

                {/* Name Field */}
                <div>
                  <Label htmlFor="name" className="text-sm font-medium text-gray-700">
                    Full Name
                  </Label>
                  <div className="relative mt-1">
                    <User className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
                    <Input
                      id="name"
                      type="text"
                      placeholder="Enter your full name"
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      className={`pl-10 py-3 border-2 rounded-xl ${errors.name ? 'border-red-300' : 'border-gray-200'}`}
                    />
                  </div>
                  {errors.name && <p className="text-red-500 text-xs mt-1">{errors.name}</p>}
                </div>

                {/* Phone Field */}
                <div>
                  <Label htmlFor="phone" className="text-sm font-medium text-gray-700">
                    Phone Number
                  </Label>
                  <div className="relative mt-1">
                    <Phone className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
                    <Input
                      id="phone"
                      type="tel"
                      placeholder="+679 123 4567"
                      value={formData.phone}
                      onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                      className={`pl-10 py-3 border-2 rounded-xl ${errors.phone ? 'border-red-300' : 'border-gray-200'}`}
                    />
                  </div>
                  {errors.phone && <p className="text-red-500 text-xs mt-1">{errors.phone}</p>}
                </div>
              </>
            )}

            {/* Email Field */}
            <div>
              <Label htmlFor="email" className="text-sm font-medium text-gray-700">
                Email Address
              </Label>
              <div className="relative mt-1">
                <Mail className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
                <Input
                  id="email"
                  type="email"
                  placeholder="Enter your email"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  className={`pl-10 py-3 border-2 rounded-xl ${errors.email ? 'border-red-300' : 'border-gray-200'}`}
                />
              </div>
              {errors.email && <p className="text-red-500 text-xs mt-1">{errors.email}</p>}
            </div>

            {/* Password Field */}
            <div>
              <Label htmlFor="password" className="text-sm font-medium text-gray-700">
                Password
              </Label>
              <div className="relative mt-1">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
                <Input
                  id="password"
                  type={showPassword ? 'text' : 'password'}
                  placeholder="Enter your password"
                  value={formData.password}
                  onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                  className={`pl-10 pr-10 py-3 border-2 rounded-xl ${errors.password ? 'border-red-300' : 'border-gray-200'}`}
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
                >
                  {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                </button>
              </div>
              {errors.password && <p className="text-red-500 text-xs mt-1">{errors.password}</p>}
            </div>

            {/* Confirm Password (Sign Up only) */}
            {mode === 'signup' && (
              <div>
                <Label htmlFor="confirmPassword" className="text-sm font-medium text-gray-700">
                  Confirm Password
                </Label>
                <div className="relative mt-1">
                  <Lock className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
                  <Input
                    id="confirmPassword"
                    type="password"
                    placeholder="Confirm your password"
                    value={formData.confirmPassword}
                    onChange={(e) => setFormData({ ...formData, confirmPassword: e.target.value })}
                    className={`pl-10 py-3 border-2 rounded-xl ${errors.confirmPassword ? 'border-red-300' : 'border-gray-200'}`}
                  />
                </div>
                {errors.confirmPassword && <p className="text-red-500 text-xs mt-1">{errors.confirmPassword}</p>}
              </div>
            )}

            {/* Submit Button */}
            <Button
              type="submit"
              disabled={loading}
              className="w-full py-4 bg-gradient-to-r from-tropical-green to-green-600 text-white font-bold text-lg rounded-xl hover:shadow-lg transition-all transform hover:scale-[1.02] disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {loading ? (
                <div className="flex items-center justify-center gap-2">
                  <div className="animate-spin h-4 w-4 border-2 border-white border-t-transparent rounded-full" />
                  {mode === 'signin' ? 'Signing In...' : 'Creating Account...'}
                </div>
              ) : (
                mode === 'signin' ? 'Sign In' : 'Create Account'
              )}
            </Button>

            {/* Forgot Password */}
            {mode === 'signin' && (
              <div className="text-center">
                <button
                  type="button"
                  className="text-sm text-tropical-green hover:text-green-700 font-medium"
                >
                  Forgot your password?
                </button>
              </div>
            )}

            {/* Terms and Privacy */}
            {mode === 'signup' && (
              <p className="text-xs text-gray-500 text-center leading-relaxed">
                By creating an account, you agree to our{' '}
                <a href="#" className="text-tropical-green font-medium">Terms of Service</a>{' '}
                and{' '}
                <a href="#" className="text-tropical-green font-medium">Privacy Policy</a>.
                You also agree to receive email updates about BulaRent.
              </p>
            )}
          </form>

          {/* Special Features for Landlords */}
          {mode === 'signup' && formData.userType === 'landlord' && (
            <div className="mt-6 p-4 bg-orange-50 border border-orange-200 rounded-xl">
              <h4 className="font-medium text-fiji-orange mb-2">🏗️ Landlord Benefits</h4>
              <ul className="text-sm text-orange-800 space-y-1">
                <li>• Get verified badge for FJD $10/month</li>
                <li>• List unlimited properties</li>
                <li>• Access to tenant screening tools</li>
                <li>• M-PAiSA payment integration</li>
                <li>• Priority customer support</li>
              </ul>
            </div>
          )}

          {/* Verification Notice */}
          <div className="mt-6 p-4 bg-blue-50 border border-blue-200 rounded-xl text-center">
            <div className="text-2xl mb-2">🛡️</div>
            <p className="text-sm text-blue-800">
              <strong>Safe & Secure:</strong> All accounts undergo verification to ensure a trusted community.
              Your personal information is protected and never shared without permission.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}