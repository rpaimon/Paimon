import { useState, useEffect } from 'react';
import { Search, Filter, MapPin, Star, Heart, Phone, MessageSquare, Grid, List, ChevronDown } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Badge } from './ui/badge';
import { Card } from './ui/card';
import { Separator } from './ui/separator';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { useAuth } from './auth/AuthContext';
import { projectId, publicAnonKey } from '../utils/supabase/info';

interface EnhancedListingsPageProps {
  onNavigate: (page: string, propertyId?: string) => void;
}

interface Property {
  id: string;
  title: string;
  location: string;
  nearLandmark?: string;
  price: string;
  period: string;
  bedrooms: number;
  bathrooms: number;
  parking: number;
  type: string;
  image: string;
  description: string;
  features: string[];
  verified: boolean;
  landlordVerified: boolean;
  views: number;
  favorites: number;
  weeklyRent: number;
  mpaisaAccepted: boolean;
  wifiIncluded: boolean;
}

export default function EnhancedListingsPage({ onNavigate }: EnhancedListingsPageProps) {
  const { user } = useAuth();
  const [properties, setProperties] = useState<Property[]>([]);
  const [loading, setLoading] = useState(true);
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [filters, setFilters] = useState({
    search: '',
    location: '',
    propertyType: '',
    priceRange: '',
    bedrooms: '',
    features: [] as string[]
  });
  const [sortBy, setSortBy] = useState('newest');

  // Sample properties - in real app, this would come from API
  const sampleProperties: Property[] = [
    {
      id: 'sample-1',
      title: 'Modern Flat near USP Campus',
      location: 'Laucala Bay',
      nearLandmark: '500m from USP Main Entrance',
      price: 'FJD $280',
      period: 'per week',
      bedrooms: 2,
      bathrooms: 1,
      parking: 1,
      type: 'Flat',
      image: 'https://images.unsplash.com/photo-1522708323590-d24dbb6b0267?w=500&h=300&fit=crop',
      description: 'Perfect for students! Walking distance to USP, furnished flat with WiFi included.',
      features: ['WiFi Included', 'Furnished', 'M-PAiSA Accepted', 'Student Friendly'],
      verified: true,
      landlordVerified: true,
      views: 45,
      favorites: 12,
      weeklyRent: 280,
      mpaisaAccepted: true,
      wifiIncluded: true
    },
    {
      id: 'sample-2',
      title: 'Traditional Bure in Tamavua Heights',
      location: 'Tamavua',
      nearLandmark: '1km from MHCC Shopping Center',
      price: 'FJD $220',
      period: 'per week',
      bedrooms: 3,
      bathrooms: 2,
      parking: 2,
      type: 'Bure',
      image: 'https://images.unsplash.com/photo-1571003123894-1f0594d2b5d9?w=500&h=300&fit=crop',
      description: 'Authentic Fijian bure with modern amenities. Great for families, garden space included.',
      features: ['Garden Space', 'Traditional Design', 'Family Friendly', 'Parking'],
      verified: true,
      landlordVerified: true,
      views: 32,
      favorites: 18,
      weeklyRent: 220,
      mpaisaAccepted: true,
      wifiIncluded: false
    },
    {
      id: 'sample-3',
      title: 'Shared Room near FNU Samabula',
      location: 'Samabula',
      nearLandmark: '300m from FNU Campus',
      price: 'FJD $120',
      period: 'per week',
      bedrooms: 1,
      bathrooms: 1,
      parking: 0,
      type: 'Shared Room',
      image: 'https://images.unsplash.com/photo-1584132915807-fd1f5fbc078f?w=500&h=300&fit=crop',
      description: 'Budget-friendly shared accommodation for students. All utilities included.',
      features: ['Utilities Included', 'Student Housing', 'Shared Kitchen', 'WiFi Included'],
      verified: false,
      landlordVerified: false,
      views: 28,
      favorites: 8,
      weeklyRent: 120,
      mpaisaAccepted: false,
      wifiIncluded: true
    },
    {
      id: 'sample-4',
      title: 'Executive Flat in Suva CBD',
      location: 'Suva CBD',
      nearLandmark: '200m from FNPF Tower',
      price: 'FJD $450',
      period: 'per week',
      bedrooms: 2,
      bathrooms: 2,
      parking: 1,
      type: 'Executive Flat',
      image: 'https://images.unsplash.com/photo-1545324418-cc1a3fa10c00?w=500&h=300&fit=crop',
      description: 'Premium executive flat in CBD. Perfect for professionals, city views.',
      features: ['City Views', 'Executive', 'Furnished', 'Security', 'M-PAiSA Accepted'],
      verified: true,
      landlordVerified: true,
      views: 67,
      favorites: 23,
      weeklyRent: 450,
      mpaisaAccepted: true,
      wifiIncluded: true
    }
  ];

  useEffect(() => {
    loadProperties();
  }, [filters, sortBy]);

  const loadProperties = async () => {
    setLoading(true);
    try {
      // In a real app, this would fetch from the API
      // For demo, we'll use sample data with client-side filtering
      let filteredProperties = [...sampleProperties];

      // Apply filters
      if (filters.search) {
        filteredProperties = filteredProperties.filter(p =>
          p.title.toLowerCase().includes(filters.search.toLowerCase()) ||
          p.location.toLowerCase().includes(filters.search.toLowerCase()) ||
          p.description.toLowerCase().includes(filters.search.toLowerCase())
        );
      }

      if (filters.location) {
        filteredProperties = filteredProperties.filter(p => p.location === filters.location);
      }

      if (filters.propertyType) {
        filteredProperties = filteredProperties.filter(p => p.type === filters.propertyType);
      }

      if (filters.bedrooms) {
        filteredProperties = filteredProperties.filter(p => p.bedrooms === parseInt(filters.bedrooms));
      }

      if (filters.priceRange) {
        const [min, max] = filters.priceRange.split('-').map(p => parseInt(p.replace('+', '')));
        filteredProperties = filteredProperties.filter(p => {
          const price = p.weeklyRent;
          if (max) {
            return price >= min && price <= max;
          } else {
            return price >= min;
          }
        });
      }

      // Apply sorting
      switch (sortBy) {
        case 'price-low':
          filteredProperties.sort((a, b) => a.weeklyRent - b.weeklyRent);
          break;
        case 'price-high':
          filteredProperties.sort((a, b) => b.weeklyRent - a.weeklyRent);
          break;
        case 'popular':
          filteredProperties.sort((a, b) => b.views - a.views);
          break;
        default: // newest
          // Already in newest order
          break;
      }

      // Prioritize verified properties
      filteredProperties.sort((a, b) => {
        if (a.landlordVerified && !b.landlordVerified) return -1;
        if (!a.landlordVerified && b.landlordVerified) return 1;
        return 0;
      });

      setProperties(filteredProperties);
    } catch (error) {
      console.error('Error loading properties:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleContactClick = (property: Property) => {
    if (!user) {
      alert('🔒 Please sign in to view contact information');
      return;
    }
    alert(`📞 Contact: ${property.title}\n\nThis would open contact details or messaging system.`);
  };

  const handleFavoriteClick = (property: Property) => {
    if (!user) {
      alert('🔒 Please sign in to save favorites');
      return;
    }
    alert(`❤️ Added "${property.title}" to favorites!`);
  };

  const renderPropertyCard = (property: Property) => {
    if (viewMode === 'list') {
      return (
        <Card key={property.id} className="p-4 hover:shadow-lg transition-all duration-300 cursor-pointer border border-gray-100 hover:border-tropical-green/30">
          <div className="flex gap-4">
            <div className="relative flex-shrink-0">
              <ImageWithFallback
                src={property.image}
                alt={property.title}
                className="w-32 h-24 object-cover rounded-lg"
              />
              {property.landlordVerified && (
                <Badge className="absolute -top-1 -right-1 verified-badge text-xs">
                  <span className="mr-1">✓</span>
                  VERIFIED
                </Badge>
              )}
            </div>

            <div className="flex-1">
              <div className="flex justify-between items-start mb-2">
                <h3 className="font-bold text-lg hover:text-tropical-green transition-colors line-clamp-1">
                  {property.title}
                </h3>
                <div className="text-right">
                  <div className="font-bold text-xl text-tropical-green">{property.price}</div>
                  <div className="text-sm text-gray-500">{property.period}</div>
                </div>
              </div>

              <div className="space-y-2 mb-3">
                <div className="flex items-center text-gray-600">
                  <MapPin size={16} className="mr-2 flex-shrink-0" />
                  <span className="line-clamp-1">{property.location}</span>
                </div>
                {property.nearLandmark && (
                  <div className="landmark-tag text-xs">
                    📍 {property.nearLandmark}
                  </div>
                )}
              </div>

              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-4 text-gray-500 text-sm">
                  <span>{property.bedrooms} bed</span>
                  <span>{property.bathrooms} bath</span>
                  {property.parking > 0 && <span>{property.parking} park</span>}
                </div>
                <div className="flex items-center gap-1 text-yellow-500">
                  <Star size={16} className="fill-current" />
                  <span className="text-sm">4.{Math.floor(Math.random() * 9) + 1}</span>
                </div>
              </div>

              <div className="flex flex-wrap gap-2 mb-3">
                {property.features.slice(0, 3).map((feature, index) => (
                  <span 
                    key={index}
                    className="bg-gray-100 text-gray-600 px-2 py-1 rounded-full text-xs"
                  >
                    {feature}
                  </span>
                ))}
                {property.features.length > 3 && (
                  <span className="text-xs text-gray-500">
                    +{property.features.length - 3} more
                  </span>
                )}
              </div>

              <div className="flex justify-between items-center">
                <div className="flex items-center gap-2 text-xs text-gray-500">
                  <span>{property.views} views</span>
                  <span>•</span>
                  <span>{property.favorites} favorites</span>
                </div>
                <div className="flex gap-2">
                  <Button 
                    size="sm"
                    variant="outline" 
                    className="p-2 border-gray-200 hover:border-red-300 hover:bg-red-50"
                    onClick={(e) => {
                      e.stopPropagation();
                      handleFavoriteClick(property);
                    }}
                  >
                    <Heart size={16} />
                  </Button>
                  <Button 
                    size="sm"
                    variant="outline" 
                    className="p-2 border-gray-200 hover:border-tropical-green hover:bg-green-50"
                    onClick={(e) => {
                      e.stopPropagation();
                      handleContactClick(property);
                    }}
                  >
                    <Phone size={16} />
                  </Button>
                  <Button 
                    size="sm"
                    className="bg-tropical-green text-white hover:bg-green-600"
                    onClick={(e) => {
                      e.stopPropagation();
                      onNavigate('property-details', property.id);
                    }}
                  >
                    View Details
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </Card>
      );
    }

    // Grid view
    return (
      <Card
        key={property.id}
        className="overflow-hidden hover:shadow-lg transition-all duration-300 cursor-pointer border border-gray-100 hover:border-tropical-green/30 transform hover:-translate-y-1"
        onClick={() => onNavigate('property-details', property.id)}
      >
        <div className="relative">
          <ImageWithFallback
            src={property.image}
            alt={property.title}
            className="w-full h-48 object-cover"
          />
          
          <div className="absolute top-4 right-4 bg-tropical-green text-white px-3 py-1 rounded-xl font-bold shadow-lg">
            {property.price}
          </div>
          
          <div className="absolute top-4 left-4">
            {property.landlordVerified ? (
              <Badge className="verified-badge">
                <span className="mr-1">✓</span>
                VERIFIED
              </Badge>
            ) : (
              <Badge className="unverified-badge">
                🚨 UNVERIFIED
              </Badge>
            )}
          </div>

          <div className="absolute bottom-4 left-4">
            <Badge className="bg-white/95 text-gray-800 px-3 py-1">
              {property.type}
            </Badge>
          </div>

          {property.mpaisaAccepted && (
            <div className="absolute bottom-4 right-4">
              <Badge className="mpaisa-button px-3 py-1">
                💳 M-PAiSA
              </Badge>
            </div>
          )}
        </div>
        
        <div className="p-4">
          <h3 className="font-bold text-lg text-gray-900 mb-3 hover:text-tropical-green transition-colors line-clamp-2">
            {property.title}
          </h3>
          
          <div className="space-y-2 mb-4">
            <div className="flex items-center text-gray-600">
              <MapPin size={16} className="mr-2" />
              <span className="line-clamp-1">{property.location}</span>
            </div>
            {property.nearLandmark && (
              <div className="landmark-tag">
                📍 {property.nearLandmark}
              </div>
            )}
          </div>
          
          <div className="flex flex-wrap gap-2 mb-4">
            {property.features.slice(0, 3).map((feature, index) => (
              <span 
                key={index}
                className="bg-gray-100 text-gray-600 px-3 py-1 rounded-full text-sm"
              >
                {feature}
              </span>
            ))}
            {property.features.length > 3 && (
              <span className="text-sm text-gray-500">
                +{property.features.length - 3} more
              </span>
            )}
          </div>
          
          <div className="flex items-center justify-between text-gray-500 mb-4">
            <div className="flex items-center gap-4">
              <span>{property.bedrooms} bed</span>
              <span>{property.bathrooms} bath</span>
              {property.parking > 0 && <span>{property.parking} park</span>}
            </div>
            <div className="flex items-center gap-1">
              <Star size={16} className="text-yellow-400 fill-current" />
              <span>4.{Math.floor(Math.random() * 9) + 1}</span>
            </div>
          </div>

          <div className="flex gap-2">
            <Button 
              className="flex-1 bg-tropical-green hover:bg-green-600 text-white"
              onClick={(e) => {
                e.stopPropagation();
                onNavigate('property-details', property.id);
              }}
            >
              View Details
            </Button>
            <Button 
              variant="outline" 
              className="p-3 border-red-200 text-red-600 hover:bg-red-50"
              onClick={(e) => {
                e.stopPropagation();
                handleFavoriteClick(property);
              }}
            >
              <Heart size={16} />
            </Button>
            <Button 
              variant="outline" 
              className="p-3 border-tropical-green text-tropical-green hover:bg-green-50"
              onClick={(e) => {
                e.stopPropagation();
                handleContactClick(property);
              }}
            >
              <Phone size={16} />
            </Button>
          </div>
        </div>
      </Card>
    );
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Search and Filters Header */}
      <div className="bg-white shadow-sm border-b sticky top-16 z-30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          {/* Search Bar */}
          <div className="relative mb-4">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={20} />
            <Input
              placeholder="Search properties in Suva..."
              value={filters.search}
              onChange={(e) => setFilters({ ...filters, search: e.target.value })}
              className="pl-10 pr-4 py-3 text-lg border-2 border-gray-200 focus:border-tropical-green rounded-xl"
            />
          </div>

          {/* Filters Row */}
          <div className="flex flex-wrap gap-3 items-center">
            <Select value={filters.location} onValueChange={(value) => setFilters({ ...filters, location: value })}>
              <SelectTrigger className="w-40">
                <SelectValue placeholder="Location" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="">All Locations</SelectItem>
                <SelectItem value="Suva CBD">Suva CBD</SelectItem>
                <SelectItem value="Samabula">Samabula</SelectItem>
                <SelectItem value="Nabua">Nabua</SelectItem>
                <SelectItem value="Raiwaqa">Raiwaqa</SelectItem>
                <SelectItem value="Tamavua">Tamavua</SelectItem>
                <SelectItem value="Laucala Bay">Laucala Bay</SelectItem>
              </SelectContent>
            </Select>

            <Select value={filters.propertyType} onValueChange={(value) => setFilters({ ...filters, propertyType: value })}>
              <SelectTrigger className="w-40">
                <SelectValue placeholder="Property Type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="">All Types</SelectItem>
                <SelectItem value="Flat">Flat</SelectItem>
                <SelectItem value="Bure">Bure</SelectItem>
                <SelectItem value="Shared Room">Shared Room</SelectItem>
                <SelectItem value="Executive Flat">Executive Flat</SelectItem>
                <SelectItem value="Studio">Studio</SelectItem>
              </SelectContent>
            </Select>

            <Select value={filters.priceRange} onValueChange={(value) => setFilters({ ...filters, priceRange: value })}>
              <SelectTrigger className="w-40">
                <SelectValue placeholder="Price Range" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="">Any Price</SelectItem>
                <SelectItem value="0-150">Under $150</SelectItem>
                <SelectItem value="150-250">$150 - $250</SelectItem>
                <SelectItem value="250-350">$250 - $350</SelectItem>
                <SelectItem value="350+">$350+</SelectItem>
              </SelectContent>
            </Select>

            <Select value={filters.bedrooms} onValueChange={(value) => setFilters({ ...filters, bedrooms: value })}>
              <SelectTrigger className="w-32">
                <SelectValue placeholder="Bedrooms" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="">Any</SelectItem>
                <SelectItem value="1">1 bed</SelectItem>
                <SelectItem value="2">2 beds</SelectItem>
                <SelectItem value="3">3 beds</SelectItem>
                <SelectItem value="4">4+ beds</SelectItem>
              </SelectContent>
            </Select>

            <Separator orientation="vertical" className="h-6" />

            <Select value={sortBy} onValueChange={setSortBy}>
              <SelectTrigger className="w-40">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="newest">Newest First</SelectItem>
                <SelectItem value="price-low">Price: Low to High</SelectItem>
                <SelectItem value="price-high">Price: High to Low</SelectItem>
                <SelectItem value="popular">Most Popular</SelectItem>
              </SelectContent>
            </Select>

            <div className="flex gap-2 ml-auto">
              <Button
                variant={viewMode === 'grid' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setViewMode('grid')}
                className={viewMode === 'grid' ? 'bg-tropical-green text-white' : ''}
              >
                <Grid size={16} />
              </Button>
              <Button
                variant={viewMode === 'list' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setViewMode('list')}
                className={viewMode === 'list' ? 'bg-tropical-green text-white' : ''}
              >
                <List size={16} />
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Results */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex justify-between items-center mb-6">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">
              Properties in Suva {filters.location && `• ${filters.location}`}
            </h1>
            <p className="text-gray-600 mt-1">
              {loading ? 'Loading...' : `${properties.length} properties found`}
              {filters.search && ` for "${filters.search}"`}
            </p>
          </div>
          
          <Badge className="bg-green-100 text-green-800 px-4 py-2">
            🔍 Verified properties shown first
          </Badge>
        </div>

        {loading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[1, 2, 3, 4, 5, 6].map((i) => (
              <div key={i} className="bg-white rounded-lg shadow animate-pulse">
                <div className="bg-gray-200 h-48 rounded-t-lg"></div>
                <div className="p-4 space-y-3">
                  <div className="bg-gray-200 h-4 rounded"></div>
                  <div className="bg-gray-200 h-3 rounded w-3/4"></div>
                  <div className="bg-gray-200 h-3 rounded w-1/2"></div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className={
            viewMode === 'grid' 
              ? 'grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6' 
              : 'space-y-4'
          }>
            {properties.map(renderPropertyCard)}
          </div>
        )}

        {!loading && properties.length === 0 && (
          <div className="text-center py-12">
            <div className="text-6xl mb-4">🏠</div>
            <h3 className="text-xl font-bold mb-2">No properties found</h3>
            <p className="text-gray-600 mb-6">
              Try adjusting your search criteria or browse all properties.
            </p>
            <Button
              onClick={() => setFilters({
                search: '',
                location: '',
                propertyType: '',
                priceRange: '',
                bedrooms: '',
                features: []
              })}
              className="bg-tropical-green text-white"
            >
              Clear Filters
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}