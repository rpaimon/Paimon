import { projectId, publicAnonKey } from '../../utils/supabase/info';

export interface UserProfile {
  id: string;
  name: string;
  email: string;
  phone: string;
  userType: 'tenant' | 'landlord';
  verified: boolean;
  avatar?: string;
  bio?: string;
  location?: string;
  preferences?: {
    notifications: boolean;
    emailUpdates: boolean;
    smsAlerts: boolean;
  };
  favorites: string[];
  savedSearches: any[];
  createdAt: string;
  updatedAt?: string;
}

export const loadUserProfile = async (token: string): Promise<UserProfile | null> => {
  try {
    const response = await fetch(
      `https://${projectId}.supabase.co/functions/v1/make-server-304c8b39/profile`,
      {
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        }
      }
    );

    if (response.ok) {
      const { profile } = await response.json();
      return profile;
    }
    return null;
  } catch (error) {
    console.error('Error loading user profile:', error);
    return null;
  }
};

export const saveUserProfile = async (token: string, updates: Partial<UserProfile>): Promise<UserProfile | null> => {
  try {
    const response = await fetch(
      `https://${projectId}.supabase.co/functions/v1/make-server-304c8b39/profile`,
      {
        method: 'PUT',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(updates)
      }
    );

    if (response.ok) {
      const { profile } = await response.json();
      return profile;
    }
    return null;
  } catch (error) {
    console.error('Error saving profile:', error);
    return null;
  }
};

export const loadFavoriteProperties = async (favoriteIds: string[]) => {
  if (!favoriteIds.length) return [];

  try {
    const response = await fetch(
      `https://${projectId}.supabase.co/functions/v1/make-server-304c8b39/properties`,
      {
        headers: {
          'Authorization': `Bearer ${publicAnonKey}`,
          'Content-Type': 'application/json'
        }
      }
    );

    if (response.ok) {
      const { properties } = await response.json();
      return properties.filter((p: any) => favoriteIds.includes(p.id));
    }
    return [];
  } catch (error) {
    console.error('Error loading favorite properties:', error);
    return [];
  }
};

export const calculateStats = (profile: UserProfile | null, favoriteProperties: any[]) => {
  return {
    favorites: favoriteProperties.length,
    searches: profile?.savedSearches?.length || 0,
    views: Math.floor(Math.random() * 50) + 10,
    messages: Math.floor(Math.random() * 5) + 1
  };
};

export const validateProfileForm = (formData: Partial<UserProfile>): Record<string, string> => {
  const errors: Record<string, string> = {};

  if (!formData.name?.trim()) {
    errors.name = 'Name is required';
  }

  if (!formData.email?.trim()) {
    errors.email = 'Email is required';
  } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
    errors.email = 'Please enter a valid email';
  }

  if (!formData.phone?.trim()) {
    errors.phone = 'Phone number is required';
  }

  return errors;
};