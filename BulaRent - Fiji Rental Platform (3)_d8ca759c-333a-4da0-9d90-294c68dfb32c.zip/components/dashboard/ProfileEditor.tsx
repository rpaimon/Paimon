import { useState } from 'react';
import { Camera, Save, X, User, Mail, Phone, MapPin } from 'lucide-react';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { Textarea } from '../ui/textarea';
import { Card } from '../ui/card';
import { Switch } from '../ui/switch';
import { UserProfile, validateProfileForm } from './helpers';
import { DEFAULT_PREFERENCES } from './constants';

interface ProfileEditorProps {
  profile: UserProfile;
  onSave: (updates: Partial<UserProfile>) => void;
  onCancel: () => void;
  loading: boolean;
}

export default function ProfileEditor({ profile, onSave, onCancel, loading }: ProfileEditorProps) {
  const [formData, setFormData] = useState<Partial<UserProfile>>({
    ...profile,
    preferences: { ...DEFAULT_PREFERENCES, ...profile.preferences }
  });
  const [errors, setErrors] = useState<Record<string, string>>({});

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const validationErrors = validateProfileForm(formData);
    
    if (Object.keys(validationErrors).length > 0) {
      setErrors(validationErrors);
      return;
    }

    setErrors({});
    onSave(formData);
  };

  const handleAvatarUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        setFormData(prev => ({ ...prev, avatar: event.target?.result as string }));
      };
      reader.readAsDataURL(file);
    }
  };

  return (
    <Card className="p-6">
      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Avatar Upload */}
        <div className="text-center">
          <div className="relative inline-block">
            <div className="w-24 h-24 rounded-full bg-gray-200 overflow-hidden">
              {formData.avatar ? (
                <img src={formData.avatar} alt="Avatar" className="w-full h-full object-cover" />
              ) : (
                <div className="w-full h-full flex items-center justify-center">
                  <User size={32} className="text-gray-400" />
                </div>
              )}
            </div>
            <label
              htmlFor="avatar-upload"
              className="absolute bottom-0 right-0 bg-tropical-green text-white p-2 rounded-full cursor-pointer hover:bg-green-600 transition-colors"
            >
              <Camera size={16} />
            </label>
            <input
              id="avatar-upload"
              type="file"
              accept="image/*"
              onChange={handleAvatarUpload}
              className="hidden"
            />
          </div>
        </div>

        {/* Basic Information */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <Label htmlFor="name">Full Name *</Label>
            <div className="relative">
              <User className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
              <Input
                id="name"
                value={formData.name || ''}
                onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                className={`pl-10 ${errors.name ? 'border-red-300' : ''}`}
                placeholder="Enter your full name"
              />
            </div>
            {errors.name && <p className="text-red-500 text-sm mt-1">{errors.name}</p>}
          </div>

          <div>
            <Label htmlFor="email">Email Address *</Label>
            <div className="relative">
              <Mail className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
              <Input
                id="email"
                type="email"
                value={formData.email || ''}
                onChange={(e) => setFormData(prev => ({ ...prev, email: e.target.value }))}
                className={`pl-10 ${errors.email ? 'border-red-300' : ''}`}
                placeholder="Enter your email"
              />
            </div>
            {errors.email && <p className="text-red-500 text-sm mt-1">{errors.email}</p>}
          </div>

          <div>
            <Label htmlFor="phone">Phone Number *</Label>
            <div className="relative">
              <Phone className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
              <Input
                id="phone"
                type="tel"
                value={formData.phone || ''}
                onChange={(e) => setFormData(prev => ({ ...prev, phone: e.target.value }))}
                className={`pl-10 ${errors.phone ? 'border-red-300' : ''}`}
                placeholder="+679 123 4567"
              />
            </div>
            {errors.phone && <p className="text-red-500 text-sm mt-1">{errors.phone}</p>}
          </div>

          <div>
            <Label htmlFor="location">Location</Label>
            <div className="relative">
              <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
              <Input
                id="location"
                value={formData.location || ''}
                onChange={(e) => setFormData(prev => ({ ...prev, location: e.target.value }))}
                className="pl-10"
                placeholder="e.g. Samabula, Suva"
              />
            </div>
          </div>
        </div>

        {/* Bio */}
        <div>
          <Label htmlFor="bio">Bio</Label>
          <Textarea
            id="bio"
            value={formData.bio || ''}
            onChange={(e) => setFormData(prev => ({ ...prev, bio: e.target.value }))}
            placeholder="Tell us about yourself..."
            rows={3}
          />
        </div>

        {/* Preferences */}
        <div className="space-y-4">
          <h4 className="font-medium text-gray-900">Notification Preferences</h4>
          
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <div>
                <label className="font-medium text-sm">Email Notifications</label>
                <p className="text-xs text-gray-500">Receive updates about new properties and messages</p>
              </div>
              <Switch
                checked={formData.preferences?.emailUpdates ?? true}
                onCheckedChange={(checked) => 
                  setFormData(prev => ({
                    ...prev,
                    preferences: { ...prev.preferences, emailUpdates: checked }
                  }))
                }
              />
            </div>

            <div className="flex items-center justify-between">
              <div>
                <label className="font-medium text-sm">SMS Alerts</label>
                <p className="text-xs text-gray-500">Get instant alerts for urgent updates</p>
              </div>
              <Switch
                checked={formData.preferences?.smsAlerts ?? false}
                onCheckedChange={(checked) => 
                  setFormData(prev => ({
                    ...prev,
                    preferences: { ...prev.preferences, smsAlerts: checked }
                  }))
                }
              />
            </div>

            <div className="flex items-center justify-between">
              <div>
                <label className="font-medium text-sm">Push Notifications</label>
                <p className="text-xs text-gray-500">Browser notifications for real-time updates</p>
              </div>
              <Switch
                checked={formData.preferences?.notifications ?? true}
                onCheckedChange={(checked) => 
                  setFormData(prev => ({
                    ...prev,
                    preferences: { ...prev.preferences, notifications: checked }
                  }))
                }
              />
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex gap-3 pt-4">
          <Button
            type="submit"
            disabled={loading}
            className="flex-1 bg-tropical-green text-white hover:bg-green-600"
          >
            {loading ? (
              <div className="flex items-center gap-2">
                <div className="animate-spin h-4 w-4 border-2 border-white border-t-transparent rounded-full" />
                Saving...
              </div>
            ) : (
              <>
                <Save size={18} className="mr-2" />
                Save Changes
              </>
            )}
          </Button>
          
          <Button
            type="button"
            variant="outline"
            onClick={onCancel}
            disabled={loading}
            className="flex-1"
          >
            <X size={18} className="mr-2" />
            Cancel
          </Button>
        </div>
      </form>
    </Card>
  );
}