import { Heart, Search, Eye, MessageSquare } from 'lucide-react';
import { Card } from '../ui/card';
import { DASHBOARD_STATS } from './constants';

interface DashboardStatsProps {
  stats: Record<string, number>;
  onStatClick: (tab: string) => void;
}

const iconMap = {
  Heart,
  Search,
  Eye,
  MessageSquare
};

export default function DashboardStats({ stats, onStatClick }: DashboardStatsProps) {
  return (
    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
      {DASHBOARD_STATS.map((stat) => {
        const IconComponent = iconMap[stat.icon as keyof typeof iconMap];
        const value = stats[stat.key] || 0;
        
        return (
          <Card 
            key={stat.key}
            className={`p-6 text-center cursor-pointer hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1 ${stat.bgColor} border-2 border-transparent hover:border-gray-200`}
            onClick={() => stat.tab && onStatClick(stat.tab)}
          >
            <div className={`inline-flex items-center justify-center w-12 h-12 rounded-full ${stat.bgColor} mb-4`}>
              <IconComponent className={`${stat.color}`} size={24} />
            </div>
            <div className="font-bold text-2xl text-gray-900 mb-1">{value}</div>
            <div className="text-sm text-gray-600">{stat.label}</div>
          </Card>
        );
      })}
    </div>
  );
}