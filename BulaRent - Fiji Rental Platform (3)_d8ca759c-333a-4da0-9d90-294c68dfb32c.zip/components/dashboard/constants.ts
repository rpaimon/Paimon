export const DASHBOARD_STATS = [
  { 
    key: 'favorites',
    label: 'Favorite Properties', 
    icon: 'Heart', 
    color: 'text-red-500', 
    bgColor: 'bg-red-50',
    tab: 'favorites'
  },
  { 
    key: 'searches',
    label: 'Saved Searches', 
    icon: 'Search', 
    color: 'text-blue-500', 
    bgColor: 'bg-blue-50',
    tab: 'searches'
  },
  { 
    key: 'views',
    label: 'Profile Views', 
    icon: 'Eye', 
    color: 'text-green-500', 
    bgColor: 'bg-green-50',
    tab: null
  },
  { 
    key: 'messages',
    label: 'Messages', 
    icon: 'MessageSquare', 
    color: 'text-purple-500', 
    bgColor: 'bg-purple-50',
    tab: 'messages'
  }
];

export const DEFAULT_PREFERENCES = {
  notifications: true,
  emailUpdates: true,
  smsAlerts: false
};

export const RECENT_ACTIVITY_MOCK = [
  {
    id: 1,
    type: 'favorite',
    title: 'Added property to favorites',
    description: 'Modern Flat near USP Campus',
    timestamp: '2 hours ago',
    icon: 'Heart'
  },
  {
    id: 2,
    type: 'search',
    title: 'Saved new search',
    description: 'Properties in Samabula under FJD $200',
    timestamp: '1 day ago',
    icon: 'Search'
  },
  {
    id: 3,
    type: 'message',
    title: 'New message received',
    description: 'From verified landlord Maria R.',
    timestamp: '2 days ago',
    icon: 'MessageSquare'
  }
];

export const LANDLORD_BENEFITS = [
  'List unlimited properties',
  'Get verified landlord badge',
  'Access to tenant screening',
  'M-PAiSA payment integration',
  'Priority customer support',
  'Advanced analytics'
];

export const TENANT_BENEFITS = [
  'Save unlimited favorites',
  'Create custom search alerts',
  'Direct messaging with landlords',
  'Verified property information',
  'Scam protection services',
  'Local area insights'
];