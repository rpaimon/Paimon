import { useState, useEffect } from 'react';
import { ArrowLeft, Heart, Share2, Phone, MessageSquare, MapPin, Bed, Bath, Car, WiFi, Shield, Star, Calendar, DollarSign } from 'lucide-react';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Card, CardContent } from './ui/card';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { useAuth } from './auth/AuthContext';
import LiveChatSystem from './LiveChatSystem';
import { projectId, publicAnonKey } from '../utils/supabase/info';

interface PropertyDetailsPageProps {
  propertyId: string;
  onNavigate: (page: string) => void;
}

interface Property {
  id: string;
  title: string;
  location: string;
  price: string;
  period: string;
  bedrooms: number;
  bathrooms: number;
  parking: number;
  type: string;
  image: string;
  description: string;
  features: string[];
  views: number;
  favorites: number;
  ownerId: string;
  verified: boolean;
  landlordVerified: boolean;
  nearLandmark?: string;
  weeklyRent?: number;
  mpaisaAccepted?: boolean;
  wifiIncluded?: boolean;
  ownerName?: string;
  contact?: string;
}

export default function PropertyDetailsPage({ propertyId, onNavigate }: PropertyDetailsPageProps) {
  const { user, getAccessToken } = useAuth();
  const [property, setProperty] = useState<Property | null>(null);
  const [loading, setLoading] = useState(true);
  const [isFavorite, setIsFavorite] = useState(false);
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const [showChat, setShowChat] = useState(false);
  const [showContactInfo, setShowContactInfo] = useState(false);

  // Sample images for demo
  const sampleImages = [
    'https://images.unsplash.com/photo-1522708323590-d24dbb6b0267?w=800&h=600&fit=crop',
    'https://images.unsplash.com/photo-1571003123894-1f0594d2b5d9?w=800&h=600&fit=crop',
    'https://images.unsplash.com/photo-1584132915807-fd1f5fbc078f?w=800&h=600&fit=crop',
    'https://images.unsplash.com/photo-1586023492125-27b2c045efd7?w=800&h=600&fit=crop'
  ];

  useEffect(() => {
    loadPropertyDetails();
  }, [propertyId]);

  const loadPropertyDetails = async () => {
    try {
      setLoading(true);
      
      // Try to load from server
      try {
        const response = await fetch(
          `https://${projectId}.supabase.co/functions/v1/make-server-304c8b39/properties`,
          {
            headers: {
              'Authorization': `Bearer ${publicAnonKey}`,
              'Content-Type': 'application/json'
            }
          }
        );

        if (response.ok) {
          const data = await response.json();
          const properties = data.properties || [];
          const foundProperty = properties.find((p: Property) => p.id === propertyId);
          
          if (foundProperty) {
            setProperty(foundProperty);
            return;
          }
        }
      } catch (error) {
        console.error('Server error:', error);
      }

      // Fallback sample property
      const sampleProperty: Property = {
        id: propertyId,
        title: 'Modern Flat near USP Campus',
        location: 'Laucala Bay, Suva',
        price: 'FJD $280',
        period: 'week',
        bedrooms: 2,
        bathrooms: 1,
        parking: 1,
        type: 'Flat',
        image: sampleImages[0],
        description: 'Perfect for students! This modern flat is walking distance to USP with all amenities included. The property features spacious bedrooms, a fully equipped kitchen, and a comfortable living area. Located in a safe and quiet neighborhood with easy access to public transport and local shops. Ideal for 2-3 students or a small family. The flat comes furnished with all essential items including bed, wardrobe, study desk, sofa, dining table, and kitchen appliances. WiFi and all utilities are included in the rent. M-PAiSA payments accepted for convenience.',
        features: ['WiFi Included', 'Furnished', 'M-PAiSA Accepted', 'Student Friendly', 'Air Conditioning', 'Security System', 'Parking', 'Near Transport'],
        views: 156,
        favorites: 23,
        ownerId: 'verified-landlord-1',
        verified: true,
        landlordVerified: true,
        nearLandmark: '500m from USP Main Entrance',
        weeklyRent: 280,
        mpaisaAccepted: true,
        wifiIncluded: true,
        ownerName: 'Maria Ratunabuabua',
        contact: '+679 123 4567'
      };

      setProperty(sampleProperty);
    } finally {
      setLoading(false);
    }
  };

  const handleShare = () => {
    if (navigator.share) {
      navigator.share({
        title: property?.title,
        text: property?.description,
        url: window.location.href
      });
    } else {
      navigator.clipboard.writeText(window.location.href);
      alert('Property link copied to clipboard!');
    }
  };

  const toggleFavorite = async () => {
    if (!user) {
      alert('Please sign in to save favorites');
      return;
    }

    const token = getAccessToken();
    if (!token) return;

    try {
      const method = isFavorite ? 'DELETE' : 'POST';
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-304c8b39/favorites/${propertyId}`,
        {
          method,
          headers: {
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json'
          }
        }
      );

      if (response.ok) {
        setIsFavorite(!isFavorite);
      }
    } catch (error) {
      console.error('Error toggling favorite:', error);
    }
  };

  const handleContactAction = (action: 'phone' | 'message') => {
    if (!user) {
      alert('🔒 Please sign in to view contact information and chat with landlords');
      return;
    }

    if (action === 'phone') {
      setShowContactInfo(true);
    } else if (action === 'message') {
      setShowChat(true);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-tropical-green"></div>
        <span className="ml-3 text-gray-600">Loading property details...</span>
      </div>
    );
  }

  if (!property) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Property Not Found</h2>
          <p className="text-gray-600 mb-6">The property you're looking for doesn't exist.</p>
          <Button onClick={() => onNavigate('listings')} className="bg-tropical-green text-white">
            ← Back to Listings
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Mobile Header */}
      <div className="bg-white shadow-sm sticky top-0 z-10">
        <div className="flex items-center justify-between p-4">
          <button
            onClick={() => onNavigate('listings')}
            className="flex items-center gap-2 text-gray-600 hover:text-gray-900"
          >
            <ArrowLeft size={20} />
            <span>Back</span>
          </button>
          
          <div className="flex items-center gap-2">
            <button
              onClick={handleShare}
              className="p-2 rounded-full hover:bg-gray-100 transition-colors"
            >
              <Share2 size={20} className="text-gray-600" />
            </button>
            
            <button
              onClick={toggleFavorite}
              className={`p-2 rounded-full transition-colors ${
                isFavorite ? 'text-red-500 bg-red-50' : 'text-gray-600 hover:bg-gray-100'
              }`}
            >
              <Heart size={20} fill={isFavorite ? 'currentColor' : 'none'} />
            </button>
          </div>
        </div>
      </div>

      <div className="max-w-4xl mx-auto">
        {/* Image Gallery */}
        <div className="relative bg-white">
          <div className="aspect-video overflow-hidden">
            <ImageWithFallback
              src={sampleImages[currentImageIndex]}
              alt={property.title}
              className="w-full h-full object-cover"
            />
          </div>
          
          {/* Image Navigation */}
          <div className="absolute bottom-4 right-4 bg-black/50 text-white px-3 py-1 rounded-full text-sm">
            {currentImageIndex + 1} / {sampleImages.length}
          </div>
          
          {/* Verification Badge */}
          <div className="absolute top-4 left-4">
            {property.landlordVerified ? (
              <Badge className="verified-badge">
                <Shield size={12} className="mr-1" />
                VERIFIED LANDLORD
              </Badge>
            ) : (
              <Badge className="unverified-badge">
                🚨 UNVERIFIED
              </Badge>
            )}
          </div>
        </div>

        {/* Image Thumbnails */}
        <div className="bg-white p-4 border-b">
          <div className="flex gap-2 overflow-x-auto">
            {sampleImages.map((img, index) => (
              <button
                key={index}
                onClick={() => setCurrentImageIndex(index)}
                className={`flex-shrink-0 w-16 h-16 rounded-lg overflow-hidden border-2 transition-colors ${
                  currentImageIndex === index ? 'border-tropical-green' : 'border-gray-200'
                }`}
              >
                <img src={img} alt={`View ${index + 1}`} className="w-full h-full object-cover" />
              </button>
            ))}
          </div>
        </div>

        {/* Property Info */}
        <div className="bg-white p-4 space-y-4">
          {/* Title & Price */}
          <div className="flex items-start justify-between">
            <div className="flex-1">
              <h1 className="text-2xl font-bold text-gray-900 mb-1">{property.title}</h1>
              <div className="flex items-center text-gray-600 mb-2">
                <MapPin size={16} className="mr-1" />
                <span>{property.location}</span>
              </div>
              {property.nearLandmark && (
                <div className="landmark-tag text-sm mb-2">
                  📍 {property.nearLandmark}
                </div>
              )}
            </div>
            <div className="text-right">
              <div className="text-2xl font-bold text-tropical-green">{property.price}</div>
              <div className="text-sm text-gray-500">per {property.period}</div>
            </div>
          </div>

          {/* Property Details */}
          <div className="grid grid-cols-3 gap-4 py-4 border-t border-b">
            <div className="text-center">
              <div className="flex items-center justify-center gap-1 mb-1">
                <Bed size={18} className="text-gray-600" />
                <span className="font-semibold">{property.bedrooms}</span>
              </div>
              <div className="text-sm text-gray-500">Bedrooms</div>
            </div>
            <div className="text-center">
              <div className="flex items-center justify-center gap-1 mb-1">
                <Bath size={18} className="text-gray-600" />
                <span className="font-semibold">{property.bathrooms}</span>
              </div>
              <div className="text-sm text-gray-500">Bathrooms</div>
            </div>
            <div className="text-center">
              <div className="flex items-center justify-center gap-1 mb-1">
                <Car size={18} className="text-gray-600" />
                <span className="font-semibold">{property.parking}</span>
              </div>
              <div className="text-sm text-gray-500">Parking</div>
            </div>
          </div>

          {/* Features */}
          <div>
            <h3 className="font-semibold text-gray-900 mb-3">Features & Amenities</h3>
            <div className="grid grid-cols-2 gap-2">
              {property.features.map((feature, index) => (
                <div key={index} className="flex items-center gap-2 text-sm">
                  <div className="w-2 h-2 bg-tropical-green rounded-full flex-shrink-0"></div>
                  <span>{feature}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Description */}
          <div>
            <h3 className="font-semibold text-gray-900 mb-3">Description</h3>
            <p className="text-gray-700 leading-relaxed">{property.description}</p>
          </div>

          {/* Property Stats */}
          <div className="bg-gray-50 rounded-lg p-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="flex items-center gap-2">
                <Star className="text-yellow-400 fill-current" size={16} />
                <span className="text-sm">4.{Math.floor(Math.random() * 9) + 1} rating</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-sm">{property.views} views</span>
              </div>
            </div>
          </div>
        </div>

        {/* Contact Information - Auth Required */}
        <Card className="mx-4 mb-6">
          <CardContent className="p-4">
            <h3 className="font-semibold text-gray-900 mb-3">Contact Property Owner</h3>
            <div className="space-y-3">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 bg-tropical-green text-white rounded-full flex items-center justify-center font-semibold">
                  {property.ownerName?.[0] || 'O'}
                </div>
                <div>
                  <div className="font-medium">{property.ownerName || 'Property Owner'}</div>
                  <div className="text-sm text-gray-500">Landlord</div>
                  {property.landlordVerified && (
                    <div className="flex items-center gap-1 text-xs text-green-600">
                      <Shield size={12} />
                      Verified Landlord
                    </div>
                  )}
                </div>
              </div>

              {/* Contact Info - Show only if signed in */}
              {user && showContactInfo ? (
                <div className="bg-green-50 border border-green-200 rounded-lg p-3">
                  <p className="text-green-800 font-medium">📞 Contact Information:</p>
                  <p className="text-green-700">{property.contact || '+679 123 4567'}</p>
                  <p className="text-green-600 text-sm mt-1">
                    Best times to call: 9 AM - 6 PM (Fiji Time)
                  </p>
                </div>
              ) : !user ? (
                <div className="bg-blue-50 border border-blue-200 rounded-lg p-3">
                  <p className="text-blue-800 text-sm">
                    🔒 Sign in to view contact information and chat with the landlord
                  </p>
                </div>
              ) : null}
            </div>
          </CardContent>
        </Card>

        {/* Action Buttons - Auth Gates */}
        <div className="sticky bottom-0 bg-white border-t p-4 space-y-3">
          <div className="flex gap-3">
            <Button
              className={`flex-1 ${
                user 
                  ? 'bg-tropical-green text-white hover:bg-green-600' 
                  : 'bg-gray-300 text-gray-500 cursor-not-allowed'
              }`}
              onClick={() => handleContactAction('phone')}
              disabled={!user}
            >
              <Phone size={18} className="mr-2" />
              {user ? 'Call Now' : '🔒 Sign in to Call'}
            </Button>
            
            <Button
              variant="outline"
              className={`flex-1 ${
                user 
                  ? 'border-blue-500 text-blue-600 hover:bg-blue-50' 
                  : 'border-gray-300 text-gray-400 cursor-not-allowed'
              }`}
              onClick={() => handleContactAction('message')}
              disabled={!user}
            >
              <MessageSquare size={18} className="mr-2" />
              {user ? 'Start Chat' : '🔒 Sign in to Chat'}
            </Button>
          </div>

          {property.mpaisaAccepted && (
            <div className="text-center">
              <Badge className="mpaisa-button text-xs">
                💳 M-PAiSA payments accepted
              </Badge>
            </div>
          )}

          {!user && (
            <div className="text-center">
              <p className="text-xs text-gray-500">
                🔐 Create a free account to contact landlords and save favorites
              </p>
            </div>
          )}
        </div>
      </div>

      {/* Live Chat System */}
      {showChat && property && user && (
        <LiveChatSystem
          propertyId={property.id}
          propertyTitle={property.title}
          landlordName={property.ownerName || 'Property Owner'}
          landlordVerified={property.landlordVerified}
          onClose={() => setShowChat(false)}
        />
      )}
    </div>
  );
}