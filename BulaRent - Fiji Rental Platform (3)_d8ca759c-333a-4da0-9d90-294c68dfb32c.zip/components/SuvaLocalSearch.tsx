import { useState } from 'react';
import { Search, MapPin, Filter, Shield, Star, AlertTriangle, Phone } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Badge } from './ui/badge';

interface SuvaLocalSearchProps {
  onSearch: (filters: SearchFilters) => void;
  showAdvanced?: boolean;
}

interface SearchFilters {
  area: string;
  priceRange: string;
  roomType: string;
  verified: boolean;
  furnished: boolean;
  wifiIncluded: boolean;
  mpaisaAccepted: boolean;
  leaseDuration: string;
  landmark: string;
}

export default function SuvaLocalSearch({ onSearch, showAdvanced = false }: SuvaLocalSearchProps) {
  const [isAdvancedOpen, setIsAdvancedOpen] = useState(showAdvanced);
  const [filters, setFilters] = useState<SearchFilters>({
    area: '',
    priceRange: '',
    roomType: '',
    verified: true, // Default to verified listings first
    furnished: false,
    wifiIncluded: false,
    mpaisaAccepted: false,
    leaseDuration: '',
    landmark: ''
  });

  // Suva-specific areas
  const suvaAreas = [
    'Samabula',
    'Nabua', 
    'Raiwaqa',
    'Tamavua',
    'Suva CBD',
    'Laucala Bay',
    'Lami',
    'Nasinu',
    'Cunningham',
    'Toorak'
  ];

  // Major landmarks within 1km radius
  const suvaLandmarks = [
    { name: 'USP (University of South Pacific)', area: 'Laucala Bay' },
    { name: 'MHCC (My Suva Park)', area: 'Suva CBD' },
    { name: 'Suva Market', area: 'Suva CBD' },
    { name: 'FNPF Tower', area: 'Suva CBD' },
    { name: 'FNU (Fiji National University)', area: 'Samabula' },
    { name: 'Suva Grammar School', area: 'Suva CBD' },
    { name: 'Colonial War Memorial Hospital', area: 'Suva CBD' },
    { name: 'Thurston Gardens', area: 'Suva CBD' },
    { name: 'Albert Park', area: 'Suva CBD' },
    { name: 'Vodafone Arena', area: 'Suva CBD' }
  ];

  const roomTypes = [
    'Single Room',
    'Shared Room', 
    'Whole Unit (Flat)',
    'Whole Unit (Bure)',
    'Studio',
    'Bedsitter'
  ];

  const priceRanges = [
    'Under FJD $150/week',
    'FJD $150-250/week',
    'FJD $250-350/week', 
    'FJD $350-500/week',
    'Above FJD $500/week'
  ];

  const leaseDurations = [
    'Weekly',
    '1-3 months',
    '3-6 months',
    '6-12 months',
    '12+ months'
  ];

  const handleFilterChange = (key: keyof SearchFilters, value: string | boolean) => {
    const newFilters = { ...filters, [key]: value };
    setFilters(newFilters);
    onSearch(newFilters);
  };

  const clearFilters = () => {
    const clearedFilters: SearchFilters = {
      area: '',
      priceRange: '',
      roomType: '',
      verified: true, // Keep verified as default
      furnished: false,
      wifiIncluded: false,
      mpaisaAccepted: false,
      leaseDuration: '',
      landmark: ''
    };
    setFilters(clearedFilters);
    onSearch(clearedFilters);
  };

  return (
    <div className="bg-white rounded-xl shadow-lg p-4 md:p-6 mb-6">
      {/* Header */}
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <MapPin className="text-fiji-blue" size={24} />
          <h2 className="text-lg md:text-xl font-bold text-gray-900">
            Find Your Home in Suva
          </h2>
        </div>
        <Badge className="bg-fiji-light-blue text-fiji-dark-blue">
          🏠 Suva MVP
        </Badge>
      </div>

      {/* Primary Filters */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-4">
        {/* Area Selection */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Area in Suva
          </label>
          <select
            value={filters.area}
            onChange={(e) => handleFilterChange('area', e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-fiji-blue focus:border-transparent text-sm"
          >
            <option value="">All Areas</option>
            {suvaAreas.map(area => (
              <option key={area} value={area}>{area}</option>
            ))}
          </select>
        </div>

        {/* Price Range */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Weekly Rent (FJD)
          </label>
          <select
            value={filters.priceRange}
            onChange={(e) => handleFilterChange('priceRange', e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-fiji-blue focus:border-transparent text-sm"
          >
            <option value="">Any Price</option>
            {priceRanges.map(range => (
              <option key={range} value={range}>{range}</option>
            ))}
          </select>
        </div>

        {/* Room Type */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Room Type
          </label>
          <select
            value={filters.roomType}
            onChange={(e) => handleFilterChange('roomType', e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-fiji-blue focus:border-transparent text-sm"
          >
            <option value="">All Types</option>
            {roomTypes.map(type => (
              <option key={type} value={type}>{type}</option>
            ))}
          </select>
        </div>

        {/* Verified Filter */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Landlord Status
          </label>
          <div className="flex items-center gap-4 mt-2">
            <label className="flex items-center gap-2 cursor-pointer">
              <input
                type="checkbox"
                checked={filters.verified}
                onChange={(e) => handleFilterChange('verified', e.target.checked)}
                className="w-4 h-4 text-fiji-blue border-gray-300 rounded focus:ring-fiji-blue"
              />
              <span className="text-sm flex items-center gap-1">
                <Shield size={14} className="text-fiji-green" />
                Verified Only
              </span>
            </label>
          </div>
        </div>
      </div>

      {/* Quick Action Buttons */}
      <div className="flex flex-wrap gap-2 mb-4">
        <Button
          variant="outline"
          size="sm"
          onClick={() => setIsAdvancedOpen(!isAdvancedOpen)}
          className="border-fiji-blue text-fiji-blue hover:bg-fiji-light-blue"
        >
          <Filter size={16} className="mr-2" />
          More Filters
        </Button>
        
        <Button
          variant="outline" 
          size="sm"
          onClick={() => handleFilterChange('mpaisaAccepted', !filters.mpaisaAccepted)}
          className={`${filters.mpaisaAccepted 
            ? 'bg-purple-100 border-purple-500 text-purple-700' 
            : 'border-gray-300'
          }`}
        >
          M-PAiSA Accepted
        </Button>

        <Button
          variant="outline"
          size="sm"
          onClick={() => handleFilterChange('wifiIncluded', !filters.wifiIncluded)}
          className={`${filters.wifiIncluded 
            ? 'bg-green-100 border-green-500 text-green-700' 
            : 'border-gray-300'
          }`}
        >
          WiFi Included
        </Button>

        <Button
          variant="outline"
          size="sm"
          onClick={clearFilters}
          className="text-red-600 border-red-200 hover:bg-red-50"
        >
          Clear All
        </Button>
      </div>

      {/* Advanced Filters */}
      {isAdvancedOpen && (
        <div className="border-t pt-4 mt-4 space-y-4">
          <h3 className="font-semibold text-gray-900 mb-3">Advanced Filters</h3>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {/* Landmark Proximity */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Near Landmark
              </label>
              <select
                value={filters.landmark}
                onChange={(e) => handleFilterChange('landmark', e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-fiji-blue focus:border-transparent text-sm"
              >
                <option value="">Any Location</option>
                {suvaLandmarks.map(landmark => (
                  <option key={landmark.name} value={landmark.name}>
                    {landmark.name} ({landmark.area})
                  </option>
                ))}
              </select>
            </div>

            {/* Lease Duration */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Lease Duration
              </label>
              <select
                value={filters.leaseDuration}
                onChange={(e) => handleFilterChange('leaseDuration', e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-fiji-blue focus:border-transparent text-sm"
              >
                <option value="">Any Duration</option>
                {leaseDurations.map(duration => (
                  <option key={duration} value={duration}>{duration}</option>
                ))}
              </select>
            </div>

            {/* Furnished */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Additional Features
              </label>
              <div className="space-y-2">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={filters.furnished}
                    onChange={(e) => handleFilterChange('furnished', e.target.checked)}
                    className="w-4 h-4 text-fiji-blue border-gray-300 rounded focus:ring-fiji-blue"
                  />
                  <span className="text-sm">Furnished</span>
                </label>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Search Results Preview */}
      <div className="mt-4 p-3 bg-fiji-light-blue rounded-lg">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="text-sm text-fiji-dark-blue">
              🔍 Showing verified listings first
            </span>
            {filters.verified && (
              <Badge className="verified-badge">
                <Shield size={12} className="mr-1" />
                Verified Priority
              </Badge>
            )}
          </div>
          
          <div className="flex items-center gap-2 text-xs text-fiji-dark-blue">
            <AlertTriangle size={14} />
            <span>Report fake listings</span>
          </div>
        </div>
      </div>

      {/* Emergency Contact */}
      <div className="mt-3 text-center">
        <p className="text-xs text-gray-600">
          🚨 Scam Alert: Report suspicious listings to{' '}
          <a 
            href="tel:919" 
            className="text-fiji-blue hover:underline font-semibold"
          >
            Fiji Police Cyber Unit: 919
          </a>
        </p>
      </div>
    </div>
  );
}